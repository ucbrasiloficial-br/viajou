# VIAJOU — Encontre. Compare. Escolha. Viaje.

Plataforma nacional inteligente de busca e comparação de passagens aéreas, rodoviárias, fluviais, hospedagens e aluguel de veículos.

## Como ativar a busca real de voos (SearchApi.io + Cloudflare Worker)

1. Crie uma conta em **searchapi.io** e copie sua `API Key`.
2. Na **Cloudflare Workers**, abra seu Worker (`viajou-api`), cole o `cloudflare_worker/worker.js` e faça **Deploy**.
3. Em **Settings -> Variables and Secrets**, adicione a variável `SEARCHAPI_API_KEY` com a chave copiada.
4. Em `lib/app/app_config.dart`, coloque a URL do seu Worker em `defaultProxyBaseUrl` e gere o APK final pelo GitHub Actions.
