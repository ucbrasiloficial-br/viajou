# VIAJOU — Encontre. Compare. Escolha. Viaje.

Plataforma nacional inteligente de busca e comparação de passagens aéreas, rodoviárias, fluviais, hospedagens e aluguel de veículos.

## Como colocar no ar pelo navegador do celular (Zero PC)

1. **Crie um repositório no GitHub** e envie todos os arquivos deste ZIP (ou faça upload direto).
2. **Configure a API Aérea Real (Amadeus Self-Service - Gratuita):**
   - Crie uma conta gratuita em [developers.amadeus.com](https://developers.amadeus.com).
   - Crie um app no painel "My Self-Service Workspace" para obter seu `API Key` (Client ID) e `API Secret` (Client Secret).
3. **Suba o Proxy no Cloudflare Workers (Gratuito):**
   - Acesse [dash.cloudflare.com](https://dash.cloudflare.com) -> **Workers & Pages** -> **Create Worker**.
   - Cole o conteúdo do arquivo `cloudflare_worker/worker.js` e clique em **Deploy**.
   - Vá em **Settings -> Variables and Secrets** do Worker e adicione:
     - `AMADEUS_CLIENT_ID`: sua API Key
     - `AMADEUS_CLIENT_SECRET`: seu API Secret
4. **Conecte o App ao Worker:**
   - Abra `lib/app/app_config.dart` no GitHub e substitua `https://SEU-WORKER.workers.dev` pela URL real do seu Worker.
   - *(Opcional)* O usuário também pode configurar a URL diretamente dentro do app na tela **Configurações > Conexão API**.
5. **Gere o APK Android automaticamente:**
   - No GitHub, acesse a aba **Actions**, clique em **Build VIAJOU Android APK** e baixe o arquivo `.apk` pronto nos **Artifacts**.
