export default {
  async fetch(request, env) {
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);

    try {
      if (url.pathname === "/health") {
        return jsonResponse({
          status: "ok",
          service: "VIAJOU API Proxy (SearchApi.io)",
          configured: Boolean(env.SEARCHAPI_API_KEY),
          engines: ["google_flights", "google_flights_autocomplete", "google_hotels"]
        }, corsHeaders);
      }

      if (!env.SEARCHAPI_API_KEY) {
        return jsonResponse({
          error: "SEARCHAPI_API_KEY não configurada nas variáveis/secrets do Cloudflare Worker."
        }, corsHeaders, 500);
      }

      if (url.pathname === "/api/places") {
        const q = (url.searchParams.get("q") || "").trim();
        if (!q) {
          return jsonResponse({ places: [] }, corsHeaders, 200);
        }

        const params = new URLSearchParams({
          engine: "google_flights_autocomplete",
          api_key: env.SEARCHAPI_API_KEY,
          q: q,
          gl: "br",
          hl: "pt",
        });

        const apiRes = await fetch(`https://www.searchapi.io/api/v1/search?${params.toString()}`);
        const rawData = await apiRes.json();

        if (!apiRes.ok) {
          return jsonResponse({
            error: rawData.error || `Falha na busca de locais (${apiRes.status})`
          }, corsHeaders, apiRes.status);
        }

        const suggestions = Array.isArray(rawData.suggestions)
          ? rawData.suggestions
          : (Array.isArray(rawData.places) ? rawData.places : []);

        return jsonResponse({
          places: suggestions
        }, corsHeaders, 200);
      }

      if (url.pathname === "/api/flights") {
        const origin = (url.searchParams.get("origin") || "").trim();
        const destination = (url.searchParams.get("destination") || "").trim();
        const departureDate = (url.searchParams.get("departureDate") || "").trim();
        const returnDate = (url.searchParams.get("returnDate") || "").trim();
        const adults = url.searchParams.get("adults") || "1";
        const travelClass = (url.searchParams.get("travelClass") || "ECONOMY").toUpperCase();
        const currency = (url.searchParams.get("currency") || "BRL").toUpperCase();

        const cabinMap = {
          "ECONOMY": "economy",
          "PREMIUM_ECONOMY": "premium_economy",
          "BUSINESS": "business",
          "FIRST": "first"
        };

        const params = new URLSearchParams({
          engine: "google_flights",
          api_key: env.SEARCHAPI_API_KEY,
          departure_id: origin,
          arrival_id: destination,
          outbound_date: departureDate,
          adults: adults,
          travel_class: cabinMap[travelClass] || "economy",
          currency: currency,
          gl: "br",
          hl: "pt",
          flight_type: returnDate ? "round_trip" : "one_way"
        });

        if (returnDate) {
          params.append("return_date", returnDate);
        }

        const apiRes = await fetch(`https://www.searchapi.io/api/v1/search?${params.toString()}`);
        const rawData = await apiRes.json();

        if (!apiRes.ok) {
          return jsonResponse({
            error: rawData.error || `Falha na consulta de voos (${apiRes.status})`
          }, corsHeaders, apiRes.status);
        }

        const bestFlights = Array.isArray(rawData.best_flights) ? rawData.best_flights : [];
        const otherFlights = Array.isArray(rawData.other_flights) ? rawData.other_flights : [];
        const combined = [...bestFlights, ...otherFlights];

        return jsonResponse({
          provider: "SearchApi.io (Google Flights)",
          currency: currency,
          flights: combined,
          booking_token: rawData.search_metadata?.id || null
        }, corsHeaders, 200);
      }

      if (url.pathname === "/api/stays") {
        const q = (url.searchParams.get("q") || "").trim();
        const checkIn = (url.searchParams.get("checkIn") || "").trim();
        const checkOut = (url.searchParams.get("checkOut") || "").trim();
        const adults = url.searchParams.get("adults") || "1";
        const currency = (url.searchParams.get("currency") || "BRL").toUpperCase();

        const params = new URLSearchParams({
          engine: "google_hotels",
          api_key: env.SEARCHAPI_API_KEY,
          q: q,
          check_in_date: checkIn,
          check_out_date: checkOut,
          adults: adults,
          currency: currency,
          gl: "br",
          hl: "pt",
        });

        const apiRes = await fetch(`https://www.searchapi.io/api/v1/search?${params.toString()}`);
        const rawData = await apiRes.json();

        if (!apiRes.ok) {
          return jsonResponse({
            error: rawData.error || `Falha na consulta de hospedagens (${apiRes.status})`
          }, corsHeaders, apiRes.status);
        }

        const properties = Array.isArray(rawData.properties) ? rawData.properties : [];

        return jsonResponse({
          provider: "SearchApi.io (Google Hotels)",
          currency: currency,
          properties: properties,
        }, corsHeaders, 200);
      }

      return jsonResponse({ error: "Rota não encontrada no VIAJOU Worker" }, corsHeaders, 404);
    } catch (err) {
      return jsonResponse({ error: err.message || "Erro interno no Worker" }, corsHeaders, 500);
    }
  },
};

function jsonResponse(body, corsHeaders, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders,
    },
  });
}
