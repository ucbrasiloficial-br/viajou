export default {
  async fetch(request, env) {
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);
    const baseUrl = env.AMADEUS_ENV === "production"
      ? "https://api.amadeus.com"
      : "https://test.api.amadeus.com";

    try {
      if (url.pathname === "/health") {
        return jsonResponse({
          status: "ok",
          service: "VIAJOU Travel Proxy",
          configured: Boolean(env.AMADEUS_CLIENT_ID && env.AMADEUS_CLIENT_SECRET),
          environment: env.AMADEUS_ENV || "test"
        }, corsHeaders);
      }

      const token = await getAmadeusToken(baseUrl, env.AMADEUS_CLIENT_ID, env.AMADEUS_CLIENT_SECRET);

      if (url.pathname === "/api/locations") {
        const keyword = url.searchParams.get("keyword") || "";
        if (keyword.length < 2) {
          return jsonResponse({ data: [] }, corsHeaders);
        }

        const apiRes = await fetch(
          `${baseUrl}/v1/reference-data/locations?subType=CITY,AIRPORT&keyword=${encodeURIComponent(keyword)}&page[limit]=10&view=LIGHT`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const data = await apiRes.json();
        return jsonResponse(data, corsHeaders, apiRes.status);
      }

      if (url.pathname === "/api/flights") {
        const params = new URLSearchParams({
          originLocationCode: url.searchParams.get("origin") || "",
          destinationLocationCode: url.searchParams.get("destination") || "",
          departureDate: url.searchParams.get("departureDate") || "",
          adults: url.searchParams.get("adults") || "1",
          travelClass: url.searchParams.get("travelClass") || "ECONOMY",
          currencyCode: url.searchParams.get("currency") || "BRL",
          max: "30",
        });

        const returnDate = url.searchParams.get("returnDate");
        if (returnDate) {
          params.append("returnDate", returnDate);
        }

        const apiRes = await fetch(
          `${baseUrl}/v2/shopping/flight-offers?${params.toString()}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const data = await apiRes.json();
        return jsonResponse(data, corsHeaders, apiRes.status);
      }

      return jsonResponse({ error: "Rota não encontrada no VIAJOU Proxy" }, corsHeaders, 404);
    } catch (err) {
      return jsonResponse({ error: err.message }, corsHeaders, 500);
    }
  },
};

async function getAmadeusToken(baseUrl, clientId, clientSecret) {
  if (!clientId || !clientSecret) {
    throw new Error("Credenciais AMADEUS_CLIENT_ID / AMADEUS_CLIENT_SECRET não configuradas no Cloudflare Worker.");
  }

  const res = await fetch(`${baseUrl}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  if (!res.ok) {
    throw new Error("Falha na autenticação OAuth2 com fornecedor aéreo.");
  }

  const data = await res.json();
  return data.access_token;
}

function jsonResponse(body, corsHeaders, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders,
    },
  });
}
