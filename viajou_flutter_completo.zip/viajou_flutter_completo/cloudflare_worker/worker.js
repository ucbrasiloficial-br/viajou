export default {
  async fetch(request, env) {
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);

    try {
      if (url.pathname === "/health") {
        return jsonResponse({
          status: "ok",
          service: "VIAJOU Flight Proxy (SearchApi.io)",
          configured: Boolean(env.SEARCHAPI_API_KEY),
          provider: "searchapi_google_flights"
        }, corsHeaders);
      }

      if (url.pathname === "/api/flights") {
        if (!env.SEARCHAPI_API_KEY) {
          return jsonResponse({
            error: "Chave SEARCHAPI_API_KEY não configurada nas variáveis do Cloudflare Worker."
          }, corsHeaders, 500);
        }

        const origin = (url.searchParams.get("origin") || "").trim();
        const destination = (url.searchParams.get("destination") || "").trim();
        const departureDate = (url.searchParams.get("departureDate") || "").trim();
        const returnDate = (url.searchParams.get("returnDate") || "").trim();
        const adults = url.searchParams.get("adults") || "1";
        const travelClass = (url.searchParams.get("travelClass") || "ECONOMY").toUpperCase();
        const currency = (url.searchParams.get("currency") || "BRL").toUpperCase();

        const cabinMap = {
          "ECONOMY": "economy",
          "PREMIUM_ECONOMY": "premium_economy",
          "BUSINESS": "business",
          "FIRST": "first"
        };

        const params = new URLSearchParams({
          engine: "google_flights",
          api_key: env.SEARCHAPI_API_KEY,
          departure_id: origin,
          arrival_id: destination,
          outbound_date: departureDate,
          adults: adults,
          travel_class: cabinMap[travelClass] || "economy",
          currency: currency,
          gl: "br",
          hl: "pt",
          flight_type: returnDate ? "round_trip" : "one_way"
        });

        if (returnDate) {
          params.append("return_date", returnDate);
        }

        const apiRes = await fetch(`https://www.searchapi.io/api/v1/search?${params.toString()}`);
        const rawData = await apiRes.json();

        if (!apiRes.ok) {
          return jsonResponse({
            error: rawData.error || `Falha na consulta de voos (${apiRes.status})`
          }, corsHeaders, apiRes.status);
        }

        const bestFlights = Array.isArray(rawData.best_flights) ? rawData.best_flights : [];
        const otherFlights = Array.isArray(rawData.other_flights) ? rawData.other_flights : [];
        const combined = [...bestFlights, ...otherFlights];

        return jsonResponse({
          provider: "SearchApi.io (Google Flights)",
          currency: currency,
          flights: combined,
          booking_token: rawData.search_metadata?.id || null
        }, corsHeaders, 200);
      }

      return jsonResponse({ error: "Rota não encontrada no VIAJOU Worker" }, corsHeaders, 404);
    } catch (err) {
      return jsonResponse({ error: err.message || "Erro interno no Worker" }, corsHeaders, 500);
    }
  },
};

function jsonResponse(body, corsHeaders, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders,
    },
  });
}
