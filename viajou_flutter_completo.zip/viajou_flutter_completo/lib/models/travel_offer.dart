import 'travel_category.dart';

class TravelOffer {
  final String id;
  final TravelCategory category;
  final String providerName;
  final String carrierCode;
  final String originLabel;
  final String destinationLabel;
  final DateTime? departureTime;
  final DateTime? arrivalTime;
  final Duration? duration;
  final int stops;
  final double? price;
  final String currency;
  final String cabinOrService;
  final String baggageInfo;
  final String rulesSummary;
  final String dataSource;
  final DateTime fetchedAt;
  final String officialUrl;
  final bool isDirectPortalFallback;

  const TravelOffer({
    required this.id,
    required this.category,
    required this.providerName,
    this.carrierCode = '',
    required this.originLabel,
    required this.destinationLabel,
    this.departureTime,
    this.arrivalTime,
    this.duration,
    this.stops = 0,
    this.price,
    this.currency = 'BRL',
    this.cabinOrService = '',
    this.baggageInfo = '',
    this.rulesSummary = '',
    required this.dataSource,
    required this.fetchedAt,
    required this.officialUrl,
    this.isDirectPortalFallback = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'category': category.name,
        'providerName': providerName,
        'carrierCode': carrierCode,
        'originLabel': originLabel,
        'destinationLabel': destinationLabel,
        'departureTime': departureTime?.toIso8601String(),
        'arrivalTime': arrivalTime?.toIso8601String(),
        'durationMinutes': duration?.inMinutes,
        'stops': stops,
        'price': price,
        'currency': currency,
        'cabinOrService': cabinOrService,
        'baggageInfo': baggageInfo,
        'rulesSummary': rulesSummary,
        'dataSource': dataSource,
        'fetchedAt': fetchedAt.toIso8601String(),
        'officialUrl': officialUrl,
        'isDirectPortalFallback': isDirectPortalFallback,
      };

  factory TravelOffer.fromJson(Map<String, dynamic> json) => TravelOffer(
        id: json['id'] ?? '',
        category: TravelCategory.values.firstWhere(
          (e) => e.name == json['category'],
          orElse: () => TravelCategory.flights,
        ),
        providerName: json['providerName'] ?? '',
        carrierCode: json['carrierCode'] ?? '',
        originLabel: json['originLabel'] ?? '',
        destinationLabel: json['destinationLabel'] ?? '',
        departureTime: json['departureTime'] != null
            ? DateTime.parse(json['departureTime'])
            : null,
        arrivalTime: json['arrivalTime'] != null
            ? DateTime.parse(json['arrivalTime'])
            : null,
        duration: json['durationMinutes'] != null
            ? Duration(minutes: json['durationMinutes'])
            : null,
        stops: json['stops'] ?? 0,
        price: json['price'] != null ? (json['price'] as num).toDouble() : null,
        currency: json['currency'] ?? 'BRL',
        cabinOrService: json['cabinOrService'] ?? '',
        baggageInfo: json['baggageInfo'] ?? '',
        rulesSummary: json['rulesSummary'] ?? '',
        dataSource: json['dataSource'] ?? '',
        fetchedAt: DateTime.parse(json['fetchedAt']),
        officialUrl: json['officialUrl'] ?? '',
        isDirectPortalFallback: json['isDirectPortalFallback'] ?? false,
      );
}
