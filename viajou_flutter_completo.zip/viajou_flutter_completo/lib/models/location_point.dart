class LocationPoint {
  final String code;
  final String name;
  final String city;
  final String stateOrCountry;
  final String type;

  const LocationPoint({
    required this.code,
    required this.name,
    required this.city,
    required this.stateOrCountry,
    this.type = 'CITY',
  });

  String get displayLabel =>
      code.isNotEmpty ? '$city ($code)' : '$city - $stateOrCountry';

  Map<String, dynamic> toJson() => {
        'code': code,
        'name': name,
        'city': city,
        'stateOrCountry': stateOrCountry,
        'type': type,
      };

  factory LocationPoint.fromJson(Map<String, dynamic> json) => LocationPoint(
        code: json['code'] ?? '',
        name: json['name'] ?? '',
        city: json['city'] ?? '',
        stateOrCountry: json['stateOrCountry'] ?? '',
        type: json['type'] ?? 'CITY',
      );
}
