import 'package:flutter/material.dart';

enum TravelCategory {
  flights,
  packages,
  buses,
  boats,
  stays,
  cars;

  String labelLocalized(String lang) {
    switch (this) {
      case TravelCategory.flights:
        return lang == 'en' ? 'Flights' : (lang == 'es' ? 'Vuelos' : 'Aéreo');
      case TravelCategory.packages:
        return lang == 'en' ? 'Packages' : (lang == 'es' ? 'Paquetes' : 'Pacotes');
      case TravelCategory.buses:
        return lang == 'en' ? 'Bus & Rail' : (lang == 'es' ? 'Bus / Tren' : 'Ônibus');
      case TravelCategory.boats:
        return lang == 'en' ? 'Boats' : (lang == 'es' ? 'Fluvial' : 'Fluvial');
      case TravelCategory.stays:
        return lang == 'en' ? 'Hotels' : (lang == 'es' ? 'Hoteles' : 'Hotéis');
      case TravelCategory.cars:
        return lang == 'en' ? 'Cars' : (lang == 'es' ? 'Autos' : 'Carros');
    }
  }

  String get label => labelLocalized('pt');

  String get fullTitle {
    switch (this) {
      case TravelCategory.flights:
        return 'Passagens Aéreas';
      case TravelCategory.packages:
        return 'Pacotes (Voo + Hotel)';
      case TravelCategory.buses:
        return 'Ônibus & Trens (Brasil e Exterior)';
      case TravelCategory.boats:
        return 'Passagens Fluviais';
      case TravelCategory.stays:
        return 'Hospedagens';
      case TravelCategory.cars:
        return 'Aluguel de Veículos';
    }
  }

  IconData get icon {
    switch (this) {
      case TravelCategory.flights:
        return Icons.flight_takeoff_rounded;
      case TravelCategory.packages:
        return Icons.luggage_rounded;
      case TravelCategory.buses:
        return Icons.directions_bus_rounded;
      case TravelCategory.boats:
        return Icons.directions_boat_rounded;
      case TravelCategory.stays:
        return Icons.hotel_rounded;
      case TravelCategory.cars:
        return Icons.directions_car_rounded;
    }
  }

  bool get hasLiveApiIntegration =>
      this == TravelCategory.flights ||
      this == TravelCategory.packages ||
      this == TravelCategory.stays ||
      this == TravelCategory.buses;
}
