import 'package:flutter/material.dart';

enum TravelCategory {
  flights,
  buses,
  boats,
  stays,
  cars;

  String get label {
    switch (this) {
      case TravelCategory.flights:
        return 'Aéreo';
      case TravelCategory.buses:
        return 'Ônibus';
      case TravelCategory.boats:
        return 'Fluvial';
      case TravelCategory.stays:
        return 'Hospedagem';
      case TravelCategory.cars:
        return 'Carros';
    }
  }

  String get fullTitle {
    switch (this) {
      case TravelCategory.flights:
        return 'Passagens Aéreas';
      case TravelCategory.buses:
        return 'Passagens Rodoviárias';
      case TravelCategory.boats:
        return 'Passagens Fluviais';
      case TravelCategory.stays:
        return 'Hospedagens';
      case TravelCategory.cars:
        return 'Aluguel de Veículos';
    }
  }

  IconData get icon {
    switch (this) {
      case TravelCategory.flights:
        return Icons.flight_takeoff_rounded;
      case TravelCategory.buses:
        return Icons.directions_bus_rounded;
      case TravelCategory.boats:
        return Icons.directions_boat_rounded;
      case TravelCategory.stays:
        return Icons.hotel_rounded;
      case TravelCategory.cars:
        return Icons.directions_car_rounded;
    }
  }

  bool get hasLiveApiIntegration => this == TravelCategory.flights;
}
