class ChecklistItem {
  final String id;
  final String title;
  final String categoryTag;
  final bool completed;

  const ChecklistItem({
    required this.id,
    required this.title,
    required this.categoryTag,
    this.completed = false,
  });

  ChecklistItem copyWith({bool? completed}) {
    return ChecklistItem(
      id: id,
      title: title,
      categoryTag: categoryTag,
      completed: completed ?? this.completed,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'categoryTag': categoryTag,
        'completed': completed,
      };

  factory ChecklistItem.fromJson(Map<String, dynamic> json) => ChecklistItem(
        id: json['id'] ?? '',
        title: json['title'] ?? '',
        categoryTag: json['categoryTag'] ?? 'Geral',
        completed: json['completed'] ?? false,
      );
}
