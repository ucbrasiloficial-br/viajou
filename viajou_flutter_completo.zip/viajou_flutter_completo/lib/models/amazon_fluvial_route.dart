class AmazonFluvialRoute {
  final String id;
  final String originCity;
  final String destinationCity;
  final String originPort;
  final String destinationPort;
  final String boatDuration;
  final String speedboatDuration;
  final String frequency;
  final String accommodations;
  final String tips;

  const AmazonFluvialRoute({
    required this.id,
    required this.originCity,
    required this.destinationCity,
    required this.originPort,
    required this.destinationPort,
    required this.boatDuration,
    required this.speedboatDuration,
    required this.frequency,
    required this.accommodations,
    required this.tips,
  });

  static const List<AmazonFluvialRoute> routes = [
    AmazonFluvialRoute(
      id: 'mao_pin',
      originCity: 'Manaus (AM)',
      destinationCity: 'Parintins (AM)',
      originPort: 'Porto de Manaus (Roadway) / Manaus Moderna',
      destinationPort: 'Terminal Hidroviário de Parintins',
      boatDuration: '18h a 24h (descendo o rio)',
      speedboatDuration: '8h a 10h (lancha rápida / ajato)',
      frequency: 'Saídas diárias (barcos regionais e lanchas)',
      accommodations: 'Rede climatizada ou aberta, camarote duplo e suíte',
      tips: 'Chegue ao porto com 2h de antecedência para escolher um bom espaço de armar rede longe da casa de máquinas.',
    ),
    AmazonFluvialRoute(
      id: 'mao_stm',
      originCity: 'Manaus (AM)',
      destinationCity: 'Santarém (PA)',
      originPort: 'Porto de Manaus (Roadway)',
      destinationPort: 'Terminal Hidroviário de Santarém',
      boatDuration: '30h a 36h (descendo o Rio Amazonas)',
      speedboatDuration: '14h a 16h (lancha rápida)',
      frequency: 'Segundas, quartas, sextas e sábados',
      accommodations: 'Convés (rede), camarote climatizado e suíte',
      tips: 'Trecho interestadual (AM → PA): aceita reserva de vagas gratuitas ou 50% de desconto via ID Jovem, Idoso e Passe Livre.',
    ),
    AmazonFluvialRoute(
      id: 'mao_tff',
      originCity: 'Manaus (AM)',
      destinationCity: 'Tefé (AM)',
      originPort: 'Porto de Manaus / São Raimundo',
      destinationPort: 'Porto de Tefé',
      boatDuration: '36h a 48h (subindo o Rio Solimões)',
      speedboatDuration: '12h a 14h (lancha ajato)',
      frequency: 'Terças, quintas e sábados',
      accommodations: 'Rede (convés coberto) e camarote fechado',
      tips: 'Subir o Solimões leva mais tempo por conta da correnteza. Leve agasalho leve se viajar em lancha com ar-condicionado.',
    ),
    AmazonFluvialRoute(
      id: 'mao_tbt',
      originCity: 'Manaus (AM)',
      destinationCity: 'Tabatinga (AM)',
      originPort: 'Porto de Manaus / Manaus Moderna',
      destinationPort: 'Porto de Tabatinga (Tríplice Fronteira)',
      boatDuration: '5 a 7 dias (subindo o Alto Solimões)',
      speedboatDuration: '30h a 36h (lancha rápida com paradas)',
      frequency: 'Saídas semanais (quartas e sábados)',
      accommodations: 'Rede, camarote individual/duplo e alimentação inclusa nos barcos',
      tips: 'Em viagens longas no Alto Solimões, leve água mineral extra, repelente e documento oficial com foto para fiscalização.',
    ),
    AmazonFluvialRoute(
      id: 'stm_bel',
      originCity: 'Santarém (PA)',
      destinationCity: 'Belém (PA)',
      originPort: 'Terminal Hidroviário de Santarém',
      destinationPort: 'Terminal Hidroviário de Belém (Av. Marechal Hermes)',
      boatDuration: '36h a 44h (via Estreitos de Breves)',
      speedboatDuration: 'Não há linha direta única (trechos fracionados)',
      frequency: 'Terças, quintas e sábados',
      accommodations: 'Rede climatizada, rede aberta e camarotes',
      tips: 'A travessia pelos Estreitos de Breves durante o dia oferece vista panorâmica das comunidades ribeirinhas.',
    ),
    AmazonFluvialRoute(
      id: 'bel_mcp',
      originCity: 'Belém (PA)',
      destinationCity: 'Macapá / Santana (AP)',
      originPort: 'Terminal Hidroviário de Belém',
      destinationPort: 'Porto de Santana (AP)',
      boatDuration: '24h a 28h (navios e ferry-boats)',
      speedboatDuration: '11h a 13h (lancha rápida)',
      frequency: 'Saídas quase diárias',
      accommodations: 'Poltrona reclinável, rede e camarote climatizado',
      tips: 'Trecho interestadual (PA → AP) com direito garantido a vagas sociais (ID Jovem, Idoso e Passe Livre) no guichê.',
    ),
  ];
}
