import 'travel_category.dart';
import 'location_point.dart';

class SearchQuery {
  final String id;
  final TravelCategory category;
  final LocationPoint? origin;
  final LocationPoint destination;
  final DateTime departureDate;
  final DateTime? returnDate;
  final bool isRoundTrip;
  final int passengers;
  final String travelClass;
  final DateTime createdAt;

  SearchQuery({
    required this.id,
    required this.category,
    this.origin,
    required this.destination,
    required this.departureDate,
    this.returnDate,
    this.isRoundTrip = false,
    this.passengers = 1,
    this.travelClass = 'ECONOMY',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'category': category.name,
        'origin': origin?.toJson(),
        'destination': destination.toJson(),
        'departureDate': departureDate.toIso8601String(),
        'returnDate': returnDate?.toIso8601String(),
        'isRoundTrip': isRoundTrip,
        'passengers': passengers,
        'travelClass': travelClass,
        'createdAt': createdAt.toIso8601String(),
      };

  factory SearchQuery.fromJson(Map<String, dynamic> json) => SearchQuery(
        id: json['id'] ?? '',
        category: TravelCategory.values.firstWhere(
          (e) => e.name == json['category'],
          orElse: () => TravelCategory.flights,
        ),
        origin: json['origin'] != null
            ? LocationPoint.fromJson(json['origin'])
            : null,
        destination: LocationPoint.fromJson(json['destination']),
        departureDate: DateTime.parse(json['departureDate']),
        returnDate: json['returnDate'] != null
            ? DateTime.parse(json['returnDate'])
            : null,
        isRoundTrip: json['isRoundTrip'] ?? false,
        passengers: json['passengers'] ?? 1,
        travelClass: json['travelClass'] ?? 'ECONOMY',
        createdAt: DateTime.parse(json['createdAt']),
      );
}
