class TravelBenefit {
  final String id;
  final String title;
  final String subtitle;
  final String legalBasis;
  final String discountDetails;
  final List<String> requirements;
  final List<String> requiredDocuments;
  final String howToRequest;
  final String officialPortalUrl;
  final String importantNotice;

  const TravelBenefit({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.legalBasis,
    required this.discountDetails,
    required this.requirements,
    required this.requiredDocuments,
    required this.howToRequest,
    required this.officialPortalUrl,
    required this.importantNotice,
  });
}
