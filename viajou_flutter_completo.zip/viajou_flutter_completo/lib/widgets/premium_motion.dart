import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Entrada escalonada suave com slide + fade para seções e cards premium.
class StaggeredReveal extends StatefulWidget {
  final Widget child;
  final int index;
  final Duration baseDelay;
  final double offsetY;

  const StaggeredReveal({
    super.key,
    required this.child,
    this.index = 0,
    this.baseDelay = const Duration(milliseconds: 65),
    this.offsetY = 18,
  });

  @override
  State<StaggeredReveal> createState() => _StaggeredRevealState();
}

class _StaggeredRevealState extends State<StaggeredReveal>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: AppMotion.normal,
    );
    final curved = CurvedAnimation(
      parent: _controller,
      curve: AppMotion.smoothCurve,
    );
    _opacity = curved;
    _slide = Tween<Offset>(
      begin: Offset(0, widget.offsetY),
      end: Offset.zero,
    ).animate(curved);

    final delayMs = (widget.index.clamp(0, 8)) * widget.baseDelay.inMilliseconds;
    Future.delayed(Duration(milliseconds: delayMs), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Opacity(
          opacity: _opacity.value,
          child: Transform.translate(
            offset: _slide.value,
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}

/// Micro-interação tátil com escala suave ao pressionar.
class PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scaleFactor;

  const PressableScale({
    super.key,
    required this.child,
    this.onTap,
    this.scaleFactor = 0.965,
  });

  @override
  State<PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<PressableScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (_pressed == value) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTapDown: widget.onTap != null ? (_) => _setPressed(true) : null,
      onTapUp: widget.onTap != null ? (_) => _setPressed(false) : null,
      onTapCancel: widget.onTap != null ? () => _setPressed(false) : null,
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? widget.scaleFactor : 1.0,
        duration: const Duration(milliseconds: 130),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

/// Brilho cintilante animado (shimmer) para skeletons de carregamento premium.
class ShimmerGlowBox extends StatefulWidget {
  final double height;
  final double? width;
  final double radius;

  const ShimmerGlowBox({
    super.key,
    required this.height,
    this.width,
    this.radius = 18,
  });

  @override
  State<ShimmerGlowBox> createState() => _ShimmerGlowBoxState();
}

class _ShimmerGlowBoxState extends State<ShimmerGlowBox>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final shift = (_controller.value * 2.4) - 1.2;
        return Container(
          height: widget.height,
          width: widget.width ?? double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.radius),
            border: Border.all(color: AppColors.cardBorder.withValues(alpha: 0.7)),
            gradient: LinearGradient(
              begin: Alignment(shift - 1.0, -0.3),
              end: Alignment(shift + 1.0, 0.3),
              colors: const [
                AppColors.cardBackground,
                Color(0xFF231942),
                AppColors.cardBackground,
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Orbe de luz ambiente sutil para dar profundidade editorial ao fundo escuro.
class AmbientGlowBackdrop extends StatelessWidget {
  final Widget child;

  const AmbientGlowBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: -90,
          right: -70,
          child: IgnorePointer(
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppColors.primaryPurple.withValues(alpha: 0.24),
                    AppColors.primaryPurple.withValues(alpha: 0.0),
                  ],
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 260,
          left: -95,
          child: IgnorePointer(
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppColors.neonViolet.withValues(alpha: 0.14),
                    AppColors.neonViolet.withValues(alpha: 0.0),
                  ],
                ),
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
