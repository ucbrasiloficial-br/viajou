import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ViajouLogo extends StatelessWidget {
  final double size;
  final bool showSlogan;

  const ViajouLogo({
    super.key,
    this.size = 28,
    this.showSlogan = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(size * 0.26),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primaryPurple, AppColors.neonViolet],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(size * 0.38),
                border: Border.all(
                  color: AppColors.lightPurple.withValues(alpha: 0.55),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withValues(alpha: 0.55),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Icon(
                Icons.explore_rounded,
                color: AppColors.white,
                size: size * 0.85,
              ),
            ),
            SizedBox(width: size * 0.36),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [AppColors.white, AppColors.lightPurple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(bounds),
              child: Text(
                'VIAJOU',
                style: TextStyle(
                  fontSize: size,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.0,
                  color: AppColors.white,
                ),
              ),
            ),
          ],
        ),
        if (showSlogan) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.cardBackground.withValues(alpha: 0.75),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: Text(
              'Encontre. Compare. Escolha. Viaje.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: size * 0.36,
                color: AppColors.lightPurple,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ],
      ],
    );
  }
}
