import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ViajouLogo extends StatelessWidget {
  final double size;
  final bool showSlogan;

  const ViajouLogo({
    super.key,
    this.size = 28,
    this.showSlogan = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(size * 0.25),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primaryPurple, AppColors.lightPurple],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(size * 0.35),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withValues(alpha: 0.45),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(
                Icons.explore_rounded,
                color: AppColors.white,
                size: size * 0.85,
              ),
            ),
            SizedBox(width: size * 0.35),
            Text(
              'VIAJOU',
              style: TextStyle(
                fontSize: size,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.8,
                color: AppColors.white,
              ),
            ),
          ],
        ),
        if (showSlogan) ...[
          const SizedBox(height: 10),
          Text(
            'Encontre. Compare. Escolha. Viaje.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: size * 0.42,
              color: AppColors.lightPurple,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ],
    );
  }
}
