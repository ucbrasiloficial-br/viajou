import 'package:flutter/material.dart';
import '../models/travel_offer.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';

class OfferCard extends StatelessWidget {
  final TravelOffer offer;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;

  const OfferCard({
    super.key,
    required this.offer,
    required this.isFavorite,
    required this.onTap,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.cardBackground,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.darkPurple.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    offer.category.icon,
                    color: AppColors.lightPurple,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        offer.providerName,
                        style: const TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      Text(
                        offer.cabinOrService,
                        style: const TextStyle(
                          color: AppColors.secondaryText,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: onToggleFavorite,
                  icon: Icon(
                    isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: isFavorite ? AppColors.primaryPurple : AppColors.secondaryText,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (offer.departureTime != null && offer.arrivalTime != null) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _TimeColumn(
                    time: AppFormatters.timeOnly(offer.departureTime),
                    place: offer.originLabel,
                    alignEnd: false,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          AppFormatters.durationLabel(offer.duration),
                          style: const TextStyle(
                            color: AppColors.secondaryText,
                            fontSize: 11,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          child: Divider(color: AppColors.primaryPurple, thickness: 1.5),
                        ),
                        Text(
                          offer.stops == 0
                              ? 'Direto'
                              : '${offer.stops} parada(s)',
                          style: TextStyle(
                            color: offer.stops == 0
                                ? AppColors.success
                                : AppColors.lightPurple,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _TimeColumn(
                    time: AppFormatters.timeOnly(offer.arrivalTime),
                    place: offer.destinationLabel,
                    alignEnd: true,
                  ),
                ],
              ),
              const SizedBox(height: 14),
            ] else ...[
              Text(
                offer.rulesSummary,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.secondaryText, fontSize: 13),
              ),
              const SizedBox(height: 12),
            ],
            const Divider(color: AppColors.cardBorder, height: 1),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Fonte: ${offer.dataSource}',
                      style: const TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 11,
                      ),
                    ),
                    Text(
                      'Atualizado: ${AppFormatters.timeOnly(offer.fetchedAt)}',
                      style: const TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
                Text(
                  AppFormatters.currency(offer.price, offer.currency),
                  style: const TextStyle(
                    color: AppColors.lightPurple,
                    fontWeight: FontWeight.w800,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeColumn extends StatelessWidget {
  final String time;
  final String place;
  final bool alignEnd;

  const _TimeColumn({
    required this.time,
    required this.place,
    required this.alignEnd,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
          alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          time,
          style: const TextStyle(
            color: AppColors.white,
            fontSize: 18,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          place,
          style: const TextStyle(
            color: AppColors.secondaryText,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
