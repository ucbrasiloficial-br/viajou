import 'package:flutter/material.dart';
import '../models/travel_offer.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import 'premium_motion.dart';

class OfferCard extends StatelessWidget {
  final TravelOffer offer;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;

  const OfferCard({
    super.key,
    required this.offer,
    required this.isFavorite,
    required this.onTap,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onTap,
      scaleFactor: 0.982,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.cardBackground, Color(0xFF191330)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: offer.isPromoDeal
                ? AppColors.success.withValues(alpha: 0.65)
                : AppColors.cardBorder,
            width: offer.isPromoDeal ? 1.4 : 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (offer.isPromoDeal) ...[
              Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.success.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: AppColors.success.withValues(alpha: 0.55)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.local_fire_department_rounded,
                        color: AppColors.success, size: 14),
                    const SizedBox(width: 5),
                    Text(
                      offer.promoBadge ?? 'OFERTA EM DESTAQUE',
                      style: const TextStyle(
                        color: AppColors.success,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primaryPurple.withValues(alpha: 0.35),
                        AppColors.darkPurple,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.lightPurple.withValues(alpha: 0.25),
                    ),
                  ),
                  child: Icon(
                    offer.category.icon,
                    color: AppColors.lightPurple,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        offer.providerName,
                        style: const TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        offer.cabinOrService,
                        style: const TextStyle(
                          color: AppColors.secondaryText,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                PressableScale(
                  onTap: onToggleFavorite,
                  scaleFactor: 0.85,
                  child: AnimatedContainer(
                    duration: AppMotion.fast,
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isFavorite
                          ? AppColors.primaryPurple.withValues(alpha: 0.22)
                          : AppColors.elevatedGlass,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isFavorite
                            ? AppColors.lightPurple.withValues(alpha: 0.6)
                            : AppColors.cardBorder,
                      ),
                    ),
                    child: Icon(
                      isFavorite
                          ? Icons.favorite_rounded
                          : Icons.favorite_border_rounded,
                      size: 19,
                      color: isFavorite
                          ? AppColors.lightPurple
                          : AppColors.secondaryText,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (offer.departureTime != null && offer.arrivalTime != null) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _TimeColumn(
                    time: AppFormatters.timeOnly(offer.departureTime),
                    place: offer.originLabel,
                    alignEnd: false,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          AppFormatters.durationLabel(offer.duration),
                          style: const TextStyle(
                            color: AppColors.secondaryText,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                color: AppColors.lightPurple,
                                shape: BoxShape.circle,
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 1.5,
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      AppColors.lightPurple,
                                      AppColors.primaryPurple,
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Icon(
                              offer.category.icon,
                              size: 14,
                              color: AppColors.lightPurple,
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: (offer.stops == 0
                                    ? AppColors.success
                                    : AppColors.lightPurple)
                                .withValues(alpha: 0.14),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            offer.stops == 0
                                ? 'Direto'
                                : '${offer.stops} parada(s)',
                            style: TextStyle(
                              color: offer.stops == 0
                                  ? AppColors.success
                                  : AppColors.lightPurple,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _TimeColumn(
                    time: AppFormatters.timeOnly(offer.arrivalTime),
                    place: offer.destinationLabel,
                    alignEnd: true,
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ] else ...[
              Text(
                offer.rulesSummary,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.secondaryText, fontSize: 13),
              ),
              const SizedBox(height: 14),
            ],
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    AppColors.cardBorder.withValues(alpha: 0.9),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      offer.dataSource,
                      style: const TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Atualizado às ${AppFormatters.timeOnly(offer.fetchedAt)}',
                      style: const TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      'A partir de',
                      style: TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 10,
                      ),
                    ),
                    Text(
                      AppFormatters.currency(offer.price, offer.currency),
                      style: const TextStyle(
                        color: AppColors.lightPurple,
                        fontWeight: FontWeight.w900,
                        fontSize: 19,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeColumn extends StatelessWidget {
  final String time;
  final String place;
  final bool alignEnd;

  const _TimeColumn({
    required this.time,
    required this.place,
    required this.alignEnd,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
          alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          time,
          style: const TextStyle(
            color: AppColors.white,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          place,
          style: const TextStyle(
            color: AppColors.lightPurple,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
