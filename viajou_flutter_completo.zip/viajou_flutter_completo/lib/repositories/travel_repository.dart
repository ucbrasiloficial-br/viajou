import 'dart:convert';
import 'package:http/http.dart' as http;
import '../app/app_config.dart';
import '../integrations/external_redirect_builder.dart';
import '../integrations/flight_api_client.dart';
import '../integrations/stays_api_client.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_benefit.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';

class SearchResultBundle {
  final List<TravelOffer> offers;
  final bool isLiveData;
  final String? infoBannerMessage;

  const SearchResultBundle({
    required this.offers,
    required this.isLiveData,
    this.infoBannerMessage,
  });
}

class TravelRepository {
  final FlightApiClient _flightClient = FlightApiClient();
  final StaysApiClient _staysClient = StaysApiClient();

  static const List<LocationPoint> curatedBrazilianLocations = [
    LocationPoint(code: 'MAO', name: 'Aeroporto Intl. Eduardo Gomes / Porto de Manaus', city: 'Manaus', stateOrCountry: 'AM - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'SAO', name: 'São Paulo (Todos Aeroportos)', city: 'São Paulo', stateOrCountry: 'SP - Brasil', type: 'CITY'),
    LocationPoint(code: 'GRU', name: 'Aeroporto Intl. de Guarulhos', city: 'São Paulo', stateOrCountry: 'SP - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'CGH', name: 'Aeroporto de Congonhas', city: 'São Paulo', stateOrCountry: 'SP - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'RIO', name: 'Rio de Janeiro (Todos Aeroportos)', city: 'Rio de Janeiro', stateOrCountry: 'RJ - Brasil', type: 'CITY'),
    LocationPoint(code: 'GIG', name: 'Aeroporto Intl. Tom Jobim (Galeão)', city: 'Rio de Janeiro', stateOrCountry: 'RJ - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'SDU', name: 'Aeroporto Santos Dumont', city: 'Rio de Janeiro', stateOrCountry: 'RJ - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'BEL', name: 'Aeroporto Intl. Val-de-Cans / Porto de Belém', city: 'Belém', stateOrCountry: 'PA - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'STM', name: 'Santarém (Aeroporto e Terminal Fluvial)', city: 'Santarém', stateOrCountry: 'PA - Brasil', type: 'CITY'),
    LocationPoint(code: 'PVH', name: 'Porto Velho (Aeroporto e Porto)', city: 'Porto Velho', stateOrCountry: 'RO - Brasil', type: 'CITY'),
    LocationPoint(code: 'MCP', name: 'Macapá (Aeroporto e Porto de Santana)', city: 'Macapá', stateOrCountry: 'AP - Brasil', type: 'CITY'),
    LocationPoint(code: 'TFF', name: 'Tefé (Terminal Fluvial e Aeroporto)', city: 'Tefé', stateOrCountry: 'AM - Brasil', type: 'CITY'),
    LocationPoint(code: 'PIN', name: 'Parintins (Porto e Aeroporto)', city: 'Parintins', stateOrCountry: 'AM - Brasil', type: 'CITY'),
    LocationPoint(code: 'TBT', name: 'Tabatinga (Alto Solimões)', city: 'Tabatinga', stateOrCountry: 'AM - Brasil', type: 'CITY'),
    LocationPoint(code: 'BSB', name: 'Aeroporto Intl. Juscelino Kubitschek', city: 'Brasília', stateOrCountry: 'DF - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'CNF', name: 'Aeroporto Intl. de Confins', city: 'Belo Horizonte', stateOrCountry: 'MG - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'SSA', name: 'Aeroporto Intl. Luís Eduardo Magalhães', city: 'Salvador', stateOrCountry: 'BA - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'REC', name: 'Aeroporto Intl. dos Guararapes', city: 'Recife', stateOrCountry: 'PE - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'FOR', name: 'Aeroporto Intl. Pinto Martins', city: 'Fortaleza', stateOrCountry: 'CE - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'CWB', name: 'Aeroporto Intl. Afonso Pena', city: 'Curitiba', stateOrCountry: 'PR - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'POA', name: 'Aeroporto Intl. Salgado Filho', city: 'Porto Alegre', stateOrCountry: 'RS - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'FLN', name: 'Aeroporto Intl. Hercílio Luz', city: 'Florianópolis', stateOrCountry: 'SC - Brasil', type: 'AIRPORT'),
    LocationPoint(code: 'LIS', name: 'Aeroporto Humberto Delgado', city: 'Lisboa', stateOrCountry: 'Portugal', type: 'AIRPORT'),
    LocationPoint(code: 'MIA', name: 'Miami International Airport', city: 'Miami', stateOrCountry: 'Estados Unidos', type: 'AIRPORT'),
    LocationPoint(code: 'EZE', name: 'Aeroporto Intl. Ministro Pistarini', city: 'Buenos Aires', stateOrCountry: 'Argentina', type: 'AIRPORT'),
  ];

  String _resolveEffectiveProxyUrl(String customProxyUrl) {
    if (AppConfig.isValidProxyUrl(AppConfig.defaultProxyBaseUrl)) {
      return AppConfig.defaultProxyBaseUrl.trim();
    }
    return customProxyUrl.trim();
  }

  Future<List<LocationPoint>> searchLocations({
    required String query,
    required String proxyUrl,
    required TravelCategory category,
  }) async {
    final normalized = query.trim().toLowerCase();
    final localMatches = normalized.isEmpty
        ? List<LocationPoint>.from(curatedBrazilianLocations)
        : curatedBrazilianLocations.where((loc) {
            return loc.city.toLowerCase().contains(normalized) ||
                loc.code.toLowerCase().contains(normalized) ||
                loc.name.toLowerCase().contains(normalized) ||
                loc.stateOrCountry.toLowerCase().contains(normalized);
          }).toList();

    final effectiveProxy = _resolveEffectiveProxyUrl(proxyUrl);
    if (normalized.length < 2 || !AppConfig.isValidProxyUrl(effectiveProxy)) {
      return localMatches;
    }

    try {
      final cleanBase = effectiveProxy.replaceAll(RegExp(r'/+$'), '');
      final uri = Uri.parse('$cleanBase/api/places').replace(
        queryParameters: {'q': query.trim()},
      );
      final resp = await http.get(uri).timeout(const Duration(seconds: 10));
      if (resp.statusCode == 200) {
        final decoded = jsonDecode(resp.body);
        final rawPlaces = (decoded is Map ? decoded['places'] : null) as List? ?? [];
        final apiPoints = <LocationPoint>[];

        for (final p in rawPlaces) {
          if (p is! Map<String, dynamic>) continue;
          final airportMap = p['airport'] is Map<String, dynamic>
              ? p['airport'] as Map<String, dynamic>
              : null;
          final code = (airportMap?['id'] ?? p['id'] ?? p['code'] ?? '')
              .toString()
              .trim();
          final title = (airportMap?['name'] ?? p['name'] ?? p['title'] ?? '')
              .toString()
              .trim();
          final city = (p['city'] ?? title).toString().trim();
          final country = (p['country'] ?? p['region'] ?? '').toString().trim();

          if (title.isNotEmpty || code.isNotEmpty) {
            apiPoints.add(
              LocationPoint(
                code: code.length <= 4 ? code.toUpperCase() : '',
                name: title.isNotEmpty ? title : city,
                city: city.isNotEmpty ? city : title,
                stateOrCountry: country.isNotEmpty ? country : 'Mundo',
                type: airportMap != null ? 'AIRPORT' : 'CITY',
              ),
            );
          }
        }

        final seenKeys = localMatches.map((e) => '${e.code}_${e.city}').toSet();
        for (final pt in apiPoints) {
          final k = '${pt.code}_${pt.city}';
          if (!seenKeys.contains(k)) {
            seenKeys.add(k);
            localMatches.add(pt);
          }
        }
      }
    } catch (_) {}

    return localMatches;
  }

  Future<SearchResultBundle> searchOffers({
    required SearchQuery query,
    required String proxyUrl,
    required String currency,
  }) async {
    final effectiveProxy = _resolveEffectiveProxyUrl(proxyUrl);

    if (query.category == TravelCategory.flights) {
      if (AppConfig.isValidProxyUrl(effectiveProxy)) {
        final liveOffers = await _flightClient.searchFlights(
          proxyBaseUrl: effectiveProxy,
          query: query,
          currency: currency,
        );
        return SearchResultBundle(
          offers: liveOffers,
          isLiveData: true,
        );
      } else {
        final portalOptions =
            ExternalRedirectBuilder.buildOfficialPortalOptions(query);
        return SearchResultBundle(
          offers: portalOptions,
          isLiveData: false,
          infoBannerMessage:
              'Configure a URL do seu Cloudflare Worker em Ajustes ou lib/app/app_config.dart para ver voos ao vivo. Enquanto isso, abra os portais oficiais abaixo.',
        );
      }
    }

    if (query.category == TravelCategory.stays &&
        AppConfig.isValidProxyUrl(effectiveProxy)) {
      try {
        final stayOffers = await _staysClient.searchStays(
          proxyBaseUrl: effectiveProxy,
          query: query,
          currency: currency,
        );
        if (stayOffers.isNotEmpty) {
          return SearchResultBundle(
            offers: stayOffers,
            isLiveData: true,
          );
        }
      } catch (_) {}
    }

    final portalOptions =
        ExternalRedirectBuilder.buildOfficialPortalOptions(query);
    return SearchResultBundle(
      offers: portalOptions,
      isLiveData: false,
      infoBannerMessage:
          'Para ${query.category.fullTitle.toLowerCase()}, o VIAJOU abre os portais oficiais diretamente com seus dados de viagem.',
    );
  }

  List<TravelBenefit> getOfficialTravelBenefits() {
    return const [
      TravelBenefit(
        id: 'id_jovem',
        title: 'ID Jovem — Identidade Jovem',
        subtitle: 'Gratuidade e 50% de desconto em viagens interestaduais',
        legalBasis: 'Decreto nº 8.537/2015 e Estatuto da Juventude (Lei nº 12.852/2013)',
        discountDetails:
            '2 vagas gratuitas por veículo/embarcação e 2 vagas com 50% de desconto (após esgotadas as gratuitas) no transporte interestadual convencional (rodoviário, ferroviário e aquaviário).',
        requirements: [
          'Ter idade entre 15 e 29 anos.',
          'Pertencer a família com renda mensal de até 2 salários mínimos.',
          'Estar inscrito no Cadastro Único (CadÚnico) com dados atualizados há menos de 24 meses.',
        ],
        requiredDocuments: [
          'Carteira ID Jovem válida (gerada pelo app ou site oficial com QR Code).',
          'Documento oficial de identificação com foto.',
          'Número de Identificação Social (NIS).',
        ],
        howToRequest:
            'Emita sua carteira gratuitamente no portal oficial da ID Jovem usando seu NIS. Solicite o Bilhete de Viagem do Jovem diretamente no guichê da empresa com antecedência mínima de 3 horas em relação ao horário de partida.',
        officialPortalUrl: 'https://idjovem.juventude.gov.br/',
        importantNotice:
            'A concessão depende da disponibilidade das vagas reservadas por lei em cada horário e não cobre taxas de embarque ou pedágio.',
      ),
      TravelBenefit(
        id: 'idoso_interestadual',
        title: 'Benefício da Pessoa Idosa',
        subtitle: 'Gratuidade ou 50% de desconto no transporte interestadual',
        legalBasis: 'Estatuto da Pessoa Idosa (Lei nº 10.741/2003, Art. 40) e Resolução ANTT',
        discountDetails:
            '2 vagas gratuitas por veículo no serviço convencional interestadual. Esgotadas essas vagas, garante desconto mínimo de 50% no valor da passagem.',
        requirements: [
          'Ter 60 anos de idade ou mais.',
          'Possuir renda individual igual ou inferior a 2 salários mínimos.',
        ],
        requiredDocuments: [
          'Documento oficial com foto e data de nascimento.',
          'Comprovante de renda (Carteira de Trabalho, contracheque, extrato INSS ou Carteira da Pessoa Idosa).',
        ],
        howToRequest:
            'Compareça ao ponto de venda da empresa transportadora com antecedência mínima de 3 horas para viagens de até 500 km, ou 6 horas para distâncias acima de 500 km.',
        officialPortalUrl: 'https://www.gov.br/antt/pt-br/assuntos/passageiros/idosos',
        importantNotice:
            'Válido para transporte rodoviário, ferroviário e aquaviário interestadual convencional. Não se aplica a passagens aéreas nem ônibus leito/executivo.',
      ),
      TravelBenefit(
        id: 'passe_livre_pcd',
        title: 'Passe Livre Interestadual (PcD)',
        subtitle: 'Gratuidade para pessoas com deficiência comprovadamente carentes',
        legalBasis: 'Lei nº 8.899/1994 e Decreto nº 3.691/2000',
        discountDetails:
            'Gratuidade integral na tarifa de transporte coletivo interestadual (ônibus, trem e barco) para o beneficiário e, quando comprovada necessidade, para seu acompanhante.',
        requirements: [
          'Possuir deficiência física, mental, auditiva, visual, múltipla ou doença renal crônica.',
          'Possuir renda familiar mensal per capita de até 1 salário mínimo.',
        ],
        requiredDocuments: [
          'Credencial oficial do Passe Livre emitida pelo Ministério dos Transportes.',
          'Documento oficial de identidade com foto.',
        ],
        howToRequest:
            'O cadastro e envio do laudo médico são feitos pela internet no portal Gov.br. Após aprovação, reserve o bilhete na empresa com pelo menos 3 horas de antecedência.',
        officialPortalUrl: 'https://www.gov.br/transportes/pt-br/assuntos/transporte-terrestre/passe-livre',
        importantNotice:
            'A credencial deve estar dentro do prazo de validade no momento do embarque.',
      ),
      TravelBenefit(
        id: 'transporte_aquaviario_antaq',
        title: 'Direitos no Transporte Fluvial (ANTAQ)',
        subtitle: 'Regras de gratuidade e meia-passagem em barcos e lanchas',
        legalBasis: 'Resolução ANTAQ nº 912 e legislação federal aplicável',
        discountDetails:
            'Garante reserva de assentos/espaços gratuitos ou com desconto para idosos, jovens de baixa renda (ID Jovem) e beneficiários do Passe Livre nas linhas interestaduais regulares.',
        requirements: [
          'Atender aos critérios legais específicos da modalidade (Idoso, ID Jovem ou Passe Livre).',
          'Embarcar em linha regular interestadual autorizada pela ANTAQ.',
        ],
        requiredDocuments: [
          'Documento oficial com foto e comprovação do respectivo programa social.',
        ],
        howToRequest:
            'Solicite a reserva antecipada diretamente no guichê da empresa de navegação ou agência portuária autorizada.',
        officialPortalUrl: 'https://www.gov.br/antaq/pt-br',
        importantNotice:
            'Linhas exclusivamente intermunicipais (dentro do mesmo estado) seguem a legislação estadual específica de cada unidade federativa.',
      ),
    ];
  }
}
