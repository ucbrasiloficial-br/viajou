class AppConfig {
  static const String appName = 'VIAJOU';
  static const String slogan = 'O mundo em um clique.';
  static const String appVersion = '1.0.0';

  /// Endpoint oficial do proxy Cloudflare Worker do VIAJOU.
  static const String defaultProxyBaseUrl =
      'https://viajou-api.romariokhalifa0.workers.dev';

  static bool isValidProxyUrl(String url) {
    final trimmed = url.trim();
    if (trimmed.isEmpty) return false;
    if (trimmed.contains('SEU-WORKER')) return false;
    return trimmed.startsWith('https://');
  }
}
