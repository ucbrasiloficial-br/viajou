class AppConfig {
  static const String appName = 'VIAJOU';
  static const String slogan = 'Encontre. Compare. Escolha. Viaje.';
  static const String appVersion = '1.0.0';

  /// Cole aqui a URL do seu Cloudflare Worker após fazer deploy:
  static const String defaultProxyBaseUrl = 'https://SEU-WORKER.workers.dev';

  static bool isValidProxyUrl(String url) {
    final trimmed = url.trim();
    return trimmed.startsWith('https://') && !trimmed.contains('SEU-WORKER');
  }
}
