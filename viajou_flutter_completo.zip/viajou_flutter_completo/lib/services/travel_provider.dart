import 'package:flutter/foundation.dart';
import '../models/checklist_item.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_benefit.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';
import '../repositories/travel_repository.dart';
import '../storage/local_storage_service.dart';

enum OfferSortOrder { recommended, cheapest, fastest }

class TravelProvider extends ChangeNotifier {
  final LocalStorageService _storage = LocalStorageService();
  final TravelRepository _repository = TravelRepository();

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  String _currency = 'BRL';
  String get currency => _currency;

  bool _notificationsEnabled = true;
  bool get notificationsEnabled => _notificationsEnabled;

  String _proxyUrl = '';
  String get proxyUrl => _proxyUrl;

  List<TravelOffer> _favoriteOffers = [];
  List<TravelOffer> get favoriteOffers => _favoriteOffers;

  List<LocationPoint> _favoriteDestinations = [];
  List<LocationPoint> get favoriteDestinations => _favoriteDestinations;

  List<SearchQuery> _searchHistory = [];
  List<SearchQuery> get searchHistory => _searchHistory;

  List<ChecklistItem> _checklist = [];
  List<ChecklistItem> get checklist => _checklist;

  List<Map<String, dynamic>> _priceAlerts = [];
  List<Map<String, dynamic>> get priceAlerts => _priceAlerts;

  bool _isLoadingResults = false;
  bool get isLoadingResults => _isLoadingResults;

  String? _searchError;
  String? get searchError => _searchError;

  SearchQuery? _activeQuery;
  SearchQuery? get activeQuery => _activeQuery;

  List<TravelOffer> _rawResults = [];
  bool _resultsAreLive = false;
  bool get resultsAreLive => _resultsAreLive;

  String? _resultsBannerMessage;
  String? get resultsBannerMessage => _resultsBannerMessage;

  OfferSortOrder _sortOrder = OfferSortOrder.recommended;
  OfferSortOrder get sortOrder => _sortOrder;

  String? _selectedProviderFilter;
  String? get selectedProviderFilter => _selectedProviderFilter;

  int? _maxStopsFilter;
  int? get maxStopsFilter => _maxStopsFilter;

  double? _maxPriceFilter;
  double? get maxPriceFilter => _maxPriceFilter;

  final List<TravelOffer> _comparisonBasket = [];
  List<TravelOffer> get comparisonBasket => List.unmodifiable(_comparisonBasket);

  Future<void> initialize() async {
    _currency = await _storage.getCurrency();
    _notificationsEnabled = await _storage.getNotificationsEnabled();
    _proxyUrl = await _storage.getProxyUrl();
    _favoriteOffers = await _storage.getFavoriteOffers();
    _favoriteDestinations = await _storage.getFavoriteDestinations();
    _searchHistory = await _storage.getSearchHistory();
    _checklist = await _storage.getChecklist();
    _priceAlerts = await _storage.getPriceAlerts();
    _isInitialized = true;
    notifyListeners();
  }

  List<TravelOffer> get filteredAndSortedResults {
    var list = List<TravelOffer>.from(_rawResults);

    if (_selectedProviderFilter != null && _selectedProviderFilter!.isNotEmpty) {
      list = list.where((e) => e.providerName == _selectedProviderFilter).toList();
    }
    if (_maxStopsFilter != null) {
      list = list.where((e) => e.stops <= _maxStopsFilter!).toList();
    }
    if (_maxPriceFilter != null) {
      list = list.where((e) => e.price == null || e.price! <= _maxPriceFilter!).toList();
    }

    switch (_sortOrder) {
      case OfferSortOrder.cheapest:
        list.sort((a, b) {
          if (a.price == null && b.price == null) return 0;
          if (a.price == null) return 1;
          if (b.price == null) return -1;
          return a.price!.compareTo(b.price!);
        });
        break;
      case OfferSortOrder.fastest:
        list.sort((a, b) {
          if (a.duration == null && b.duration == null) return 0;
          if (a.duration == null) return 1;
          if (b.duration == null) return -1;
          return a.duration!.compareTo(b.duration!);
        });
        break;
      case OfferSortOrder.recommended:
        break;
    }

    return list;
  }

  List<String> get availableProviders {
    return _rawResults.map((e) => e.providerName).toSet().toList()..sort();
  }

  double? get lowestCurrentPrice {
    final priced = _rawResults.where((e) => e.price != null).toList();
    if (priced.isEmpty) return null;
    priced.sort((a, b) => a.price!.compareTo(b.price!));
    return priced.first.price;
  }

  void setSortOrder(OfferSortOrder order) {
    _sortOrder = order;
    notifyListeners();
  }

  void setFilters({String? provider, int? maxStops, double? maxPrice}) {
    _selectedProviderFilter = provider;
    _maxStopsFilter = maxStops;
    _maxPriceFilter = maxPrice;
    notifyListeners();
  }

  void clearFilters() {
    _selectedProviderFilter = null;
    _maxStopsFilter = null;
    _maxPriceFilter = null;
    notifyListeners();
  }

  bool isInComparison(String offerId) {
    return _comparisonBasket.any((e) => e.id == offerId);
  }

  String? toggleComparisonOffer(TravelOffer offer) {
    if (isInComparison(offer.id)) {
      _comparisonBasket.removeWhere((e) => e.id == offer.id);
      notifyListeners();
      return null;
    }
    if (_comparisonBasket.length >= 3) {
      return 'Você pode comparar no máximo 3 opções por vez.';
    }
    _comparisonBasket.add(offer);
    notifyListeners();
    return null;
  }

  void clearComparison() {
    _comparisonBasket.clear();
    notifyListeners();
  }

  Future<List<LocationPoint>> autocompleteLocations(
    String keyword,
    TravelCategory category,
  ) {
    return _repository.searchLocations(
      query: keyword,
      proxyUrl: _proxyUrl,
      category: category,
    );
  }

  Future<void> shiftActiveSearchDate(int daysDelta) async {
    final current = _activeQuery;
    if (current == null) return;
    final shiftedDeparture = current.departureDate.add(Duration(days: daysDelta));
    final today = DateTime.now();
    final minDate = DateTime(today.year, today.month, today.day);
    if (shiftedDeparture.isBefore(minDate)) return;

    final shiftedReturn = current.returnDate?.add(Duration(days: daysDelta));
    final updated = SearchQuery(
      id: '${DateTime.now().millisecondsSinceEpoch}',
      category: current.category,
      origin: current.origin,
      destination: current.destination,
      departureDate: shiftedDeparture,
      returnDate: shiftedReturn,
      isRoundTrip: current.isRoundTrip,
      passengers: current.passengers,
      travelClass: current.travelClass,
    );
    await executeSearch(updated);
  }

  Future<void> executeSearch(SearchQuery query) async {
    _activeQuery = query;
    _isLoadingResults = true;
    _searchError = null;
    _rawResults = [];
    _comparisonBasket.clear();
    clearFilters();
    _sortOrder = OfferSortOrder.recommended;
    notifyListeners();

    _searchHistory.removeWhere((h) =>
        h.category == query.category &&
        h.origin?.city == query.origin?.city &&
        h.destination.city == query.destination.city);
    _searchHistory.insert(0, query);
    await _storage.saveSearchHistory(_searchHistory);

    try {
      final bundle = await _repository.searchOffers(
        query: query,
        proxyUrl: _proxyUrl,
        currency: _currency,
      );
      _rawResults = bundle.offers;
      _resultsAreLive = bundle.isLiveData;
      _resultsBannerMessage = bundle.infoBannerMessage;

      // Atualizar alerta de preço monitorado se existir para esta rota
      final lowest = lowestCurrentPrice;
      if (lowest != null) {
        final routeKey =
            '${query.origin?.code ?? query.origin?.city ?? ''}_${query.destination.code.isNotEmpty ? query.destination.code : query.destination.city}';
        final idx = _priceAlerts.indexWhere((a) => a['routeKey'] == routeKey);
        if (idx >= 0) {
          _priceAlerts[idx]['lastPrice'] = lowest;
          _priceAlerts[idx]['checkedAt'] = DateTime.now().toIso8601String();
          await _storage.savePriceAlerts(_priceAlerts);
        }
      }
    } catch (e) {
      _searchError = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _isLoadingResults = false;
      notifyListeners();
    }
  }

  bool hasPriceAlertForActiveQuery() {
    final q = _activeQuery;
    if (q == null) return false;
    final routeKey =
        '${q.origin?.code ?? q.origin?.city ?? ''}_${q.destination.code.isNotEmpty ? q.destination.code : q.destination.city}';
    return _priceAlerts.any((a) => a['routeKey'] == routeKey);
  }

  Future<bool> togglePriceAlertForActiveQuery() async {
    final q = _activeQuery;
    if (q == null) return false;
    final routeKey =
        '${q.origin?.code ?? q.origin?.city ?? ''}_${q.destination.code.isNotEmpty ? q.destination.code : q.destination.city}';
    final existingIdx = _priceAlerts.indexWhere((a) => a['routeKey'] == routeKey);
    if (existingIdx >= 0) {
      _priceAlerts.removeAt(existingIdx);
      await _storage.savePriceAlerts(_priceAlerts);
      notifyListeners();
      return false;
    } else {
      _priceAlerts.insert(0, {
        'routeKey': routeKey,
        'label': q.origin != null
            ? '${q.origin!.city} → ${q.destination.city}'
            : q.destination.city,
        'baselinePrice': lowestCurrentPrice,
        'lastPrice': lowestCurrentPrice,
        'currency': _currency,
        'createdAt': DateTime.now().toIso8601String(),
      });
      await _storage.savePriceAlerts(_priceAlerts);
      notifyListeners();
      return true;
    }
  }

  Future<void> removePriceAlert(String routeKey) async {
    _priceAlerts.removeWhere((a) => a['routeKey'] == routeKey);
    await _storage.savePriceAlerts(_priceAlerts);
    notifyListeners();
  }

  Future<void> toggleChecklistItem(String id) async {
    _checklist = _checklist.map((item) {
      if (item.id == id) {
        return item.copyWith(completed: !item.completed);
      }
      return item;
    }).toList();
    await _storage.saveChecklist(_checklist);
    notifyListeners();
  }

  Future<void> addChecklistItem(String title, String tag) async {
    final trimmed = title.trim();
    if (trimmed.isEmpty) return;
    _checklist.add(
      ChecklistItem(
        id: 'chk_${DateTime.now().millisecondsSinceEpoch}',
        title: trimmed,
        categoryTag: tag,
      ),
    );
    await _storage.saveChecklist(_checklist);
    notifyListeners();
  }

  Future<void> removeChecklistItem(String id) async {
    _checklist.removeWhere((e) => e.id == id);
    await _storage.saveChecklist(_checklist);
    notifyListeners();
  }

  bool isOfferFavorite(String offerId) {
    return _favoriteOffers.any((o) => o.id == offerId);
  }

  Future<void> toggleFavoriteOffer(TravelOffer offer) async {
    if (isOfferFavorite(offer.id)) {
      _favoriteOffers.removeWhere((o) => o.id == offer.id);
    } else {
      _favoriteOffers.insert(0, offer);
    }
    await _storage.saveFavoriteOffers(_favoriteOffers);
    notifyListeners();
  }

  bool isDestinationFavorite(String cityOrCode) {
    return _favoriteDestinations.any((d) => d.displayLabel == cityOrCode);
  }

  Future<void> toggleFavoriteDestination(LocationPoint point) async {
    if (isDestinationFavorite(point.displayLabel)) {
      _favoriteDestinations.removeWhere((d) => d.displayLabel == point.displayLabel);
    } else {
      _favoriteDestinations.insert(0, point);
    }
    await _storage.saveFavoriteDestinations(_favoriteDestinations);
    notifyListeners();
  }

  Future<void> removeHistoryItem(String id) async {
    _searchHistory.removeWhere((h) => h.id == id);
    await _storage.saveSearchHistory(_searchHistory);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    _searchHistory.clear();
    await _storage.saveSearchHistory(_searchHistory);
    notifyListeners();
  }

  Future<void> updateCurrency(String newCurrency) async {
    _currency = newCurrency;
    await _storage.setCurrency(newCurrency);
    notifyListeners();
  }

  Future<void> updateNotifications(bool enabled) async {
    _notificationsEnabled = enabled;
    await _storage.setNotificationsEnabled(enabled);
    notifyListeners();
  }

  Future<void> updateProxyUrl(String url) async {
    _proxyUrl = url.trim();
    await _storage.setProxyUrl(_proxyUrl);
    notifyListeners();
  }

  List<TravelBenefit> get benefits => _repository.getOfficialTravelBenefits();
}
