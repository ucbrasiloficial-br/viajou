import 'package:flutter/foundation.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_benefit.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';
import '../repositories/travel_repository.dart';
import '../storage/local_storage_service.dart';

enum OfferSortOrder { recommended, cheapest, fastest }

class TravelProvider extends ChangeNotifier {
  final LocalStorageService _storage = LocalStorageService();
  final TravelRepository _repository = TravelRepository();

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  String _currency = 'BRL';
  String get currency => _currency;

  bool _notificationsEnabled = true;
  bool get notificationsEnabled => _notificationsEnabled;

  String _proxyUrl = '';
  String get proxyUrl => _proxyUrl;

  List<TravelOffer> _favoriteOffers = [];
  List<TravelOffer> get favoriteOffers => _favoriteOffers;

  List<LocationPoint> _favoriteDestinations = [];
  List<LocationPoint> get favoriteDestinations => _favoriteDestinations;

  List<SearchQuery> _searchHistory = [];
  List<SearchQuery> get searchHistory => _searchHistory;

  bool _isLoadingResults = false;
  bool get isLoadingResults => _isLoadingResults;

  String? _searchError;
  String? get searchError => _searchError;

  SearchQuery? _activeQuery;
  SearchQuery? get activeQuery => _activeQuery;

  List<TravelOffer> _rawResults = [];
  bool _resultsAreLive = false;
  bool get resultsAreLive => _resultsAreLive;

  String? _resultsBannerMessage;
  String? get resultsBannerMessage => _resultsBannerMessage;

  // Filtros e ordenação
  OfferSortOrder _sortOrder = OfferSortOrder.recommended;
  OfferSortOrder get sortOrder => _sortOrder;

  String? _selectedProviderFilter;
  String? get selectedProviderFilter => _selectedProviderFilter;

  int? _maxStopsFilter;
  int? get maxStopsFilter => _maxStopsFilter;

  double? _maxPriceFilter;
  double? get maxPriceFilter => _maxPriceFilter;

  Future<void> initialize() async {
    _currency = await _storage.getCurrency();
    _notificationsEnabled = await _storage.getNotificationsEnabled();
    _proxyUrl = await _storage.getProxyUrl();
    _favoriteOffers = await _storage.getFavoriteOffers();
    _favoriteDestinations = await _storage.getFavoriteDestinations();
    _searchHistory = await _storage.getSearchHistory();
    _isInitialized = true;
    notifyListeners();
  }

  List<TravelOffer> get filteredAndSortedResults {
    var list = List<TravelOffer>.from(_rawResults);

    if (_selectedProviderFilter != null && _selectedProviderFilter!.isNotEmpty) {
      list = list.where((e) => e.providerName == _selectedProviderFilter).toList();
    }
    if (_maxStopsFilter != null) {
      list = list.where((e) => e.stops <= _maxStopsFilter!).toList();
    }
    if (_maxPriceFilter != null) {
      list = list.where((e) => e.price == null || e.price! <= _maxPriceFilter!).toList();
    }

    switch (_sortOrder) {
      case OfferSortOrder.cheapest:
        list.sort((a, b) {
          if (a.price == null && b.price == null) return 0;
          if (a.price == null) return 1;
          if (b.price == null) return -1;
          return a.price!.compareTo(b.price!);
        });
        break;
      case OfferSortOrder.fastest:
        list.sort((a, b) {
          if (a.duration == null && b.duration == null) return 0;
          if (a.duration == null) return 1;
          if (b.duration == null) return -1;
          return a.duration!.compareTo(b.duration!);
        });
        break;
      case OfferSortOrder.recommended:
        break;
    }

    return list;
  }

  List<String> get availableProviders {
    return _rawResults.map((e) => e.providerName).toSet().toList()..sort();
  }

  void setSortOrder(OfferSortOrder order) {
    _sortOrder = order;
    notifyListeners();
  }

  void setFilters({String? provider, int? maxStops, double? maxPrice}) {
    _selectedProviderFilter = provider;
    _maxStopsFilter = maxStops;
    _maxPriceFilter = maxPrice;
    notifyListeners();
  }

  void clearFilters() {
    _selectedProviderFilter = null;
    _maxStopsFilter = null;
    _maxPriceFilter = null;
    notifyListeners();
  }

  Future<List<LocationPoint>> autocompleteLocations(
    String keyword,
    TravelCategory category,
  ) {
    return _repository.searchLocations(
      query: keyword,
      proxyUrl: _proxyUrl,
      category: category,
    );
  }

  Future<void> executeSearch(SearchQuery query) async {
    _activeQuery = query;
    _isLoadingResults = true;
    _searchError = null;
    _rawResults = [];
    clearFilters();
    _sortOrder = OfferSortOrder.recommended;
    notifyListeners();

    // Salva no histórico local
    _searchHistory.removeWhere((h) =>
        h.category == query.category &&
        h.origin?.city == query.origin?.city &&
        h.destination.city == query.destination.city);
    _searchHistory.insert(0, query);
    await _storage.saveSearchHistory(_searchHistory);

    try {
      final bundle = await _repository.searchOffers(
        query: query,
        proxyUrl: _proxyUrl,
        currency: _currency,
      );
      _rawResults = bundle.offers;
      _resultsAreLive = bundle.isLiveData;
      _resultsBannerMessage = bundle.infoBannerMessage;
    } catch (e) {
      _searchError = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _isLoadingResults = false;
      notifyListeners();
    }
  }

  bool isOfferFavorite(String offerId) {
    return _favoriteOffers.any((o) => o.id == offerId);
  }

  Future<void> toggleFavoriteOffer(TravelOffer offer) async {
    if (isOfferFavorite(offer.id)) {
      _favoriteOffers.removeWhere((o) => o.id == offer.id);
    } else {
      _favoriteOffers.insert(0, offer);
    }
    await _storage.saveFavoriteOffers(_favoriteOffers);
    notifyListeners();
  }

  bool isDestinationFavorite(String cityOrCode) {
    return _favoriteDestinations.any((d) => d.displayLabel == cityOrCode);
  }

  Future<void> toggleFavoriteDestination(LocationPoint point) async {
    if (isDestinationFavorite(point.displayLabel)) {
      _favoriteDestinations.removeWhere((d) => d.displayLabel == point.displayLabel);
    } else {
      _favoriteDestinations.insert(0, point);
    }
    await _storage.saveFavoriteDestinations(_favoriteDestinations);
    notifyListeners();
  }

  Future<void> removeHistoryItem(String id) async {
    _searchHistory.removeWhere((h) => h.id == id);
    await _storage.saveSearchHistory(_searchHistory);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    _searchHistory.clear();
    await _storage.saveSearchHistory(_searchHistory);
    notifyListeners();
  }

  Future<void> updateCurrency(String newCurrency) async {
    _currency = newCurrency;
    await _storage.setCurrency(newCurrency);
    notifyListeners();
  }

  Future<void> updateNotifications(bool enabled) async {
    _notificationsEnabled = enabled;
    await _storage.setNotificationsEnabled(enabled);
    notifyListeners();
  }

  Future<void> updateProxyUrl(String url) async {
    _proxyUrl = url.trim();
    await _storage.setProxyUrl(_proxyUrl);
    notifyListeners();
  }

  List<TravelBenefit> get benefits => _repository.getOfficialTravelBenefits();
}
