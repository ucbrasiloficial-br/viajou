import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/premium_motion.dart';
import 'results_screen.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Histórico de Pesquisas'),
        actions: [
          if (provider.searchHistory.isNotEmpty)
            TextButton(
              onPressed: () => provider.clearHistory(),
              child: const Text('Limpar',
                  style: TextStyle(color: AppColors.lightPurple)),
            ),
        ],
      ),
      body: AmbientGlowBackdrop(
        child: provider.searchHistory.isEmpty
            ? const Center(
                child: Text(
                  'Seu histórico de pesquisas está vazio.',
                  style: TextStyle(color: AppColors.secondaryText),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
                itemCount: provider.searchHistory.length,
                itemBuilder: (context, index) {
                  final item = provider.searchHistory[index];
                  return StaggeredReveal(
                    index: index,
                    child: Dismissible(
                      key: Key(item.id),
                      direction: DismissDirection.endToStart,
                      onDismissed: (_) => provider.removeHistoryItem(item.id),
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        decoration: BoxDecoration(
                          color: AppColors.error,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(Icons.delete_rounded,
                            color: AppColors.white),
                      ),
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: Icon(item.category.icon,
                              color: AppColors.lightPurple),
                          title: Text(
                            item.origin != null
                                ? '${item.origin!.city} → ${item.destination.city}'
                                : item.destination.city,
                            style: const TextStyle(
                                color: AppColors.white,
                                fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(
                            '${item.category.fullTitle} • ${AppFormatters.dateShort(item.departureDate)}',
                            style: const TextStyle(
                                color: AppColors.secondaryText, fontSize: 12),
                          ),
                          trailing: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                            ),
                            onPressed: () {
                              provider.executeSearch(item);
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (_) => const ResultsScreen()),
                              );
                            },
                            child: const Text('Repetir',
                                style: TextStyle(fontSize: 12)),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
