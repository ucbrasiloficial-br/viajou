import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/travel_offer.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/premium_motion.dart';

class DetailsScreen extends StatelessWidget {
  final TravelOffer offer;

  const DetailsScreen({super.key, required this.offer});

  Future<void> _openOfficialWebsite(BuildContext context) async {
    final uri = Uri.tryParse(offer.officialUrl);
    if (uri == null || !uri.isScheme('https')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Endereço de redirecionamento inválido.')),
      );
      return;
    }

    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Não foi possível abrir o navegador externo.')),
      );
    }
  }

  void _shareOffer() {
    final priceStr = AppFormatters.currency(offer.price, offer.currency);
    Share.share(
      'Encontrei esta viagem no VIAJOU:\n'
      '${offer.providerName} (${offer.originLabel} → ${offer.destinationLabel})\n'
      'Valor: $priceStr\n'
      'Confira no site oficial: ${offer.officialUrl}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final isFav = provider.isOfferFavorite(offer.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes da Viagem'),
        actions: [
          IconButton(
            onPressed: _shareOffer,
            icon: const Icon(Icons.share_rounded),
            tooltip: 'Compartilhar',
          ),
          IconButton(
            onPressed: () => provider.toggleFavoriteOffer(offer),
            icon: Icon(
              isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: isFav ? AppColors.lightPurple : AppColors.white,
            ),
            tooltip: 'Salvar nos favoritos',
          ),
        ],
      ),
      body: AmbientGlowBackdrop(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StaggeredReveal(
                index: 0,
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.darkPurple, AppColors.cardBackground],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: AppColors.primaryPurple.withValues(alpha: 0.8),
                      width: 1.4,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryPurple.withValues(alpha: 0.25),
                        blurRadius: 24,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.primaryPurple
                                  .withValues(alpha: 0.25),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(offer.category.icon,
                                color: AppColors.lightPurple, size: 26),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              offer.providerName,
                              style: const TextStyle(
                                color: AppColors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Text(
                        '${offer.originLabel} → ${offer.destinationLabel}',
                        style: const TextStyle(
                          color: AppColors.lightPurple,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        AppFormatters.currency(offer.price, offer.currency),
                        style: const TextStyle(
                          color: AppColors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              StaggeredReveal(
                index: 1,
                child: _DetailRow(
                    label: 'Categoria / Serviço', value: offer.cabinOrService),
              ),
              if (offer.departureTime != null)
                StaggeredReveal(
                  index: 2,
                  child: _DetailRow(
                    label: 'Partida',
                    value: AppFormatters.dateTimeFull(offer.departureTime!),
                  ),
                ),
              if (offer.arrivalTime != null)
                StaggeredReveal(
                  index: 3,
                  child: _DetailRow(
                    label: 'Chegada',
                    value: AppFormatters.dateTimeFull(offer.arrivalTime!),
                  ),
                ),
              if (offer.duration != null)
                StaggeredReveal(
                  index: 4,
                  child: _DetailRow(
                    label: 'Duração estimada',
                    value: AppFormatters.durationLabel(offer.duration),
                  ),
                ),
              StaggeredReveal(
                index: 5,
                child: _DetailRow(
                    label: 'Bagagem e Serviços', value: offer.baggageInfo),
              ),
              StaggeredReveal(
                index: 6,
                child: _DetailRow(
                    label: 'Regras e Condições', value: offer.rulesSummary),
              ),
              StaggeredReveal(
                index: 7,
                child: _DetailRow(
                    label: 'Fonte verificada', value: offer.dataSource),
              ),

              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.warning.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: AppColors.warning.withValues(alpha: 0.45)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.warning_amber_rounded, color: AppColors.warning),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Aviso: O VIAJOU não realiza vendas diretas. Preços, taxas e disponibilidade podem sofrer alteração no site oficial do fornecedor.',
                        style: TextStyle(color: AppColors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),
              PressableScale(
                onTap: () => _openOfficialWebsite(context),
                scaleFactor: 0.985,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primaryPurple, AppColors.neonViolet],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryPurple.withValues(alpha: 0.45),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.open_in_new_rounded, color: AppColors.white),
                      SizedBox(width: 10),
                      Text(
                        'VER PASSAGEM NO SITE OFICIAL',
                        style: TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style:
                  const TextStyle(color: AppColors.secondaryText, fontSize: 11)),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  color: AppColors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
