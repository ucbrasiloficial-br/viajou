import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/travel_offer.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';

class DetailsScreen extends StatelessWidget {
  final TravelOffer offer;

  const DetailsScreen({super.key, required this.offer});

  Future<void> _openOfficialWebsite(BuildContext context) async {
    final uri = Uri.tryParse(offer.officialUrl);
    if (uri == null || !uri.isScheme('https')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Endereço de redirecionamento inválido.')),
      );
      return;
    }

    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir o navegador externo.')),
      );
    }
  }

  void _shareOffer() {
    final priceStr = AppFormatters.currency(offer.price, offer.currency);
    Share.share(
      'Encontrei esta viagem no VIAJOU:\n'
      '${offer.providerName} (${offer.originLabel} → ${offer.destinationLabel})\n'
      'Valor: $priceStr\n'
      'Confira no site oficial: ${offer.officialUrl}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final isFav = provider.isOfferFavorite(offer.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes da Viagem'),
        actions: [
          IconButton(
            onPressed: _shareOffer,
            icon: const Icon(Icons.share_rounded),
            tooltip: 'Compartilhar',
          ),
          IconButton(
            onPressed: () => provider.toggleFavoriteOffer(offer),
            icon: Icon(
              isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: isFav ? AppColors.primaryPurple : AppColors.white,
            ),
            tooltip: 'Salvar nos favoritos',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.darkPurple, AppColors.cardBackground],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.primaryPurple),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(offer.category.icon, color: AppColors.lightPurple, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          offer.providerName,
                          style: const TextStyle(
                            color: AppColors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    '${offer.originLabel} → ${offer.destinationLabel}',
                    style: const TextStyle(
                      color: AppColors.lightPurple,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    AppFormatters.currency(offer.price, offer.currency),
                    style: const TextStyle(
                      color: AppColors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            _DetailRow(label: 'Categoria / Serviço', value: offer.cabinOrService),
            if (offer.departureTime != null)
              _DetailRow(
                label: 'Partida',
                value: AppFormatters.dateTimeFull(offer.departureTime!),
              ),
            if (offer.arrivalTime != null)
              _DetailRow(
                label: 'Chegada',
                value: AppFormatters.dateTimeFull(offer.arrivalTime!),
              ),
            if (offer.duration != null)
              _DetailRow(
                label: 'Duração estimada',
                value: AppFormatters.durationLabel(offer.duration),
              ),
            _DetailRow(label: 'Bagagem e Serviços', value: offer.baggageInfo),
            _DetailRow(label: 'Regras e Condições', value: offer.rulesSummary),
            _DetailRow(label: 'Fonte verificada', value: offer.dataSource),
            _DetailRow(
              label: 'Última atualização',
              value: AppFormatters.dateTimeFull(offer.fetchedAt),
            ),

            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.warning.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.warning.withValues(alpha: 0.5)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: AppColors.warning),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Aviso: O VIAJOU não realiza vendas diretas. Preços, taxas e disponibilidade podem sofrer alteração no site oficial do fornecedor.',
                      style: TextStyle(color: AppColors.white, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _openOfficialWebsite(context),
                icon: const Icon(Icons.open_in_new_rounded),
                label: const Text('VER PASSAGEM NO SITE OFICIAL'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: AppColors.secondaryText, fontSize: 11)),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  color: AppColors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
