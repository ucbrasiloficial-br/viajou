import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/travel_offer.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/premium_motion.dart';

class DetailsScreen extends StatelessWidget {
  final TravelOffer offer;

  const DetailsScreen({super.key, required this.offer});

  Future<void> _openOfficialWebsite(BuildContext context) async {
    final uri = Uri.tryParse(offer.officialUrl);
    if (uri == null || !uri.isScheme('https')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Endereço de redirecionamento inválido.')),
      );
      return;
    }

    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Não foi possível abrir o navegador externo.')),
      );
    }
  }

  void _shareOffer() {
    final priceStr = AppFormatters.currency(offer.price, offer.currency);
    Share.share(
      'VIAJOU — Cartão de Viagem:
'
      '${offer.providerName} (${offer.originLabel} → ${offer.destinationLabel})
'
      'Valor: $priceStr
'
      'Acesse no portal oficial: ${offer.officialUrl}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final isFav = provider.isOfferFavorite(offer.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(provider.tr('boarding_pass')),
        actions: [
          IconButton(
            onPressed: _shareOffer,
            icon: const Icon(Icons.share_rounded),
            tooltip: 'Compartilhar',
          ),
          IconButton(
            onPressed: () => provider.toggleFavoriteOffer(offer),
            icon: Icon(
              isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: isFav ? AppColors.lightPurple : AppColors.white,
            ),
            tooltip: 'Salvar nos favoritos',
          ),
        ],
      ),
      body: AmbientGlowBackdrop(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cartão de Embarque Digital (Boarding Pass UI)
              StaggeredReveal(
                index: 0,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.darkPurple, AppColors.cardBackground],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: AppColors.primaryPurple.withValues(alpha: 0.85),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryPurple.withValues(alpha: 0.28),
                        blurRadius: 24,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: AppColors.primaryPurple
                                        .withValues(alpha: 0.25),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(offer.category.icon,
                                      color: AppColors.lightPurple, size: 24),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        offer.providerName,
                                        style: const TextStyle(
                                          color: AppColors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                      if (offer.carrierCode.isNotEmpty)
                                        Text(
                                          'Voo / Código: ${offer.carrierCode}',
                                          style: const TextStyle(
                                            color: AppColors.lightPurple,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 18),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    offer.originLabel,
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Icon(
                                    offer.category.icon,
                                    color: AppColors.lightPurple,
                                    size: 26,
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    offer.destinationLabel,
                                    textAlign: TextAlign.end,
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      // Linha divisória estilo bilhete perfurado
                      Row(
                        children: [
                          Container(
                            width: 14,
                            height: 24,
                            decoration: const BoxDecoration(
                              color: AppColors.deepBlack,
                              borderRadius: BorderRadius.horizontal(
                                right: Radius.circular(14),
                              ),
                            ),
                          ),
                          Expanded(
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                final count = (constraints.maxWidth / 10).floor();
                                return Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: List.generate(
                                    count,
                                    (_) => Container(
                                      width: 5,
                                      height: 1.5,
                                      color: AppColors.lightPurple
                                          .withValues(alpha: 0.45),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          Container(
                            width: 14,
                            height: 24,
                            decoration: const BoxDecoration(
                              color: AppColors.deepBlack,
                              borderRadius: BorderRadius.horizontal(
                                left: Radius.circular(14),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'TARIFA ESTIMADA',
                                  style: TextStyle(
                                    color: AppColors.secondaryText,
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  AppFormatters.currency(
                                      offer.price, offer.currency),
                                  style: const TextStyle(
                                    color: AppColors.white,
                                    fontSize: 26,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: AppColors.elevatedGlass,
                                borderRadius: BorderRadius.circular(12),
                                border:
                                    Border.all(color: AppColors.cardBorder),
                              ),
                              child: Text(
                                offer.stops == 0
                                    ? 'DIRETO'
                                    : '${offer.stops} PARADA(S)',
                                style: const TextStyle(
                                  color: AppColors.lightPurple,
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (offer.price != null) ...[
                const SizedBox(height: 14),
                StaggeredReveal(
                  index: 1,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.cardBackground,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          provider.tr('currency_estimate'),
                          style: const TextStyle(
                            color: AppColors.lightPurple,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 12,
                          runSpacing: 6,
                          children: ['BRL', 'USD', 'EUR', 'GBP']
                              .where((c) => c != offer.currency)
                              .map((target) {
                            final converted = AppFormatters.convertAmount(
                              offer.price!,
                              offer.currency,
                              target,
                            );
                            return Text(
                              '≈ ${AppFormatters.currency(converted, target)}',
                              style: const TextStyle(
                                color: AppColors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 14),
              StaggeredReveal(
                index: 2,
                child: _DetailRow(
                    label: 'Categoria / Serviço', value: offer.cabinOrService),
              ),
              if (offer.departureTime != null)
                StaggeredReveal(
                  index: 3,
                  child: _DetailRow(
                    label: 'Partida',
                    value: AppFormatters.dateTimeFull(offer.departureTime!),
                  ),
                ),
              if (offer.arrivalTime != null)
                StaggeredReveal(
                  index: 4,
                  child: _DetailRow(
                    label: 'Chegada',
                    value: AppFormatters.dateTimeFull(offer.arrivalTime!),
                  ),
                ),
              if (offer.duration != null)
                StaggeredReveal(
                  index: 5,
                  child: _DetailRow(
                    label: 'Duração estimada',
                    value: AppFormatters.durationLabel(offer.duration),
                  ),
                ),
              StaggeredReveal(
                index: 6,
                child: _DetailRow(
                    label: 'Bagagem e Serviços', value: offer.baggageInfo),
              ),
              StaggeredReveal(
                index: 7,
                child: _DetailRow(
                    label: 'Regras e Condições', value: offer.rulesSummary),
              ),
              StaggeredReveal(
                index: 8,
                child: _DetailRow(
                    label: 'Fonte verificada', value: offer.dataSource),
              ),

              const SizedBox(height: 20),
              PressableScale(
                onTap: () => _openOfficialWebsite(context),
                scaleFactor: 0.985,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primaryPurple, AppColors.neonViolet],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryPurple.withValues(alpha: 0.45),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.open_in_new_rounded,
                          color: AppColors.white),
                      const SizedBox(width: 10),
                      Text(
                        provider.tr('open_official'),
                        style: const TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14.5,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style:
                  const TextStyle(color: AppColors.secondaryText, fontSize: 11)),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  color: AppColors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
