import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/offer_card.dart';
import '../widgets/premium_motion.dart';
import 'details_screen.dart';
import 'search_screen.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Favoritos'),
          bottom: const TabBar(
            indicatorColor: AppColors.primaryPurple,
            labelColor: AppColors.lightPurple,
            unselectedLabelColor: AppColors.secondaryText,
            tabs: [
              Tab(text: 'Viagens Salvas'),
              Tab(text: 'Destinos'),
            ],
          ),
        ),
        body: AmbientGlowBackdrop(
          child: TabBarView(
            children: [
              provider.favoriteOffers.isEmpty
                  ? const Center(
                      child: Text(
                        'Nenhuma viagem salva ainda.',
                        style: TextStyle(color: AppColors.secondaryText),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
                      itemCount: provider.favoriteOffers.length,
                      itemBuilder: (context, index) {
                        final offer = provider.favoriteOffers[index];
                        return StaggeredReveal(
                          index: index,
                          child: OfferCard(
                            offer: offer,
                            isFavorite: true,
                            onToggleFavorite: () =>
                                provider.toggleFavoriteOffer(offer),
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => DetailsScreen(offer: offer),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
              provider.favoriteDestinations.isEmpty
                  ? const Center(
                      child: Text(
                        'Nenhum destino favoritado.',
                        style: TextStyle(color: AppColors.secondaryText),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
                      itemCount: provider.favoriteDestinations.length,
                      itemBuilder: (context, index) {
                        final dest = provider.favoriteDestinations[index];
                        return StaggeredReveal(
                          index: index,
                          child: Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              leading: const Icon(Icons.location_on_rounded,
                                  color: AppColors.lightPurple),
                              title: Text(dest.displayLabel,
                                  style: const TextStyle(color: AppColors.white)),
                              subtitle: Text(dest.stateOrCountry,
                                  style: const TextStyle(
                                      color: AppColors.secondaryText)),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline_rounded,
                                    color: AppColors.error),
                                onPressed: () =>
                                    provider.toggleFavoriteDestination(dest),
                              ),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      SearchScreen(initialDestination: dest),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
