import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app/app_config.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/premium_motion.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  void _showLegalDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.cardBorder),
        ),
        title: Text(title, style: const TextStyle(color: AppColors.white)),
        content: SingleChildScrollView(
          child: Text(content,
              style: const TextStyle(
                  color: AppColors.secondaryText, fontSize: 13, height: 1.45)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fechar',
                style: TextStyle(color: AppColors.lightPurple)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: AmbientGlowBackdrop(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            const StaggeredReveal(
              index: 0,
              child: Text(
                'Preferências Gerais',
                style: TextStyle(
                    color: AppColors.lightPurple, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(height: 10),
            StaggeredReveal(
              index: 1,
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.payments_rounded,
                      color: AppColors.lightPurple),
                  title: const Text('Moeda padrão',
                      style: TextStyle(color: AppColors.white)),
                  trailing: DropdownButton<String>(
                    value: provider.currency,
                    dropdownColor: AppColors.cardBackground,
                    underline: const SizedBox(),
                    items: const [
                      DropdownMenuItem(value: 'BRL', child: Text('Real (BRL)')),
                      DropdownMenuItem(value: 'USD', child: Text('Dólar (USD)')),
                      DropdownMenuItem(value: 'EUR', child: Text('Euro (€)')),
                    ],
                    onChanged: (val) {
                      if (val != null) provider.updateCurrency(val);
                    },
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 2,
              child: Card(
                child: SwitchListTile(
                  secondary: const Icon(Icons.notifications_active_rounded,
                      color: AppColors.lightPurple),
                  title: const Text('Notificações de oportunidades',
                      style: TextStyle(color: AppColors.white)),
                  value: provider.notificationsEnabled,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (val) => provider.updateNotifications(val),
                ),
              ),
            ),
            const SizedBox(height: 22),
            const StaggeredReveal(
              index: 3,
              child: Text(
                'Institucional e Legal',
                style: TextStyle(
                    color: AppColors.lightPurple, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(height: 10),
            StaggeredReveal(
              index: 4,
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined,
                      color: AppColors.lightPurple),
                  title: const Text('Política de Privacidade',
                      style: TextStyle(color: AppColors.white)),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: AppColors.secondaryText),
                  onTap: () => _showLegalDialog(
                    'Política de Privacidade',
                    'O VIAJOU não exige cadastro nem coleta dados pessoais sensíveis. Favoritos, histórico de pesquisa e preferências ficam armazenados exclusivamente no seu dispositivo.',
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 5,
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.description_outlined,
                      color: AppColors.lightPurple),
                  title: const Text('Termos de Uso',
                      style: TextStyle(color: AppColors.white)),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: AppColors.secondaryText),
                  onTap: () => _showLegalDialog(
                    'Termos de Uso',
                    'O VIAJOU atua exclusivamente como agregador e comparador de informações de viagem. A emissão de bilhetes, reservas e pagamentos ocorrem integralmente nos sites oficiais dos fornecedores.',
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 6,
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.info_outline_rounded,
                      color: AppColors.lightPurple),
                  title: const Text('Sobre o VIAJOU',
                      style: TextStyle(color: AppColors.white)),
                  subtitle: const Text(
                    'Versão ${AppConfig.appVersion} • ${AppConfig.slogan}',
                    style:
                        TextStyle(color: AppColors.secondaryText, fontSize: 12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
