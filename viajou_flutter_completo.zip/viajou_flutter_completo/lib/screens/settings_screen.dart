import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app/app_config.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _proxyController;

  @override
  void initState() {
    super.initState();
    _proxyController = TextEditingController(
      text: context.read<TravelProvider>().proxyUrl,
    );
  }

  @override
  void dispose() {
    _proxyController.dispose();
    super.dispose();
  }

  void _showLegalDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        title: Text(title, style: const TextStyle(color: AppColors.white)),
        content: SingleChildScrollView(
          child: Text(content,
              style: const TextStyle(color: AppColors.secondaryText, fontSize: 13)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fechar',
                style: TextStyle(color: AppColors.lightPurple)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Preferências Gerais',
            style: TextStyle(
                color: AppColors.lightPurple, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.payments_rounded,
                  color: AppColors.lightPurple),
              title: const Text('Moeda padrão',
                  style: TextStyle(color: AppColors.white)),
              trailing: DropdownButton<String>(
                value: provider.currency,
                dropdownColor: AppColors.cardBackground,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(value: 'BRL', child: Text('Real (R\$)')),
                  DropdownMenuItem(value: 'USD', child: Text('Dólar (US\$)')),
                  DropdownMenuItem(value: 'EUR', child: Text('Euro (€)')),
                ],
                onChanged: (val) {
                  if (val != null) provider.updateCurrency(val);
                },
              ),
            ),
          ),
          Card(
            child: SwitchListTile(
              secondary: const Icon(Icons.notifications_active_rounded,
                  color: AppColors.lightPurple),
              title: const Text('Notificações de oportunidades',
                  style: TextStyle(color: AppColors.white)),
              value: provider.notificationsEnabled,
              activeThumbColor: AppColors.primaryPurple,
              onChanged: (val) => provider.updateNotifications(val),
            ),
          ),

          const SizedBox(height: 22),
          const Text(
            'Conexão com Backend (Cloudflare Worker)',
            style: TextStyle(
                color: AppColors.lightPurple, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'URL do Worker de APIs Reais',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Insira o endereço https:// do seu Cloudflare Worker para ativar voos em tempo real.',
                    style: TextStyle(
                        color: AppColors.secondaryText, fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _proxyController,
                    decoration: const InputDecoration(
                      hintText: 'https://viajou-api.seu-usuario.workers.dev',
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        provider.updateProxyUrl(_proxyController.text);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Endpoint atualizado com sucesso!')),
                        );
                      },
                      child: const Text('Salvar Endpoint'),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 22),
          const Text(
            'Institucional e Legal',
            style: TextStyle(
                color: AppColors.lightPurple, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.privacy_tip_outlined,
                  color: AppColors.lightPurple),
              title: const Text('Política de Privacidade',
                  style: TextStyle(color: AppColors.white)),
              onTap: () => _showLegalDialog(
                'Política de Privacidade',
                'O VIAJOU não exige cadastro nem coleta dados pessoais sensíveis. Favoritos, histórico de pesquisa e preferências ficam armazenados exclusivamente no seu dispositivo.',
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.description_outlined,
                  color: AppColors.lightPurple),
              title: const Text('Termos de Uso',
                  style: TextStyle(color: AppColors.white)),
              onTap: () => _showLegalDialog(
                'Termos de Uso',
                'O VIAJOU atua exclusivamente como agregador e comparador de informações de viagem. A emissão de bilhetes, reservas e pagamentos ocorrem integralmente nos sites oficiais dos fornecedores.',
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.info_outline_rounded, color: AppColors.lightPurple),
              title: const Text('Sobre o VIAJOU',
                  style: TextStyle(color: AppColors.white)),
              subtitle: const Text(
                'Versão ${AppConfig.appVersion} • ${AppConfig.slogan}',
                style: TextStyle(color: AppColors.secondaryText, fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
