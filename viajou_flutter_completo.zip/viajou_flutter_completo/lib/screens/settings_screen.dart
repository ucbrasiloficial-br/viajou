import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../app/app_config.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/premium_motion.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _proxyController;
  bool _testingConnection = false;
  String? _connectionStatus;
  bool _connectionOk = false;

  @override
  void initState() {
    super.initState();
    final currentProxy = context.read<TravelProvider>().proxyUrl;
    _proxyController = TextEditingController(
      text: currentProxy.isNotEmpty
          ? currentProxy
          : AppConfig.defaultProxyBaseUrl,
    );
  }

  @override
  void dispose() {
    _proxyController.dispose();
    super.dispose();
  }

  Future<void> _saveAndTestProxy() async {
    final raw = _proxyController.text.trim();
    final provider = context.read<TravelProvider>();
    await provider.updateProxyUrl(raw);

    if (!raw.startsWith('https://')) {
      setState(() {
        _connectionOk = false;
        _connectionStatus = 'A URL deve começar com https://';
      });
      return;
    }

    setState(() {
      _testingConnection = true;
      _connectionStatus = 'Testando conexão com o Worker...';
    });

    try {
      final cleanBase = raw.replaceAll(RegExp(r'/+$'), '');
      final uri = Uri.parse('$cleanBase/health');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      final data = jsonDecode(res.body);

      if (res.statusCode == 200 && data is Map) {
        final configured = data['configured'] == true;
        setState(() {
          _connectionOk = configured;
          _connectionStatus = configured
              ? 'Conectado! API real ativa e pronta para buscar voos e hotéis.'
              : 'Worker online, mas falta configurar SEARCHAPI_API_KEY nos Secrets do Cloudflare.';
        });
      } else {
        setState(() {
          _connectionOk = false;
          _connectionStatus = 'Worker respondeu com status ${res.statusCode}.';
        });
      }
    } catch (e) {
      setState(() {
        _connectionOk = false;
        _connectionStatus = 'Falha ao conectar: ${e.toString()}';
      });
    } finally {
      if (mounted) {
        setState(() => _testingConnection = false);
      }
    }
  }

  void _showLegalDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.cardBorder),
        ),
        title: Text(title, style: const TextStyle(color: AppColors.white)),
        content: SingleChildScrollView(
          child: Text(
            content,
            style: const TextStyle(
              color: AppColors.secondaryText,
              fontSize: 13,
              height: 1.45,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Fechar',
              style: TextStyle(color: AppColors.lightPurple),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: AmbientGlowBackdrop(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            const StaggeredReveal(
              index: 0,
              child: Text(
                'Conexão de Dados em Tempo Real',
                style: TextStyle(
                  color: AppColors.lightPurple,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 10),
            StaggeredReveal(
              index: 1,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'URL do Cloudflare Worker',
                      style: TextStyle(
                        color: AppColors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Cole aqui a URL do seu Worker (ex: https://viajou-api.seu-usuario.workers.dev) para buscar voos e hotéis reais.',
                      style: TextStyle(
                        color: AppColors.secondaryText,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _proxyController,
                      style: const TextStyle(color: AppColors.white, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'https://seu-worker.workers.dev',
                        prefixIcon: Icon(
                          Icons.cloud_done_rounded,
                          color: AppColors.lightPurple,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _testingConnection ? null : _saveAndTestProxy,
                        icon: _testingConnection
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: AppColors.white,
                                ),
                              )
                            : const Icon(Icons.sync_rounded),
                        label: Text(
                          _testingConnection
                              ? 'Testando...'
                              : 'Salvar e Testar Conexão',
                        ),
                      ),
                    ),
                    if (_connectionStatus != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        _connectionStatus!,
                        style: TextStyle(
                          color: _connectionOk
                              ? AppColors.success
                              : AppColors.warning,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),

            const SizedBox(height: 22),
            const StaggeredReveal(
              index: 2,
              child: Text(
                'Preferências Gerais',
                style: TextStyle(
                  color: AppColors.lightPurple,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 10),
            StaggeredReveal(
              index: 3,
              child: Card(
                child: ListTile(
                  leading: const Icon(
                    Icons.payments_rounded,
                    color: AppColors.lightPurple,
                  ),
                  title: const Text(
                    'Moeda padrão',
                    style: TextStyle(color: AppColors.white),
                  ),
                  trailing: DropdownButton<String>(
                    value: provider.currency,
                    dropdownColor: AppColors.cardBackground,
                    underline: const SizedBox(),
                    items: const [
                      DropdownMenuItem(value: 'BRL', child: Text('Real (BRL)')),
                      DropdownMenuItem(value: 'USD', child: Text('Dólar (USD)')),
                      DropdownMenuItem(value: 'EUR', child: Text('Euro (EUR)')),
                    ],
                    onChanged: (val) {
                      if (val != null) provider.updateCurrency(val);
                    },
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 4,
              child: Card(
                child: SwitchListTile(
                  secondary: const Icon(
                    Icons.notifications_active_rounded,
                    color: AppColors.lightPurple,
                  ),
                  title: const Text(
                    'Notificações de oportunidades',
                    style: TextStyle(color: AppColors.white),
                  ),
                  value: provider.notificationsEnabled,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (val) => provider.updateNotifications(val),
                ),
              ),
            ),

            const SizedBox(height: 22),
            const StaggeredReveal(
              index: 5,
              child: Text(
                'Institucional e Legal',
                style: TextStyle(
                  color: AppColors.lightPurple,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 10),
            StaggeredReveal(
              index: 6,
              child: Card(
                child: ListTile(
                  leading: const Icon(
                    Icons.privacy_tip_outlined,
                    color: AppColors.lightPurple,
                  ),
                  title: const Text(
                    'Política de Privacidade',
                    style: TextStyle(color: AppColors.white),
                  ),
                  trailing: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.secondaryText,
                  ),
                  onTap: () => _showLegalDialog(
                    'Política de Privacidade',
                    'O VIAJOU não exige cadastro nem coleta dados pessoais sensíveis. Favoritos, histórico de pesquisa e preferências ficam armazenados exclusivamente no seu dispositivo.',
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 7,
              child: Card(
                child: ListTile(
                  leading: const Icon(
                    Icons.description_outlined,
                    color: AppColors.lightPurple,
                  ),
                  title: const Text(
                    'Termos de Uso',
                    style: TextStyle(color: AppColors.white),
                  ),
                  trailing: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.secondaryText,
                  ),
                  onTap: () => _showLegalDialog(
                    'Termos de Uso',
                    'O VIAJOU atua exclusivamente como agregador e comparador de informações de viagem. A emissão de bilhetes, reservas e pagamentos ocorrem integralmente nos sites oficiais dos fornecedores.',
                  ),
                ),
              ),
            ),
            StaggeredReveal(
              index: 8,
              child: Card(
                child: ListTile(
                  leading: const Icon(
                    Icons.info_outline_rounded,
                    color: AppColors.lightPurple,
                  ),
                  title: const Text(
                    'Sobre o VIAJOU',
                    style: TextStyle(color: AppColors.white),
                  ),
                  subtitle: Text(
                    'Versão ${AppConfig.appVersion} • ${AppConfig.slogan}',
                    style: const TextStyle(
                      color: AppColors.secondaryText,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
