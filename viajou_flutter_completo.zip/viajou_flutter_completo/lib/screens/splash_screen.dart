import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/viajou_logo.dart';
import 'main_shell_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _introController;
  late final AnimationController _orbitController;
  late final Animation<double> _fadeAnim;
  late final Animation<double> _scaleAnim;
  Timer? _iconCycleTimer;
  int _activeStep = 0;

  static const List<_SplashStep> _steps = [
    _SplashStep(
      icon: Icons.flight_takeoff_rounded,
      label: 'Conectando rotas aéreas...',
    ),
    _SplashStep(
      icon: Icons.directions_bus_rounded,
      label: 'Buscando linhas rodoviárias...',
    ),
    _SplashStep(
      icon: Icons.directions_boat_rounded,
      label: 'Mapeando trajetos fluviais...',
    ),
    _SplashStep(
      icon: Icons.directions_car_rounded,
      label: 'Preparando sua próxima viagem...',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    _fadeAnim = CurvedAnimation(
      parent: _introController,
      curve: Curves.easeOutCubic,
    );
    _scaleAnim = Tween<double>(begin: 0.86, end: 1.0).animate(
      CurvedAnimation(
        parent: _introController,
        curve: Curves.easeOutBack,
      ),
    );

    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();

    _introController.forward();

    _iconCycleTimer = Timer.periodic(const Duration(milliseconds: 950), (_) {
      if (!mounted) return;
      setState(() {
        _activeStep = (_activeStep + 1) % _steps.length;
      });
    });

    _bootApp();
  }

  Future<void> _bootApp() async {
    await Future.wait([
      context.read<TravelProvider>().initialize(),
      Future.delayed(const Duration(milliseconds: 3900)),
    ]);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const MainShellScreen(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
            ),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 520),
      ),
    );
  }

  @override
  void dispose() {
    _iconCycleTimer?.cancel();
    _introController.dispose();
    _orbitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentStep = _steps[_activeStep];

    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment(0, -0.15),
                radius: 1.25,
                colors: [
                  AppColors.darkPurple,
                  AppColors.deepBlack,
                ],
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _orbitController,
            builder: (context, _) {
              final pulse = 0.94 +
                  0.08 * math.sin(_orbitController.value * 2 * math.pi);
              return Transform.scale(
                scale: pulse,
                child: Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        AppColors.primaryPurple.withValues(alpha: 0.25),
                        AppColors.primaryPurple.withValues(alpha: 0.0),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          FadeTransition(
            opacity: _fadeAnim,
            child: ScaleTransition(
              scale: _scaleAnim,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const ViajouLogo(size: 40, showSlogan: true),
                    const SizedBox(height: 52),
                    SizedBox(
                      width: 112,
                      height: 112,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Anel externo pontilhado girando no sentido horário
                          AnimatedBuilder(
                            animation: _orbitController,
                            builder: (context, child) {
                              return Transform.rotate(
                                angle: _orbitController.value * 2 * math.pi,
                                child: child,
                              );
                            },
                            child: CustomPaint(
                              size: const Size(112, 112),
                              painter: _OrbitRingPainter(
                                color: AppColors.lightPurple,
                                accentColor: AppColors.primaryPurple,
                              ),
                            ),
                          ),
                          // Aviãozinho orbitando em torno do círculo
                          AnimatedBuilder(
                            animation: _orbitController,
                            builder: (context, child) {
                              final angle =
                                  _orbitController.value * 2 * math.pi;
                              const radius = 48.0;
                              return Transform.translate(
                                offset: Offset(
                                  radius * math.cos(angle),
                                  radius * math.sin(angle),
                                ),
                                child: Transform.rotate(
                                  angle: angle + (math.pi / 2),
                                  child: child,
                                ),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: AppColors.primaryPurple,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.neonViolet
                                        .withValues(alpha: 0.75),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.flight_rounded,
                                size: 14,
                                color: AppColors.white,
                              ),
                            ),
                          ),
                          // Núcleo central alternando entre avião, ônibus, barco e carro
                          Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  AppColors.elevatedGlass,
                                  AppColors.cardBackground,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppColors.lightPurple
                                    .withValues(alpha: 0.55),
                                width: 1.4,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryPurple
                                      .withValues(alpha: 0.35),
                                  blurRadius: 16,
                                ),
                              ],
                            ),
                            child: AnimatedSwitcher(
                              duration: const Duration(milliseconds: 360),
                              switchInCurve: Curves.easeOutBack,
                              switchOutCurve: Curves.easeInCubic,
                              transitionBuilder: (child, animation) {
                                return FadeTransition(
                                  opacity: animation,
                                  child: ScaleTransition(
                                    scale: animation,
                                    child: child,
                                  ),
                                );
                              },
                              child: Icon(
                                currentStep.icon,
                                key: ValueKey<int>(_activeStep),
                                color: AppColors.lightPurple,
                                size: 28,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Text(
                        currentStep.label,
                        key: ValueKey<String>(currentStep.label),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: AppColors.secondaryText,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: 170,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0.05, end: 1.0),
                          duration: const Duration(milliseconds: 3800),
                          curve: Curves.easeInOutCubic,
                          builder: (context, value, _) {
                            return LinearProgressIndicator(
                              value: value,
                              minHeight: 4,
                              backgroundColor: AppColors.cardBackground,
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                AppColors.lightPurple,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SplashStep {
  final IconData icon;
  final String label;

  const _SplashStep({required this.icon, required this.label});
}

class _OrbitRingPainter extends CustomPainter {
  final Color color;
  final Color accentColor;

  _OrbitRingPainter({required this.color, required this.accentColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 8;

    final trackPaint = Paint()
      ..color = accentColor.withValues(alpha: 0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.drawCircle(center, radius, trackPaint);

    final arcPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          color.withValues(alpha: 0.0),
          color.withValues(alpha: 0.9),
          accentColor,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 3.0;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      0,
      math.pi * 1.45,
      false,
      arcPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _OrbitRingPainter oldDelegate) => false;
}
