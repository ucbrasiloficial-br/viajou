import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/amazon_fluvial_route.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/premium_motion.dart';

class FluvialAndChecklistScreen extends StatefulWidget {
  final int initialTab;
  const FluvialAndChecklistScreen({super.key, this.initialTab = 0});

  @override
  State<FluvialAndChecklistScreen> createState() =>
      _FluvialAndChecklistScreenState();
}

class _FluvialAndChecklistScreenState extends State<FluvialAndChecklistScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final TextEditingController _newTaskController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.initialTab,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    _newTaskController.dispose();
    super.dispose();
  }

  void _showRouteDetails(AmazonFluvialRoute route) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 20, 22, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${route.originCity} → ${route.destinationCity}',
              style: const TextStyle(
                color: AppColors.white,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            _infoRow(Icons.anchor_rounded, 'Porto de saída', route.originPort),
            _infoRow(Icons.flag_rounded, 'Porto de chegada', route.destinationPort),
            _infoRow(Icons.directions_boat_rounded, 'Barco regional', route.boatDuration),
            _infoRow(Icons.bolt_rounded, 'Lancha rápida (Ajato)', route.speedboatDuration),
            _infoRow(Icons.event_repeat_rounded, 'Frequência', route.frequency),
            _infoRow(Icons.airline_seat_flat_rounded, 'Acomodações', route.accommodations),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.darkPurple.withValues(alpha: 0.55),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.primaryPurple),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.tips_and_updates_rounded,
                      color: AppColors.lightPurple, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      route.tips,
                      style: const TextStyle(
                        color: AppColors.white,
                        fontSize: 12.5,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.lightPurple),
          const SizedBox(width: 10),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontSize: 13, height: 1.35),
                children: [
                  TextSpan(
                    text: '$label: ',
                    style: const TextStyle(
                      color: AppColors.secondaryText,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextSpan(
                    text: value,
                    style: const TextStyle(
                      color: AppColors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final items = provider.checklist;
    final doneCount = items.where((e) => e.completed).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ferramentas do Viajante'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.lightPurple,
          labelColor: AppColors.white,
          unselectedLabelColor: AppColors.secondaryText,
          tabs: const [
            Tab(text: 'Guia Fluvial Amazônia'),
            Tab(text: 'Checklist de Viagem'),
          ],
        ),
      ),
      body: AmbientGlowBackdrop(
        child: TabBarView(
          controller: _tabController,
          children: [
            // Aba 1: Rotas Fluviais
            ListView.builder(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
              itemCount: AmazonFluvialRoute.routes.length,
              itemBuilder: (context, idx) {
                final r = AmazonFluvialRoute.routes[idx];
                return StaggeredReveal(
                  index: idx,
                  child: PressableScale(
                    onTap: () => _showRouteDetails(r),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.cardBackground,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppColors.cardBorder),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: AppColors.darkPurple,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(
                                  Icons.directions_boat_rounded,
                                  color: AppColors.lightPurple,
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  '${r.originCity} → ${r.destinationCity}',
                                  style: const TextStyle(
                                    color: AppColors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                              const Icon(
                                Icons.chevron_right_rounded,
                                color: AppColors.lightPurple,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Barco: ${r.boatDuration} • Lancha: ${r.speedboatDuration}',
                            style: const TextStyle(
                              color: AppColors.secondaryText,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            // Aba 2: Checklist Inteligente
            ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Progresso da bagagem & documentos',
                        style: TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      Text(
                        '$doneCount / ${items.length}',
                        style: const TextStyle(
                          color: AppColors.lightPurple,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _newTaskController,
                        style: const TextStyle(color: AppColors.white, fontSize: 13),
                        decoration: const InputDecoration(
                          hintText: 'Adicionar item (ex: Protetor solar)',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () {
                        provider.addChecklistItem(
                          _newTaskController.text,
                          'Personalizado',
                        );
                        _newTaskController.clear();
                      },
                      child: const Icon(Icons.add_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                ...items.map((item) {
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: CheckboxListTile(
                      value: item.completed,
                      activeColor: AppColors.primaryPurple,
                      onChanged: (_) => provider.toggleChecklistItem(item.id),
                      title: Text(
                        item.title,
                        style: TextStyle(
                          color: item.completed
                              ? AppColors.secondaryText
                              : AppColors.white,
                          decoration: item.completed
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                          fontSize: 13.5,
                        ),
                      ),
                      subtitle: Text(
                        item.categoryTag,
                        style: const TextStyle(
                          color: AppColors.lightPurple,
                          fontSize: 11,
                        ),
                      ),
                      secondary: IconButton(
                        icon: const Icon(
                          Icons.delete_outline_rounded,
                          color: AppColors.secondaryText,
                          size: 20,
                        ),
                        onPressed: () => provider.removeChecklistItem(item.id),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
