import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/offer_card.dart';
import 'details_screen.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  void _openFilterSheet(BuildContext context) {
    final provider = context.read<TravelProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        String? selectedProvider = provider.selectedProviderFilter;
        int? maxStops = provider.maxStopsFilter;

        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Filtrar Resultados',
                    style: TextStyle(
                      color: AppColors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Paradas / Escalas',
                      style: TextStyle(color: AppColors.secondaryText)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('Qualquer'),
                        selected: maxStops == null,
                        onSelected: (_) => setModalState(() => maxStops = null),
                      ),
                      ChoiceChip(
                        label: const Text('Direto'),
                        selected: maxStops == 0,
                        onSelected: (_) => setModalState(() => maxStops = 0),
                      ),
                      ChoiceChip(
                        label: const Text('Até 1 parada'),
                        selected: maxStops == 1,
                        onSelected: (_) => setModalState(() => maxStops = 1),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Companhia / Fornecedor',
                      style: TextStyle(color: AppColors.secondaryText)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String?>(
                    initialValue: selectedProvider,
                    dropdownColor: AppColors.cardBackground,
                    items: [
                      const DropdownMenuItem(value: null, child: Text('Todas as empresas')),
                      ...provider.availableProviders.map(
                        (p) => DropdownMenuItem(value: p, child: Text(p)),
                      ),
                    ],
                    onChanged: (v) => setModalState(() => selectedProvider = v),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {
                            provider.clearFilters();
                            Navigator.pop(ctx);
                          },
                          child: const Text('Limpar'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            provider.setFilters(
                              provider: selectedProvider,
                              maxStops: maxStops,
                            );
                            Navigator.pop(ctx);
                          },
                          child: const Text('Aplicar'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final query = provider.activeQuery;
    final offers = provider.filteredAndSortedResults;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              query != null
                  ? (query.origin != null
                      ? '${query.origin!.city} → ${query.destination.city}'
                      : query.destination.city)
                  : 'Resultados',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            if (query != null)
              Text(
                '${query.category.label} • ${AppFormatters.dateDayMonth(query.departureDate)} • ${query.passengers} pax',
                style: const TextStyle(color: AppColors.secondaryText, fontSize: 12),
              ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _openFilterSheet(context),
            icon: const Icon(Icons.tune_rounded, color: AppColors.lightPurple),
            tooltip: 'Filtros',
          ),
        ],
      ),
      body: Column(
        children: [
          // Barra de ordenação
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                _SortPill(
                  label: 'Recomendados',
                  selected: provider.sortOrder == OfferSortOrder.recommended,
                  onTap: () => provider.setSortOrder(OfferSortOrder.recommended),
                ),
                const SizedBox(width: 8),
                _SortPill(
                  label: 'Mais baratos',
                  selected: provider.sortOrder == OfferSortOrder.cheapest,
                  onTap: () => provider.setSortOrder(OfferSortOrder.cheapest),
                ),
                const SizedBox(width: 8),
                _SortPill(
                  label: 'Mais rápidos',
                  selected: provider.sortOrder == OfferSortOrder.fastest,
                  onTap: () => provider.setSortOrder(OfferSortOrder.fastest),
                ),
              ],
            ),
          ),

          if (provider.resultsBannerMessage != null)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.darkPurple.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primaryPurple.withValues(alpha: 0.5)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline_rounded,
                      color: AppColors.lightPurple, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      provider.resultsBannerMessage!,
                      style: const TextStyle(color: AppColors.white, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),

          Expanded(
            child: provider.isLoadingResults
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(color: AppColors.primaryPurple),
                        SizedBox(height: 16),
                        Text(
                          'Consultando fornecedores oficiais...',
                          style: TextStyle(color: AppColors.secondaryText),
                        ),
                      ],
                    ),
                  )
                : provider.searchError != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.error_outline_rounded,
                                  color: AppColors.error, size: 48),
                              const SizedBox(height: 12),
                              Text(
                                provider.searchError!,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: AppColors.white),
                              ),
                              const SizedBox(height: 16),
                              if (query != null)
                                ElevatedButton(
                                  onPressed: () => provider.executeSearch(query),
                                  child: const Text('Tentar novamente'),
                                ),
                            ],
                          ),
                        ),
                      )
                    : offers.isEmpty
                        ? const Center(
                            child: Text(
                              'Nenhuma oferta encontrada para os filtros selecionados.',
                              style: TextStyle(color: AppColors.secondaryText),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: offers.length,
                            itemBuilder: (context, index) {
                              final offer = offers[index];
                              return OfferCard(
                                offer: offer,
                                isFavorite: provider.isOfferFavorite(offer.id),
                                onToggleFavorite: () => provider.toggleFavoriteOffer(offer),
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => DetailsScreen(offer: offer),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class _SortPill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _SortPill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? AppColors.primaryPurple : AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: selected ? AppColors.lightPurple : AppColors.cardBorder,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? AppColors.white : AppColors.secondaryText,
              fontSize: 12,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
