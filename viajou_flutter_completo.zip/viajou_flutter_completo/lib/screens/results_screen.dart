import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/travel_offer.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/offer_card.dart';
import '../widgets/premium_motion.dart';
import 'details_screen.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  void _openFilterSheet(BuildContext context) {
    final provider = context.read<TravelProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        String? selectedProvider = provider.selectedProviderFilter;
        int? maxStops = provider.maxStopsFilter;
        double? maxPrice = provider.maxPriceFilter;

        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Filtrar Resultados',
                    style: TextStyle(
                      color: AppColors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Paradas / Escalas',
                      style: TextStyle(color: AppColors.secondaryText)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('Qualquer'),
                        selected: maxStops == null,
                        onSelected: (_) => setModalState(() => maxStops = null),
                      ),
                      ChoiceChip(
                        label: const Text('Direto'),
                        selected: maxStops == 0,
                        onSelected: (_) => setModalState(() => maxStops = 0),
                      ),
                      ChoiceChip(
                        label: const Text('Até 1 parada'),
                        selected: maxStops == 1,
                        onSelected: (_) => setModalState(() => maxStops = 1),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Companhia / Fornecedor',
                      style: TextStyle(color: AppColors.secondaryText)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String?>(
                    initialValue: selectedProvider,
                    dropdownColor: AppColors.cardBackground,
                    items: [
                      const DropdownMenuItem(
                          value: null, child: Text('Todas as empresas')),
                      ...provider.availableProviders.map(
                        (p) => DropdownMenuItem(value: p, child: Text(p)),
                      ),
                    ],
                    onChanged: (v) => setModalState(() => selectedProvider = v),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Preço máximo',
                          style: TextStyle(color: AppColors.secondaryText)),
                      Text(
                        maxPrice == null
                            ? 'Sem limite'
                            : AppFormatters.currency(maxPrice, provider.currency),
                        style: const TextStyle(
                          color: AppColors.lightPurple,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  Slider(
                    value: (maxPrice ?? 5000).clamp(200, 5000),
                    min: 200,
                    max: 5000,
                    divisions: 24,
                    activeColor: AppColors.primaryPurple,
                    onChanged: (val) {
                      setModalState(() {
                        maxPrice = val >= 5000 ? null : val;
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {
                            provider.clearFilters();
                            Navigator.pop(ctx);
                          },
                          child: const Text('Limpar'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            provider.setFilters(
                              provider: selectedProvider,
                              maxStops: maxStops,
                              maxPrice: maxPrice,
                            );
                            Navigator.pop(ctx);
                          },
                          child: const Text('Aplicar'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _openComparisonModal(BuildContext context, List<TravelOffer> items) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.72,
        maxChildSize: 0.92,
        builder: (ctx, sc) => ListView(
          controller: sc,
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Comparação Lado a Lado',
              style: TextStyle(
                color: AppColors.white,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowColor: WidgetStateProperty.all(AppColors.darkPurple),
                columns: [
                  const DataColumn(label: Text('Critério')),
                  ...items.map(
                    (e) => DataColumn(
                      label: Text(
                        e.providerName,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ],
                rows: [
                  DataRow(cells: [
                    const DataCell(Text('Valor')),
                    ...items.map((e) => DataCell(Text(
                          AppFormatters.currency(e.price, e.currency),
                          style: const TextStyle(
                            color: AppColors.lightPurple,
                            fontWeight: FontWeight.w700,
                          ),
                        ))),
                  ]),
                  DataRow(cells: [
                    const DataCell(Text('Duração')),
                    ...items.map((e) => DataCell(Text(
                          e.duration != null
                              ? '${e.duration!.inHours}h ${e.duration!.inMinutes % 60}m'
                              : 'Portal oficial',
                        ))),
                  ]),
                  DataRow(cells: [
                    const DataCell(Text('Paradas')),
                    ...items.map((e) => DataCell(Text(
                          e.stops == 0 ? 'Direto' : '${e.stops} parada(s)',
                        ))),
                  ]),
                  DataRow(cells: [
                    const DataCell(Text('Serviço')),
                    ...items.map((e) => DataCell(Text(
                          e.cabinOrService.isNotEmpty
                              ? e.cabinOrService
                              : 'Padrão',
                        ))),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final query = provider.activeQuery;
    final offers = provider.filteredAndSortedResults;
    final basket = provider.comparisonBasket;
    final hasAlert = provider.hasPriceAlertForActiveQuery();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              query != null
                  ? (query.origin != null
                      ? '${query.origin!.city} → ${query.destination.city}'
                      : query.destination.city)
                  : 'Resultados',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            if (query != null)
              Text(
                '${query.category.label} • ${AppFormatters.dateDayMonth(query.departureDate)} • ${query.passengers} pax',
                style:
                    const TextStyle(color: AppColors.secondaryText, fontSize: 12),
              ),
          ],
        ),
        actions: [
          if (query != null)
            IconButton(
              onPressed: () async {
                final created = await provider.togglePriceAlertForActiveQuery();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      created
                          ? 'Alerta de preço ativado para esta rota!'
                          : 'Alerta de preço removido.',
                    ),
                  ),
                );
              },
              icon: Icon(
                hasAlert
                    ? Icons.notifications_active_rounded
                    : Icons.notifications_none_rounded,
                color: hasAlert ? AppColors.success : AppColors.lightPurple,
              ),
              tooltip: 'Monitorar preço desta rota',
            ),
          IconButton(
            onPressed: () => _openFilterSheet(context),
            icon: const Icon(Icons.tune_rounded, color: AppColors.lightPurple),
            tooltip: 'Filtros',
          ),
        ],
      ),
      body: AmbientGlowBackdrop(
        child: Column(
          children: [
            // Faixa de datas flexíveis (-1 dia / Data selecionada / +1 dia)
            if (query != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                child: Row(
                  children: [
                    _DateShiftChip(
                      label: '← -1 dia',
                      onTap: () => provider.shiftActiveSearchDate(-1),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 7),
                        decoration: BoxDecoration(
                          color: AppColors.darkPurple.withValues(alpha: 0.65),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.primaryPurple),
                        ),
                        child: Text(
                          AppFormatters.dateDayMonth(query.departureDate),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _DateShiftChip(
                      label: '+1 dia →',
                      onTap: () => provider.shiftActiveSearchDate(1),
                    ),
                  ],
                ),
              ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  _SortPill(
                    label: 'Recomendados',
                    selected: provider.sortOrder == OfferSortOrder.recommended,
                    onTap: () => provider.setSortOrder(OfferSortOrder.recommended),
                  ),
                  const SizedBox(width: 8),
                  _SortPill(
                    label: 'Mais baratos',
                    selected: provider.sortOrder == OfferSortOrder.cheapest,
                    onTap: () => provider.setSortOrder(OfferSortOrder.cheapest),
                  ),
                  const SizedBox(width: 8),
                  _SortPill(
                    label: 'Mais rápidos',
                    selected: provider.sortOrder == OfferSortOrder.fastest,
                    onTap: () => provider.setSortOrder(OfferSortOrder.fastest),
                  ),
                  const SizedBox(width: 8),
                  _SortPill(
                    label: 'Promoções',
                    selected: provider.promoOnlyFilter,
                    onTap: () => provider.togglePromoOnly(),
                  ),
                ],
              ),
            ),

            if (provider.resultsBannerMessage != null)
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.darkPurple.withValues(alpha: 0.55),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: AppColors.primaryPurple.withValues(alpha: 0.5)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.auto_awesome_rounded,
                        color: AppColors.lightPurple, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        provider.resultsBannerMessage!,
                        style:
                            const TextStyle(color: AppColors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),

            Expanded(
              child: provider.isLoadingResults
                  ? ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: 4,
                      itemBuilder: (_, idx) => Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: ShimmerGlowBox(
                          height: idx == 0 ? 155 : 140,
                          radius: 22,
                        ),
                      ),
                    )
                  : provider.searchError != null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.error_outline_rounded,
                                    color: AppColors.error, size: 48),
                                const SizedBox(height: 12),
                                Text(
                                  provider.searchError!,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(color: AppColors.white),
                                ),
                                const SizedBox(height: 16),
                                if (query != null)
                                  ElevatedButton(
                                    onPressed: () =>
                                        provider.executeSearch(query),
                                    child: const Text('Tentar novamente'),
                                  ),
                              ],
                            ),
                          ),
                        )
                      : offers.isEmpty
                          ? const Center(
                              child: Text(
                                'Nenhuma oferta encontrada para os filtros selecionados.',
                                style:
                                    TextStyle(color: AppColors.secondaryText),
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
                              itemCount: offers.length,
                              itemBuilder: (context, index) {
                                final offer = offers[index];
                                final inCompare =
                                    provider.isInComparison(offer.id);

                                return StaggeredReveal(
                                  index: index,
                                  child: Column(
                                    children: [
                                      OfferCard(
                                        offer: offer,
                                        isFavorite:
                                            provider.isOfferFavorite(offer.id),
                                        onToggleFavorite: () =>
                                            provider.toggleFavoriteOffer(offer),
                                        onTap: () {
                                          Navigator.of(context).push(
                                            PageRouteBuilder(
                                              pageBuilder: (_, __, ___) =>
                                                  DetailsScreen(offer: offer),
                                              transitionsBuilder:
                                                  (_, animation, __, child) {
                                                final slide = Tween<Offset>(
                                                  begin: const Offset(0.08, 0),
                                                  end: Offset.zero,
                                                ).animate(CurvedAnimation(
                                                  parent: animation,
                                                  curve: Curves.easeOutCubic,
                                                ));
                                                return FadeTransition(
                                                  opacity: animation,
                                                  child: SlideTransition(
                                                      position: slide,
                                                      child: child),
                                                );
                                              },
                                              transitionDuration:
                                                  const Duration(
                                                      milliseconds: 280),
                                            ),
                                          );
                                        },
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 8, right: 4),
                                          child: InkWell(
                                            onTap: () {
                                              final msg = provider
                                                  .toggleComparisonOffer(offer);
                                              if (msg != null &&
                                                  context.mounted) {
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  SnackBar(content: Text(msg)),
                                                );
                                              }
                                            },
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(
                                                  inCompare
                                                      ? Icons.check_box_rounded
                                                      : Icons
                                                          .check_box_outline_blank_rounded,
                                                  size: 16,
                                                  color: AppColors.lightPurple,
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  inCompare
                                                      ? 'Selecionado para comparar'
                                                      : 'Comparar',
                                                  style: const TextStyle(
                                                    color: AppColors.lightPurple,
                                                    fontSize: 11.5,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: basket.length >= 2
          ? SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
                child: ElevatedButton.icon(
                  onPressed: () => _openComparisonModal(context, basket),
                  icon: const Icon(Icons.compare_arrows_rounded),
                  label: Text('COMPARAR ${basket.length} OPÇÕES LADO A LADO'),
                ),
              ),
            )
          : null,
    );
  }
}

class _DateShiftChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _DateShiftChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: AppColors.cardBackground,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.lightPurple,
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

class _SortPill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _SortPill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: PressableScale(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: selected ? AppColors.primaryPurple : AppColors.cardBackground,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? AppColors.lightPurple : AppColors.cardBorder,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? AppColors.white : AppColors.secondaryText,
              fontSize: 12,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
