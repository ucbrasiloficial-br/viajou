import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/location_point.dart';
import '../models/travel_category.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/viajou_logo.dart';
import 'search_screen.dart';
import 'results_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const List<LocationPoint> _popularDestinations = [
    LocationPoint(code: 'MAO', name: 'Manaus', city: 'Manaus', stateOrCountry: 'Amazonas'),
    LocationPoint(code: 'GRU', name: 'São Paulo', city: 'São Paulo', stateOrCountry: 'São Paulo'),
    LocationPoint(code: 'GIG', name: 'Rio de Janeiro', city: 'Rio de Janeiro', stateOrCountry: 'Rio de Janeiro'),
    LocationPoint(code: 'BEL', name: 'Belém', city: 'Belém', stateOrCountry: 'Pará'),
    LocationPoint(code: 'SSA', name: 'Salvador', city: 'Salvador', stateOrCountry: 'Bahia'),
    LocationPoint(code: 'LIS', name: 'Lisboa', city: 'Lisboa', stateOrCountry: 'Portugal'),
  ];

  void _openSearch(
    BuildContext context, {
    TravelCategory category = TravelCategory.flights,
    LocationPoint? preselectedDest,
  }) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SearchScreen(
          initialCategory: category,
          initialDestination: preselectedDest,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const ViajouLogo(size: 22),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.cardBackground,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Text(
                      provider.currency,
                      style: const TextStyle(
                        color: AppColors.lightPurple,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Text(
                'Olá, viajante!',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 4),
              const Text(
                'Compare voos, ônibus, barcos e hospedagens em um só lugar.',
                style: TextStyle(color: AppColors.secondaryText, fontSize: 14),
              ),
              const SizedBox(height: 20),

              // Campo de pesquisa em destaque
              GestureDetector(
                onTap: () => _openSearch(context),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.cardBackground, Color(0xFF1F183B)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.primaryPurple, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryPurple.withValues(alpha: 0.2),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.primaryPurple,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.search_rounded, color: AppColors.white),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Para onde você vai?',
                              style: TextStyle(
                                color: AppColors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Origem, destino, datas e passageiros',
                              style: TextStyle(
                                color: AppColors.secondaryText,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded,
                          color: AppColors.lightPurple, size: 16),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 26),
              Text(
                'Categorias de viagem',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.15,
                children: TravelCategory.values.map((cat) {
                  return InkWell(
                    onTap: () => _openSearch(context, category: cat),
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.cardBackground,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.cardBorder),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(cat.icon, color: AppColors.lightPurple, size: 26),
                          const SizedBox(height: 8),
                          Text(
                            cat.label,
                            style: const TextStyle(
                              color: AppColors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 26),
              Text(
                'Destinos populares',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 112,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _popularDestinations.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) {
                    final dest = _popularDestinations[index];
                    final isFav = provider.isDestinationFavorite(dest.displayLabel);

                    return GestureDetector(
                      onTap: () => _openSearch(context, preselectedDest: dest),
                      child: Container(
                        width: 155,
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [AppColors.darkPurple, AppColors.cardBackground],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  dest.code,
                                  style: const TextStyle(
                                    color: AppColors.lightPurple,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => provider.toggleFavoriteDestination(dest),
                                  child: Icon(
                                    isFav ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                                    color: AppColors.lightPurple,
                                    size: 18,
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  dest.city,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: AppColors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                  ),
                                ),
                                Text(
                                  dest.stateOrCountry,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: AppColors.secondaryText,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              if (provider.searchHistory.isNotEmpty) ...[
                const SizedBox(height: 26),
                Text(
                  'Últimas pesquisas',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 10),
                ...provider.searchHistory.take(3).map((item) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: AppColors.cardBackground,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: ListTile(
                      leading: Icon(item.category.icon, color: AppColors.lightPurple),
                      title: Text(
                        item.origin != null
                            ? '${item.origin!.city} → ${item.destination.city}'
                            : item.destination.city,
                        style: const TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                      subtitle: Text(
                        '${item.category.label} • ${AppFormatters.dateDayMonth(item.departureDate)} • ${item.passengers} pax',
                        style: const TextStyle(color: AppColors.secondaryText, fontSize: 12),
                      ),
                      trailing: const Icon(Icons.refresh_rounded, color: AppColors.lightPurple),
                      onTap: () {
                        provider.executeSearch(item);
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const ResultsScreen()),
                        );
                      },
                    ),
                  );
                }),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
