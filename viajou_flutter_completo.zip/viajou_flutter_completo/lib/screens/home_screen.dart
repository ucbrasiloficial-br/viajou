import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/premium_motion.dart';
import '../widgets/viajou_logo.dart';
import 'fluvial_guide_screen.dart';
import 'results_screen.dart';
import 'search_screen.dart';

class _PromoSpotlight {
  final String tag;
  final String title;
  final String subtitle;
  final LocationPoint origin;
  final LocationPoint destination;
  final TravelCategory category;
  final String badge;

  const _PromoSpotlight({
    required this.tag,
    required this.title,
    required this.subtitle,
    required this.origin,
    required this.destination,
    required this.category,
    required this.badge,
  });
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const List<_PromoSpotlight> _flashDeals = [
    _PromoSpotlight(
      tag: 'BRASIL',
      title: 'Manaus → Brasília',
      subtitle: 'Voos diretos e conexões rápidas',
      origin: LocationPoint(code: 'MAO', name: 'Manaus', city: 'Manaus', stateOrCountry: 'Brasil'),
      destination: LocationPoint(code: 'BSB', name: 'Brasília', city: 'Brasília', stateOrCountry: 'Brasil'),
      category: TravelCategory.flights,
      badge: 'OFERTA RELÂMPAGO',
    ),
    _PromoSpotlight(
      tag: 'EUROPA',
      title: 'São Paulo → Lisboa',
      subtitle: 'Tarifas internacionais em destaque',
      origin: LocationPoint(code: 'GRU', name: 'São Paulo', city: 'São Paulo', stateOrCountry: 'Brasil'),
      destination: LocationPoint(code: 'LIS', name: 'Lisboa', city: 'Lisboa', stateOrCountry: 'Portugal'),
      category: TravelCategory.flights,
      badge: 'INTERNACIONAL',
    ),
    _PromoSpotlight(
      tag: 'PACOTE',
      title: 'Manaus → Fortaleza',
      subtitle: 'Combo Voo + 3 noites de hotel',
      origin: LocationPoint(code: 'MAO', name: 'Manaus', city: 'Manaus', stateOrCountry: 'Brasil'),
      destination: LocationPoint(code: 'FOR', name: 'Fortaleza', city: 'Fortaleza', stateOrCountry: 'Brasil'),
      category: TravelCategory.packages,
      badge: 'PACOTE -6%',
    ),
    _PromoSpotlight(
      tag: 'AMÉRICAS',
      title: 'Belém → Miami',
      subtitle: 'Rotas para os Estados Unidos',
      origin: LocationPoint(code: 'BEL', name: 'Belém', city: 'Belém', stateOrCountry: 'Brasil'),
      destination: LocationPoint(code: 'MIA', name: 'Miami', city: 'Miami', stateOrCountry: 'EUA'),
      category: TravelCategory.flights,
      badge: 'EUA DIRETO',
    ),
  ];

  static const List<LocationPoint> _popularDestinations = [
    LocationPoint(code: 'MAO', name: 'Manaus', city: 'Manaus', stateOrCountry: 'Amazonas • Brasil'),
    LocationPoint(code: 'LIS', name: 'Lisboa', city: 'Lisboa', stateOrCountry: 'Portugal • Europa'),
    LocationPoint(code: 'MIA', name: 'Miami', city: 'Miami', stateOrCountry: 'Estados Unidos'),
    LocationPoint(code: 'EZE', name: 'Buenos Aires', city: 'Buenos Aires', stateOrCountry: 'Argentina'),
    LocationPoint(code: 'CDG', name: 'Paris', city: 'Paris', stateOrCountry: 'França • Europa'),
    LocationPoint(code: 'GRU', name: 'São Paulo', city: 'São Paulo', stateOrCountry: 'Brasil'),
  ];

  void _openSearch(
    BuildContext context, {
    TravelCategory category = TravelCategory.flights,
    LocationPoint? preselectedDest,
  }) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => SearchScreen(
          initialCategory: category,
          initialDestination: preselectedDest,
        ),
        transitionsBuilder: (_, animation, __, child) {
          final slide = Tween<Offset>(
            begin: const Offset(0, 0.06),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(position: slide, child: child),
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  void _launchPromoSearch(BuildContext context, _PromoSpotlight promo) {
    final provider = context.read<TravelProvider>();
    final query = SearchQuery(
      id: const Uuid().v4(),
      category: promo.category,
      origin: promo.origin,
      destination: promo.destination,
      departureDate: DateTime.now().add(const Duration(days: 14)),
      returnDate: promo.category == TravelCategory.packages
          ? DateTime.now().add(const Duration(days: 17))
          : null,
      isRoundTrip: promo.category == TravelCategory.packages,
      passengers: 1,
    );
    provider.executeSearch(query);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ResultsScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      body: AmbientGlowBackdrop(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                StaggeredReveal(
                  index: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const ViajouLogo(size: 22),
                      Row(
                        children: [
                          // Seletor rápido de idioma (PT / EN / ES)
                          PopupMenuButton<String>(
                            color: AppColors.cardBackground,
                            onSelected: (lang) => provider.updateLanguage(lang),
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'pt', child: Text('🇧🇷 Português (PT)')),
                              PopupMenuItem(value: 'en', child: Text('🇺🇸 English (EN)')),
                              PopupMenuItem(value: 'es', child: Text('🇪🇸 Español (ES)')),
                            ],
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: AppColors.cardBackground,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: AppColors.lightPurple
                                      .withValues(alpha: 0.35),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.language_rounded,
                                      size: 14, color: AppColors.lightPurple),
                                  const SizedBox(width: 4),
                                  Text(
                                    provider.language.toUpperCase(),
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 11.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Seletor rápido de moeda
                          PopupMenuButton<String>(
                            color: AppColors.cardBackground,
                            onSelected: (cur) => provider.updateCurrency(cur),
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'BRL', child: Text('BRL (R\$)')),
                              const PopupMenuItem(value: 'USD', child: Text('USD (US\$)')),
                              const PopupMenuItem(value: 'EUR', child: Text('EUR (€)')),
                              const PopupMenuItem(value: 'GBP', child: Text('GBP (£)')),
                              const PopupMenuItem(value: 'ARS', child: Text('ARS (ARS\$)')),
                            ],
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    AppColors.cardBackground,
                                    AppColors.elevatedGlass
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: AppColors.lightPurple
                                      .withValues(alpha: 0.35),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: const BoxDecoration(
                                      color: AppColors.success,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    provider.currency,
                                    style: const TextStyle(
                                      color: AppColors.lightPurple,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 11.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),
                StaggeredReveal(
                  index: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        provider.tr('hello_traveler'),
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        provider.tr('home_subtitle'),
                        style: const TextStyle(
                          color: AppColors.secondaryText,
                          fontSize: 14,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),
                StaggeredReveal(
                  index: 2,
                  child: PressableScale(
                    onTap: () => _openSearch(context),
                    scaleFactor: 0.98,
                    child: Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF1D1438), AppColors.cardBackground],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: AppColors.primaryPurple.withValues(alpha: 0.85),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primaryPurple.withValues(alpha: 0.25),
                            blurRadius: 24,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  AppColors.primaryPurple,
                                  AppColors.neonViolet,
                                ],
                              ),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryPurple.withValues(alpha: 0.45),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.search_rounded,
                              color: AppColors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  provider.tr('where_to'),
                                  style: const TextStyle(
                                    color: AppColors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  provider.tr('where_to_sub'),
                                  style: const TextStyle(
                                    color: AppColors.secondaryText,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppColors.elevatedGlass,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.arrow_forward_rounded,
                              color: AppColors.lightPurple,
                              size: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 14),
                StaggeredReveal(
                  index: 3,
                  child: Row(
                    children: [
                      Expanded(
                        child: PressableScale(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) =>
                                    const FluvialAndChecklistScreen(initialTab: 0),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(13),
                            decoration: BoxDecoration(
                              color: AppColors.cardBackground,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppColors.cardBorder),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.directions_boat_rounded,
                                    color: AppColors.lightPurple, size: 20),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    provider.tr('fluvial_guide'),
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: PressableScale(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) =>
                                    const FluvialAndChecklistScreen(initialTab: 1),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(13),
                            decoration: BoxDecoration(
                              color: AppColors.cardBackground,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppColors.cardBorder),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.checklist_rounded,
                                    color: AppColors.lightPurple, size: 20),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    provider.tr('travel_checklist'),
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Vitrine de Promoções & Pacotes Relâmpago
                const SizedBox(height: 24),
                StaggeredReveal(
                  index: 4,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.local_fire_department_rounded,
                              color: AppColors.success, size: 20),
                          const SizedBox(width: 6),
                          Text(
                            provider.tr('flash_deals'),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        provider.tr('flash_deals_sub'),
                        style: const TextStyle(
                            color: AppColors.secondaryText, fontSize: 12),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 132,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: _flashDeals.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (context, idx) {
                            final promo = _flashDeals[idx];
                            return PressableScale(
                              onTap: () => _launchPromoSearch(context, promo),
                              child: Container(
                                width: 215,
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xFF231347),
                                      AppColors.cardBackground,
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: AppColors.success
                                        .withValues(alpha: 0.55),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8, vertical: 3),
                                          decoration: BoxDecoration(
                                            color: AppColors.success
                                                .withValues(alpha: 0.16),
                                            borderRadius:
                                                BorderRadius.circular(8),
                                          ),
                                          child: Text(
                                            promo.badge,
                                            style: const TextStyle(
                                              color: AppColors.success,
                                              fontSize: 10,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          promo.tag,
                                          style: const TextStyle(
                                            color: AppColors.lightPurple,
                                            fontSize: 10.5,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          promo.title,
                                          style: const TextStyle(
                                            color: AppColors.white,
                                            fontWeight: FontWeight.w800,
                                            fontSize: 15,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          promo.subtitle,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: AppColors.secondaryText,
                                            fontSize: 11.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
                StaggeredReveal(
                  index: 5,
                  child: Text(
                    provider.tr('categories'),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                const SizedBox(height: 12),
                StaggeredReveal(
                  index: 6,
                  child: GridView.count(
                    crossAxisCount: 3,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.12,
                    children: TravelCategory.values.map((cat) {
                      return PressableScale(
                        onTap: () => _openSearch(context, category: cat),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [AppColors.cardBackground, Color(0xFF18122E)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: AppColors.cardBorder),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: AppColors.darkPurple.withValues(alpha: 0.75),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  cat.icon,
                                  color: AppColors.lightPurple,
                                  size: 22,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                cat.labelLocalized(provider.language),
                                style: const TextStyle(
                                  color: AppColors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                if (provider.priceAlerts.isNotEmpty) ...[
                  const SizedBox(height: 24),
                  Text(
                    provider.tr('monitored_routes'),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 10),
                  ...provider.priceAlerts.map((alert) {
                    final price = alert['lastPrice'];
                    final cur = (alert['currency'] ?? provider.currency).toString();
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: AppColors.cardBackground,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.success.withValues(alpha: 0.45)),
                      ),
                      child: ListTile(
                        leading: const Icon(Icons.notifications_active_rounded,
                            color: AppColors.success),
                        title: Text(
                          (alert['label'] ?? 'Rota').toString(),
                          style: const TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5,
                          ),
                        ),
                        subtitle: Text(
                          price is num
                              ? 'Menor valor registrado: ${AppFormatters.currency(price.toDouble(), cur)}'
                              : 'Monitorando tarifas',
                          style: const TextStyle(
                              color: AppColors.secondaryText, fontSize: 12),
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.close_rounded,
                              color: AppColors.secondaryText, size: 18),
                          onPressed: () => provider.removePriceAlert(
                              (alert['routeKey'] ?? '').toString()),
                        ),
                      ),
                    );
                  }),
                ],

                const SizedBox(height: 24),
                StaggeredReveal(
                  index: 7,
                  child: Text(
                    provider.tr('featured_destinations'),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                const SizedBox(height: 12),
                StaggeredReveal(
                  index: 8,
                  child: SizedBox(
                    height: 122,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _popularDestinations.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        final dest = _popularDestinations[index];
                        final isFav =
                            provider.isDestinationFavorite(dest.displayLabel);

                        return PressableScale(
                          onTap: () =>
                              _openSearch(context, preselectedDest: dest),
                          child: Container(
                            width: 164,
                            padding: const EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  AppColors.darkPurple,
                                  AppColors.cardBackground,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: AppColors.primaryPurple.withValues(alpha: 0.45),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(
                                        color: AppColors.primaryPurple
                                            .withValues(alpha: 0.28),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        dest.code,
                                        style: const TextStyle(
                                          color: AppColors.lightPurple,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 11.5,
                                        ),
                                      ),
                                    ),
                                    PressableScale(
                                      onTap: () => provider
                                          .toggleFavoriteDestination(dest),
                                      scaleFactor: 0.85,
                                      child: Icon(
                                        isFav
                                            ? Icons.bookmark_rounded
                                            : Icons.bookmark_border_rounded,
                                        color: AppColors.lightPurple,
                                        size: 19,
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      dest.city,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: AppColors.white,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 15.5,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      dest.stateOrCountry,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: AppColors.secondaryText,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                if (provider.searchHistory.isNotEmpty) ...[
                  const SizedBox(height: 26),
                  Text(
                    provider.tr('recent_searches'),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 10),
                  ...provider.searchHistory.take(3).map((item) {
                    return PressableScale(
                      scaleFactor: 0.985,
                      onTap: () {
                        provider.executeSearch(item);
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const ResultsScreen()),
                        );
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: AppColors.cardBackground,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: ListTile(
                          leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppColors.darkPurple,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(item.category.icon,
                                color: AppColors.lightPurple, size: 20),
                          ),
                          title: Text(
                            item.origin != null
                                ? '${item.origin!.city} → ${item.destination.city}'
                                : item.destination.city,
                            style: const TextStyle(
                              color: AppColors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          subtitle: Text(
                            '${item.category.labelLocalized(provider.language)} • ${AppFormatters.dateDayMonth(item.departureDate)} • ${item.passengers} pax',
                            style: const TextStyle(
                                color: AppColors.secondaryText, fontSize: 12),
                          ),
                          trailing: const Icon(Icons.refresh_rounded,
                              color: AppColors.lightPurple),
                        ),
                      ),
                    );
                  }),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
