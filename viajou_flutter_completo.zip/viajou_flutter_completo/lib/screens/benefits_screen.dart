import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/travel_benefit.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/premium_motion.dart';

class BenefitsScreen extends StatelessWidget {
  const BenefitsScreen({super.key});

  Future<void> _openOfficialPortal(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openEligibilityChecker(BuildContext context) {
    int age = 24;
    bool lowIncome = true;
    bool hasCadUnico = true;
    bool hasDisability = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final eligibleIdJovem = age >= 15 && age <= 29 && lowIncome && hasCadUnico;
          final eligibleIdoso = age >= 60 && lowIncome;
          final eligiblePasseLivre = hasDisability && lowIncome;

          return Padding(
            padding: const EdgeInsets.fromLTRB(22, 20, 22, 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Verificador Rápido de Direito',
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Informe seus dados básicos para conferir quais gratuidades ou descontos se aplicam a você:',
                  style: TextStyle(color: AppColors.secondaryText, fontSize: 12.5),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Sua idade', style: TextStyle(color: AppColors.white)),
                    Text(
                      '$age anos',
                      style: const TextStyle(
                        color: AppColors.lightPurple,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: age.toDouble(),
                  min: 12,
                  max: 90,
                  divisions: 78,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (v) => setModalState(() => age = v.round()),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(
                    'Renda familiar de até 2 salários mínimos',
                    style: TextStyle(color: AppColors.white, fontSize: 13),
                  ),
                  value: lowIncome,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (v) => setModalState(() => lowIncome = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(
                    'Inscrito no CadÚnico atualizado',
                    style: TextStyle(color: AppColors.white, fontSize: 13),
                  ),
                  value: hasCadUnico,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (v) => setModalState(() => hasCadUnico = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(
                    'Pessoa com deficiência (laudo médico)',
                    style: TextStyle(color: AppColors.white, fontSize: 13),
                  ),
                  value: hasDisability,
                  activeColor: AppColors.primaryPurple,
                  onChanged: (v) => setModalState(() => hasDisability = v),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: (eligibleIdJovem || eligibleIdoso || eligiblePasseLivre)
                          ? AppColors.success
                          : AppColors.cardBorder,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Resultado estimado:',
                        style: TextStyle(
                          color: AppColors.lightPurple,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (eligibleIdJovem)
                        const Text(
                          '✓ Elegível ao ID Jovem (gratuidade ou 50% de desconto interestadual).',
                          style: TextStyle(color: AppColors.success, fontSize: 13),
                        ),
                      if (eligibleIdoso)
                        const Text(
                          '✓ Elegível ao Benefício da Pessoa Idosa (gratuidade ou 50% de desconto).',
                          style: TextStyle(color: AppColors.success, fontSize: 13),
                        ),
                      if (eligiblePasseLivre)
                        const Text(
                          '✓ Elegível ao Passe Livre Interestadual (PcD).',
                          style: TextStyle(color: AppColors.success, fontSize: 13),
                        ),
                      if (!eligibleIdJovem && !eligibleIdoso && !eligiblePasseLivre)
                        const Text(
                          'Pelos critérios informados, não se enquadra nas gratuidades federais interestaduais.',
                          style: TextStyle(color: AppColors.secondaryText, fontSize: 12.5),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showBenefitDetails(BuildContext context, TravelBenefit benefit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.85,
          maxChildSize: 0.95,
          builder: (ctx, scrollController) {
            return ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(24),
              children: [
                Text(
                  benefit.title,
                  style: const TextStyle(
                    color: AppColors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  benefit.legalBasis,
                  style: const TextStyle(
                      color: AppColors.lightPurple, fontSize: 12),
                ),
                const SizedBox(height: 16),
                const Text('O que garante:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(benefit.discountDetails,
                    style: const TextStyle(
                        color: AppColors.secondaryText, fontSize: 13)),
                const SizedBox(height: 16),
                const Text('Requisitos legais:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                ...benefit.requirements.map(
                  (r) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• $r',
                        style: const TextStyle(
                            color: AppColors.secondaryText, fontSize: 13)),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Documentação necessária:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                ...benefit.requiredDocuments.map(
                  (d) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• $d',
                        style: const TextStyle(
                            color: AppColors.secondaryText, fontSize: 13)),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Como solicitar:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(benefit.howToRequest,
                    style: const TextStyle(
                        color: AppColors.secondaryText, fontSize: 13)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.warning),
                  ),
                  child: Text(
                    benefit.importantNotice,
                    style: const TextStyle(color: AppColors.white, fontSize: 12),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () =>
                      _openOfficialPortal(context, benefit.officialPortalUrl),
                  icon: const Icon(Icons.open_in_new_rounded),
                  label: const Text('ACESSAR PORTAL OFICIAL DO GOVERNO'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final benefits = context.watch<TravelProvider>().benefits;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Direitos e Benefícios'),
        actions: [
          IconButton(
            onPressed: () => _openEligibilityChecker(context),
            icon: const Icon(Icons.calculate_rounded,
                color: AppColors.lightPurple),
            tooltip: 'Verificar se tenho direito',
          ),
        ],
      ),
      body: AmbientGlowBackdrop(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            StaggeredReveal(
              index: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.darkPurple, AppColors.cardBackground],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.primaryPurple),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Guia verificado sobre gratuidades e descontos previstos na legislação brasileira para transporte interestadual.',
                      style: TextStyle(color: AppColors.white, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _openEligibilityChecker(context),
                        icon: const Icon(Icons.fact_check_rounded),
                        label: const Text('VERIFICAR MEU DIREITO AGORA'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ...benefits.asMap().entries.map((entry) {
              final idx = entry.key;
              final b = entry.value;
              return StaggeredReveal(
                index: idx + 1,
                child: PressableScale(
                  scaleFactor: 0.985,
                  onTap: () => _showBenefitDetails(context, b),
                  child: Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: const CircleAvatar(
                        backgroundColor: AppColors.darkPurple,
                        child: Icon(Icons.verified_user_rounded,
                            color: AppColors.lightPurple),
                      ),
                      title: Text(
                        b.title,
                        style: const TextStyle(
                            color: AppColors.white, fontWeight: FontWeight.w700),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          b.subtitle,
                          style: const TextStyle(
                              color: AppColors.secondaryText, fontSize: 12),
                        ),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded,
                          color: AppColors.lightPurple),
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
