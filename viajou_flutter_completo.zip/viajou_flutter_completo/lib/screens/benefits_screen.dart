import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/travel_benefit.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/premium_motion.dart';

class BenefitsScreen extends StatelessWidget {
  const BenefitsScreen({super.key});

  Future<void> _openOfficialPortal(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _showBenefitDetails(BuildContext context, TravelBenefit benefit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.85,
          maxChildSize: 0.95,
          builder: (ctx, scrollController) {
            return ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(24),
              children: [
                Text(
                  benefit.title,
                  style: const TextStyle(
                    color: AppColors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  benefit.legalBasis,
                  style: const TextStyle(
                      color: AppColors.lightPurple, fontSize: 12),
                ),
                const SizedBox(height: 16),
                const Text('O que garante:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(benefit.discountDetails,
                    style: const TextStyle(
                        color: AppColors.secondaryText, fontSize: 13)),
                const SizedBox(height: 16),
                const Text('Requisitos legais:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                ...benefit.requirements.map(
                  (r) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• \$r',
                        style: const TextStyle(
                            color: AppColors.secondaryText, fontSize: 13)),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Documentação necessária:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                ...benefit.requiredDocuments.map(
                  (d) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• \$d',
                        style: const TextStyle(
                            color: AppColors.secondaryText, fontSize: 13)),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Como solicitar:',
                    style: TextStyle(
                        color: AppColors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(benefit.howToRequest,
                    style: const TextStyle(
                        color: AppColors.secondaryText, fontSize: 13)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.warning),
                  ),
                  child: Text(
                    benefit.importantNotice,
                    style: const TextStyle(color: AppColors.white, fontSize: 12),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () =>
                      _openOfficialPortal(context, benefit.officialPortalUrl),
                  icon: const Icon(Icons.open_in_new_rounded),
                  label: const Text('ACESSAR PORTAL OFICIAL DO GOVERNO'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final benefits = context.watch<TravelProvider>().benefits;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Direitos e Benefícios'),
      ),
      body: AmbientGlowBackdrop(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            StaggeredReveal(
              index: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.darkPurple, AppColors.cardBackground],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.primaryPurple),
                ),
                child: const Text(
                  'Guia verificado sobre gratuidades e descontos previstos na legislação brasileira para transporte interestadual.',
                  style: TextStyle(color: AppColors.white, fontSize: 13),
                ),
              ),
            ),
            const SizedBox(height: 16),
            ...benefits.asMap().entries.map((entry) {
              final idx = entry.key;
              final b = entry.value;
              return StaggeredReveal(
                index: idx + 1,
                child: PressableScale(
                  scaleFactor: 0.985,
                  onTap: () => _showBenefitDetails(context, b),
                  child: Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: const CircleAvatar(
                        backgroundColor: AppColors.darkPurple,
                        child: Icon(Icons.verified_user_rounded,
                            color: AppColors.lightPurple),
                      ),
                      title: Text(
                        b.title,
                        style: const TextStyle(
                            color: AppColors.white, fontWeight: FontWeight.w700),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          b.subtitle,
                          style: const TextStyle(
                              color: AppColors.secondaryText, fontSize: 12),
                        ),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded,
                          color: AppColors.lightPurple),
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
