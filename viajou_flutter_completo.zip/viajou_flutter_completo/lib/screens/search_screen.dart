import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../repositories/travel_repository.dart';
import '../services/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/category_selector.dart';
import '../widgets/premium_motion.dart';
import 'results_screen.dart';

class SearchScreen extends StatefulWidget {
  final TravelCategory initialCategory;
  final LocationPoint? initialDestination;

  const SearchScreen({
    super.key,
    this.initialCategory = TravelCategory.flights,
    this.initialDestination,
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late TravelCategory _category;
  LocationPoint? _origin;
  LocationPoint? _destination;
  DateTime _departureDate = DateTime.now().add(const Duration(days: 7));
  DateTime? _returnDate;
  bool _isRoundTrip = false;
  int _passengers = 1;
  String _travelClass = 'ECONOMY';
  double _swapTurns = 0.0;

  @override
  void initState() {
    super.initState();
    _category = widget.initialCategory;
    _destination = widget.initialDestination;
    _origin = TravelRepository.curatedBrazilianLocations.firstWhere(
      (l) => l.code == 'MAO',
      orElse: () => TravelRepository.curatedBrazilianLocations.first,
    );
  }

  bool get _requiresOrigin => _category != TravelCategory.stays;

  void _swapLocations() {
    setState(() {
      _swapTurns += 0.5;
      final temp = _origin;
      _origin = _destination;
      _destination = temp;
    });
  }

  Future<void> _pickLocation({required bool isOrigin}) async {
    final selected = await showModalBottomSheet<LocationPoint>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.deepBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _LocationPickerSheet(category: _category),
    );

    if (selected != null) {
      setState(() {
        if (isOrigin) {
          _origin = selected;
        } else {
          _destination = selected;
        }
      });
    }
  }

  Future<void> _pickDate({required bool isReturn}) async {
    final firstDate = isReturn ? _departureDate : DateTime.now();
    final initial = isReturn
        ? (_returnDate ?? _departureDate.add(const Duration(days: 3)))
        : _departureDate;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: firstDate,
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: AppTheme.darkTheme.copyWith(
            colorScheme: const ColorScheme.dark(
              primary: AppColors.primaryPurple,
              surface: AppColors.cardBackground,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isReturn) {
          _returnDate = picked;
        } else {
          _departureDate = picked;
          if (_returnDate != null && _returnDate!.isBefore(picked)) {
            _returnDate = picked.add(const Duration(days: 2));
          }
        }
      });
    }
  }

  void _submitSearch() {
    if (_requiresOrigin && _origin == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione a origem da viagem.')),
      );
      return;
    }
    if (_destination == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione o destino da viagem.')),
      );
      return;
    }

    final query = SearchQuery(
      id: const Uuid().v4(),
      category: _category,
      origin: _requiresOrigin ? _origin : null,
      destination: _destination!,
      departureDate: _departureDate,
      returnDate: _isRoundTrip ? _returnDate : null,
      isRoundTrip: _isRoundTrip,
      passengers: _passengers,
      travelClass: _travelClass,
    );

    context.read<TravelProvider>().executeSearch(query);
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const ResultsScreen(),
        transitionsBuilder: (_, animation, __, child) {
          final slide = Tween<Offset>(
            begin: const Offset(0.08, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(position: slide, child: child),
          );
        },
        transitionDuration: const Duration(milliseconds: 280),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_category.fullTitle),
      ),
      body: AmbientGlowBackdrop(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StaggeredReveal(
                index: 0,
                child: CategorySelector(
                  selected: _category,
                  onSelected: (cat) => setState(() => _category = cat),
                ),
              ),
              const SizedBox(height: 20),

              if (_category == TravelCategory.flights ||
                  _category == TravelCategory.stays) ...[
                StaggeredReveal(
                  index: 1,
                  child: Row(
                    children: [
                      _TripTypeChip(
                        label: _category == TravelCategory.stays
                            ? 'Estadia'
                            : 'Somente ida',
                        selected: !_isRoundTrip,
                        onTap: () => setState(() => _isRoundTrip = false),
                      ),
                      const SizedBox(width: 10),
                      _TripTypeChip(
                        label: _category == TravelCategory.stays
                            ? 'Com Check-out'
                            : 'Ida e volta',
                        selected: _isRoundTrip,
                        onTap: () => setState(() {
                          _isRoundTrip = true;
                          _returnDate ??=
                              _departureDate.add(const Duration(days: 3));
                        }),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],

              if (_requiresOrigin) ...[
                StaggeredReveal(
                  index: 2,
                  child: _FieldTile(
                    icon: Icons.trip_origin_rounded,
                    label: _category == TravelCategory.cars
                        ? 'Local de retirada'
                        : 'Origem',
                    value: _origin?.displayLabel ?? 'Selecionar origem',
                    onTap: () => _pickLocation(isOrigin: true),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: PressableScale(
                      onTap: _swapLocations,
                      scaleFactor: 0.9,
                      child: AnimatedRotation(
                        turns: _swapTurns,
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                AppColors.darkPurple,
                                AppColors.elevatedGlass,
                              ],
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppColors.primaryPurple.withValues(alpha: 0.7),
                            ),
                          ),
                          child: const Icon(
                            Icons.swap_vert_rounded,
                            color: AppColors.lightPurple,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              StaggeredReveal(
                index: 3,
                child: _FieldTile(
                  icon: Icons.location_on_rounded,
                  label: _category == TravelCategory.stays
                      ? 'Cidade ou destino'
                      : (_category == TravelCategory.cars
                          ? 'Local de devolução'
                          : 'Destino'),
                  value: _destination?.displayLabel ?? 'Selecionar destino',
                  onTap: () => _pickLocation(isOrigin: false),
                ),
              ),

              const SizedBox(height: 14),
              StaggeredReveal(
                index: 4,
                child: Row(
                  children: [
                    Expanded(
                      child: _FieldTile(
                        icon: Icons.calendar_today_rounded,
                        label: _category == TravelCategory.stays
                            ? 'Check-in'
                            : 'Data de ida',
                        value: AppFormatters.dateShort(_departureDate),
                        onTap: () => _pickDate(isReturn: false),
                      ),
                    ),
                    if (_isRoundTrip || _category == TravelCategory.stays) ...[
                      const SizedBox(width: 12),
                      Expanded(
                        child: _FieldTile(
                          icon: Icons.event_available_rounded,
                          label: _category == TravelCategory.stays
                              ? 'Check-out'
                              : 'Volta',
                          value: AppFormatters.dateShort(
                            _returnDate ??
                                _departureDate.add(const Duration(days: 3)),
                          ),
                          onTap: () => _pickDate(isReturn: true),
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 14),
              StaggeredReveal(
                index: 5,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.people_alt_rounded,
                              color: AppColors.lightPurple),
                          const SizedBox(width: 12),
                          Text(
                            _category == TravelCategory.stays
                                ? 'Hóspedes'
                                : 'Passageiros',
                            style: const TextStyle(
                                color: AppColors.white,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(
                            onPressed: _passengers > 1
                                ? () => setState(() => _passengers--)
                                : null,
                            icon: const Icon(Icons.remove_circle_outline_rounded),
                          ),
                          Text(
                            '$_passengers',
                            style: const TextStyle(
                              color: AppColors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          IconButton(
                            onPressed: _passengers < 9
                                ? () => setState(() => _passengers++)
                                : null,
                            icon: const Icon(Icons.add_circle_outline_rounded),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              if (_category == TravelCategory.flights) ...[
                const SizedBox(height: 14),
                StaggeredReveal(
                  index: 6,
                  child: DropdownButtonFormField<String>(
                    initialValue: _travelClass,
                    dropdownColor: AppColors.cardBackground,
                    decoration: const InputDecoration(
                      labelText: 'Classe da cabine',
                      prefixIcon: Icon(
                          Icons.airline_seat_recline_extra_rounded,
                          color: AppColors.lightPurple),
                    ),
                    items: const [
                      DropdownMenuItem(
                          value: 'ECONOMY', child: Text('Econômica')),
                      DropdownMenuItem(
                          value: 'PREMIUM_ECONOMY',
                          child: Text('Econômica Premium')),
                      DropdownMenuItem(
                          value: 'BUSINESS', child: Text('Executiva')),
                      DropdownMenuItem(
                          value: 'FIRST', child: Text('Primeira Classe')),
                    ],
                    onChanged: (val) {
                      if (val != null) setState(() => _travelClass = val);
                    },
                  ),
                ),
              ],

              const SizedBox(height: 28),
              StaggeredReveal(
                index: 7,
                child: PressableScale(
                  onTap: _submitSearch,
                  scaleFactor: 0.985,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primaryPurple, AppColors.neonViolet],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primaryPurple.withValues(alpha: 0.45),
                          blurRadius: 18,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_rounded, color: AppColors.white),
                        SizedBox(width: 10),
                        Text(
                          'PESQUISAR OPÇÕES',
                          style: TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TripTypeChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TripTypeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: AppColors.primaryPurple,
      backgroundColor: AppColors.cardBackground,
      labelStyle: TextStyle(
        color: selected ? AppColors.white : AppColors.secondaryText,
        fontWeight: FontWeight.w600,
      ),
      side: BorderSide(
        color: selected ? AppColors.lightPurple : AppColors.cardBorder,
      ),
    );
  }
}

class _FieldTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  const _FieldTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onTap,
      scaleFactor: 0.985,
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.cardBackground, Color(0xFF18122E)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.darkPurple.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: AppColors.lightPurple, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                        color: AppColors.secondaryText, fontSize: 11),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppColors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LocationPickerSheet extends StatefulWidget {
  final TravelCategory category;

  const _LocationPickerSheet({required this.category});

  @override
  State<_LocationPickerSheet> createState() => _LocationPickerSheetState();
}

class _LocationPickerSheetState extends State<_LocationPickerSheet> {
  final TextEditingController _controller = TextEditingController();
  List<LocationPoint> _suggestions = TravelRepository.curatedBrazilianLocations;
  bool _loading = false;

  Future<void> _onQueryChanged(String value) async {
    setState(() => _loading = true);
    final results = await context
        .read<TravelProvider>()
        .autocompleteLocations(value, widget.category);
    if (!mounted) return;
    setState(() {
      _suggestions = results;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.7,
        child: Column(
          children: [
            TextField(
              controller: _controller,
              autofocus: true,
              onChanged: _onQueryChanged,
              decoration: const InputDecoration(
                hintText: 'Digite cidade, porto ou código IATA (ex: MAO, GRU)...',
                prefixIcon:
                    Icon(Icons.search_rounded, color: AppColors.lightPurple),
              ),
            ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: LinearProgressIndicator(color: AppColors.primaryPurple),
              ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _suggestions.length,
                itemBuilder: (context, index) {
                  final loc = _suggestions[index];
                  return ListTile(
                    leading: const Icon(Icons.place_rounded,
                        color: AppColors.lightPurple),
                    title: Text(
                      loc.displayLabel,
                      style: const TextStyle(
                          color: AppColors.white, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      '${loc.name} • ${loc.stateOrCountry}',
                      style: const TextStyle(
                          color: AppColors.secondaryText, fontSize: 12),
                    ),
                    onTap: () => Navigator.of(context).pop(loc),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
