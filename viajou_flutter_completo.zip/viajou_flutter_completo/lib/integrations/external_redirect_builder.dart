import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';
import '../utils/formatters.dart';

class ExternalRedirectBuilder {
  static List<TravelOffer> buildOfficialPortalOptions(SearchQuery query) {
    final now = DateTime.now();
    final origin = query.origin?.city ?? '';
    final dest = query.destination.city;
    final dateBr = AppFormatters.dateShort(query.departureDate);
    final dateIso = query.departureDate.toIso8601String().split('T').first;

    switch (query.category) {
      case TravelCategory.flights:
        final originCode = query.origin?.code ?? origin;
        final destCode = query.destination.code.isNotEmpty ? query.destination.code : dest;
        return [
          TravelOffer(
            id: 'portal_google_flights_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.flights,
            providerName: 'Google Flights (Busca Oficial)',
            originLabel: originCode,
            destinationLabel: destCode,
            cabinOrService: AppFormatters.travelClassLabel(query.travelClass),
            baggageInfo: 'Verifique regras diretamente na companhia aérea',
            rulesSummary: 'Redirecionamento direto com origem, destino e data preenchidos.',
            dataSource: 'Portal Oficial Externo',
            fetchedAt: now,
            officialUrl:
                'https://www.google.com/travel/flights?q=Voos%20de%20\${Uri.encodeComponent(originCode)}%20para%20\${Uri.encodeComponent(destCode)}%20em%20\$dateIso',
            isDirectPortalFallback: true,
          ),
          TravelOffer(
            id: 'portal_skyscanner_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.flights,
            providerName: 'Skyscanner Brasil',
            originLabel: originCode,
            destinationLabel: destCode,
            cabinOrService: AppFormatters.travelClassLabel(query.travelClass),
            baggageInfo: 'Comparador parceiro oficial',
            rulesSummary: 'Consulta externa em tempo real no portal Skyscanner.',
            dataSource: 'Portal Oficial Externo',
            fetchedAt: now,
            officialUrl: 'https://www.skyscanner.com.br/',
            isDirectPortalFallback: true,
          ),
        ];

      case TravelCategory.buses:
        return [
          TravelOffer(
            id: 'bus_clickbus_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.buses,
            providerName: 'ClickBus (Portal Rodoviário)',
            originLabel: origin,
            destinationLabel: dest,
            cabinOrService: 'Convencional / Executivo / Leito',
            baggageInfo: 'Até 30kg no bagageiro + 5kg mão (Norma ANTT)',
            rulesSummary: 'Consulta direta de horários e viações autorizadas para \$dateBr.',
            dataSource: 'Redirecionamento Oficial Rodoviário',
            fetchedAt: now,
            officialUrl:
                'https://www.clickbus.com.br/onibus/\${_slugify(origin)}-to-\${_slugify(dest)}?departureDate=\$dateIso',
            isDirectPortalFallback: true,
          ),
          TravelOffer(
            id: 'bus_buson_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.buses,
            providerName: 'Buson (Guichê Virtual)',
            originLabel: origin,
            destinationLabel: dest,
            cabinOrService: 'Todas as classes rodoviárias',
            baggageInfo: 'Conforme regras da viação selecionada',
            rulesSummary: 'Consulta oficial de passagens rodoviárias interestaduais e intermunicipais.',
            dataSource: 'Redirecionamento Oficial Rodoviário',
            fetchedAt: now,
            officialUrl: 'https://www.buson.com.br/',
            isDirectPortalFallback: true,
          ),
        ];

      case TravelCategory.boats:
        return [
          TravelOffer(
            id: 'boat_navegam_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.boats,
            providerName: 'Navegam — Transporte Fluvial Amazônia',
            originLabel: origin,
            destinationLabel: dest,
            cabinOrService: 'Lancha Rápida (Ajato) / Barco Regional / Camarote',
            baggageInfo: 'Conforme regulamento da embarcação e Capitania dos Portos',
            rulesSummary: 'Consulta de linhas fluviais na Região Norte (AM, PA, AP, RO) para \$dateBr.',
            dataSource: 'Portal Fluvial Oficial',
            fetchedAt: now,
            officialUrl: 'https://navegam.com.br/',
            isDirectPortalFallback: true,
          ),
          TravelOffer(
            id: 'boat_amazonstar_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.boats,
            providerName: 'Amazon Star / Operadoras Portuárias',
            originLabel: origin,
            destinationLabel: dest,
            cabinOrService: 'Rede / Suíte / Lancha Expresso',
            baggageInfo: 'Consultar limite de bagagem por passageiro',
            rulesSummary: 'Consulta oficial de horários e embarcações da bacia amazônica.',
            dataSource: 'Portal Fluvial Oficial',
            fetchedAt: now,
            officialUrl: 'https://www.amazonstar.com.br/',
            isDirectPortalFallback: true,
          ),
        ];

      case TravelCategory.stays:
        final checkoutIso = (query.returnDate ?? query.departureDate.add(const Duration(days: 2)))
            .toIso8601String()
            .split('T')
            .first;
        return [
          TravelOffer(
            id: 'stay_booking_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.stays,
            providerName: 'Booking.com — Hotéis e Pousadas',
            originLabel: dest,
            destinationLabel: dest,
            cabinOrService: '\${query.passengers} hóspede(s)',
            baggageInfo: 'Check-in \$dateIso • Check-out \$checkoutIso',
            rulesSummary: 'Consulta oficial de tarifas, avaliações verificadas e fotos.',
            dataSource: 'Portal Oficial de Hospedagem',
            fetchedAt: now,
            officialUrl:
                'https://www.booking.com/searchresults.pt-br.html?ss=\${Uri.encodeComponent(dest)}&checkin=\$dateIso&checkout=\$checkoutIso&group_adults=\${query.passengers}',
            isDirectPortalFallback: true,
          ),
          TravelOffer(
            id: 'stay_hoteis_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.stays,
            providerName: 'Hoteis.com Brasil',
            originLabel: dest,
            destinationLabel: dest,
            cabinOrService: 'Hotéis, Resorts e Apartamentos',
            baggageInfo: 'Check-in \$dateIso',
            rulesSummary: 'Pesquisa direta no portal oficial Hoteis.com.',
            dataSource: 'Portal Oficial de Hospedagem',
            fetchedAt: now,
            officialUrl:
                'https://www.hoteis.com/Hotel-Search?destination=\${Uri.encodeComponent(dest)}&startDate=\$dateIso&endDate=\$checkoutIso&adults=\${query.passengers}',
            isDirectPortalFallback: true,
          ),
        ];

      case TravelCategory.cars:
        return [
          TravelOffer(
            id: 'car_rentcars_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.cars,
            providerName: 'Rentcars — Comparador de Locadoras',
            originLabel: origin.isNotEmpty ? origin : dest,
            destinationLabel: dest,
            cabinOrService: 'Econômico / Sedan / SUV / Utilitário',
            baggageInfo: 'Compara Localiza, Movida, Unidas e internacionais',
            rulesSummary: 'Consulta direta de disponibilidade e seguros para retirada em \$dateBr.',
            dataSource: 'Portal Oficial de Locação',
            fetchedAt: now,
            officialUrl: 'https://www.rentcars.com/pt-br/',
            isDirectPortalFallback: true,
          ),
          TravelOffer(
            id: 'car_localiza_\${now.millisecondsSinceEpoch}',
            category: TravelCategory.cars,
            providerName: 'Localiza Hertz Brasil',
            originLabel: origin.isNotEmpty ? origin : dest,
            destinationLabel: dest,
            cabinOrService: 'Frota Nacional',
            baggageInfo: 'CNH definitiva e cartão de crédito requeridos',
            rulesSummary: 'Redirecionamento direto ao portal oficial da locadora.',
            dataSource: 'Portal Oficial de Locação',
            fetchedAt: now,
            officialUrl: 'https://www.localiza.com/brasil/pt-br',
            isDirectPortalFallback: true,
          ),
        ];
    }
  }

  static String _slugify(String text) {
    return text
        .toLowerCase()
        .trim()
        .replaceAll(RegExp(r'[áàâãä]'), 'a')
        .replaceAll(RegExp(r'[éèêë]'), 'e')
        .replaceAll(RegExp(r'[íìîï]'), 'i')
        .replaceAll(RegExp(r'[óòôõö]'), 'o')
        .replaceAll(RegExp(r'[úùûü]'), 'u')
        .replaceAll('ç', 'c')
        .replaceAll(RegExp(r'[^a-z0-9]+'), '-');
  }
}
