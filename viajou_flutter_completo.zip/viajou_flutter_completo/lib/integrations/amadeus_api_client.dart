import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';
import '../utils/formatters.dart';

class AmadeusApiClient {
  static const Map<String, String> _airlineNames = {
    'LA': 'LATAM Airlines',
    'G3': 'GOL Linhas Aéreas',
    'AD': 'Azul Linhas Aéreas',
    'TP': 'TAP Air Portugal',
    'AA': 'American Airlines',
    'DL': 'Delta Air Lines',
    'UA': 'United Airlines',
    'AF': 'Air France',
    'KL': 'KLM',
    'IB': 'Iberia',
    'LH': 'Lufthansa',
    'CM': 'Copa Airlines',
    'AR': 'Aerolíneas Argentinas',
    'AV': 'Avianca',
    'EK': 'Emirates',
    'QR': 'Qatar Airways',
  };

  static const Map<String, String> _airlineWebsites = {
    'LA': 'https://www.latamairlines.com/br/pt',
    'G3': 'https://www.voegol.com.br',
    'AD': 'https://www.voeazul.com.br',
    'TP': 'https://www.flytap.com/pt-br/',
    'AA': 'https://www.aa.com.br',
    'DL': 'https://pt.delta.com',
    'UA': 'https://www.united.com/pt/br',
    'AF': 'https://wwws.airfrance.com.br',
    'CM': 'https://www.copaair.com/pt-br',
    'AV': 'https://www.avianca.com/pt/',
  };

  Future<List<LocationPoint>> searchLocations({
    required String proxyBaseUrl,
    required String keyword,
  }) async {
    final uri = Uri.parse('$proxyBaseUrl/api/locations')
        .replace(queryParameters: {'keyword': keyword});

    final response = await http.get(uri).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) {
      throw Exception('Erro ao consultar localidades (${response.statusCode})');
    }

    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    final data = (decoded['data'] as List?) ?? [];

    return data.map((item) {
      final address = item['address'] as Map<String, dynamic>? ?? {};
      return LocationPoint(
        code: item['iataCode'] ?? '',
        name: item['name'] ?? '',
        city: address['cityName'] ?? item['name'] ?? '',
        stateOrCountry: address['countryName'] ?? address['countryCode'] ?? '',
        type: item['subType'] ?? 'AIRPORT',
      );
    }).toList();
  }

  Future<List<TravelOffer>> searchFlights({
    required String proxyBaseUrl,
    required SearchQuery query,
    required String currency,
  }) async {
    if (query.origin == null) {
      throw Exception('Origem é obrigatória para passagens aéreas.');
    }

    final depStr = query.departureDate.toIso8601String().split('T').first;
    final params = <String, String>{
      'origin': query.origin!.code,
      'destination': query.destination.code,
      'departureDate': depStr,
      'adults': query.passengers.toString(),
      'travelClass': query.travelClass,
      'currency': currency,
    };

    if (query.isRoundTrip && query.returnDate != null) {
      params['returnDate'] = query.returnDate!.toIso8601String().split('T').first;
    }

    final uri = Uri.parse('$proxyBaseUrl/api/flights').replace(queryParameters: params);
    final response = await http.get(uri).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      final errBody = jsonDecode(response.body);
      throw Exception(errBody['error'] ?? 'Falha ao consultar voos reais.');
    }

    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    final data = (decoded['data'] as List?) ?? [];
    final dictionaries = decoded['dictionaries'] as Map<String, dynamic>? ?? {};
    final carriersDict = dictionaries['carriers'] as Map<String, dynamic>? ?? {};
    final now = DateTime.now();

    final seenKeys = <String>{};
    final offers = <TravelOffer>[];

    for (final item in data) {
      final itineraries = (item['itineraries'] as List?) ?? [];
      if (itineraries.isEmpty) continue;

      final outbound = itineraries.first as Map<String, dynamic>;
      final segments = (outbound['segments'] as List?) ?? [];
      if (segments.isEmpty) continue;

      final firstSeg = segments.first as Map<String, dynamic>;
      final lastSeg = segments.last as Map<String, dynamic>;

      final carrierCode = firstSeg['carrierCode']?.toString() ?? '';
      final airlineName = _airlineNames[carrierCode] ??
          carriersDict[carrierCode]?.toString() ??
          'Companhia $carrierCode';

      final depAt = DateTime.tryParse(firstSeg['departure']?['at'] ?? '');
      final arrAt = DateTime.tryParse(lastSeg['arrival']?['at'] ?? '');
      final duration = AppFormatters.parseIso8601Duration(
        outbound['duration']?.toString() ?? '',
      );

      final priceObj = item['price'] as Map<String, dynamic>? ?? {};
      final totalPrice = double.tryParse(priceObj['grandTotal']?.toString() ?? '');
      final offerCurrency = priceObj['currency']?.toString() ?? currency;

      final dedupKey = '$carrierCode-${depAt?.toIso8601String()}-$totalPrice';
      if (seenKeys.contains(dedupKey)) continue;
      seenKeys.add(dedupKey);

      String baggageDesc = 'Consultar franquia de bagagem no site oficial';
      final travelerPricings = (item['travelerPricings'] as List?) ?? [];
      if (travelerPricings.isNotEmpty) {
        final fareDetails = (travelerPricings.first['fareDetailsBySegment'] as List?) ?? [];
        if (fareDetails.isNotEmpty) {
          final includedBags = fareDetails.first['includedCheckedBags'] as Map<String, dynamic>?;
          final qty = includedBags?['quantity'];
          if (qty != null) {
            baggageDesc = qty == 0
                ? 'Somente bagagem de mão (0 despachada)'
                : '$qty bagagem(ns) despachada(s) incluída(s)';
          }
        }
      }

      final officialSite = _airlineWebsites[carrierCode] ??
          'https://www.google.com/travel/flights?q=Flights%20to%20${query.destination.code}%20from%20${query.origin!.code}%20on%20$depStr';

      offers.add(
        TravelOffer(
          id: 'amadeus_${item['id']}_${now.millisecondsSinceEpoch}',
          category: TravelCategory.flights,
          providerName: airlineName,
          carrierCode: carrierCode,
          originLabel: '${firstSeg['departure']?['iataCode'] ?? query.origin!.code}',
          destinationLabel: '${lastSeg['arrival']?['iataCode'] ?? query.destination.code}',
          departureTime: depAt,
          arrivalTime: arrAt,
          duration: duration,
          stops: segments.length - 1,
          price: totalPrice,
          currency: offerCurrency,
          cabinOrService: AppFormatters.travelClassLabel(query.travelClass),
          baggageInfo: baggageDesc,
          rulesSummary: query.isRoundTrip
              ? 'Tarifa ida e volta para ${query.passengers} passageiro(s). Sujeita a disponibilidade.'
              : 'Tarifa somente ida para ${query.passengers} passageiro(s). Sujeita a disponibilidade.',
          dataSource: 'Amadeus GDS Official API',
          fetchedAt: now,
          officialUrl: officialSite,
          isDirectPortalFallback: false,
        ),
      );
    }

    return offers;
  }
}
