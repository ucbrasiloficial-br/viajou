import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';

class GroundApiClient {
  Future<List<TravelOffer>> searchGroundRoutes({
    required String proxyBaseUrl,
    required SearchQuery query,
    required String languageCode,
  }) async {
    final origin = query.origin?.city ?? '';
    final dest = query.destination.city;
    final dateIso = query.departureDate.toIso8601String().split('T').first;

    final cleanBase = proxyBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$cleanBase/api/ground').replace(
      queryParameters: {
        'origin': origin,
        'destination': dest,
        'date': dateIso,
        'hl': languageCode,
      },
    );

    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) return [];

    final decoded = jsonDecode(response.body);
    final rawOptions =
        (decoded is Map ? decoded['options'] : null) as List? ?? [];
    final now = DateTime.now();
    final offers = <TravelOffer>[];

    for (var i = 0; i < rawOptions.length; i++) {
      final item = rawOptions[i];
      if (item is! Map<String, dynamic>) continue;
      final title = (item['title'] ?? '$origin → $dest').toString();
      final snippet = (item['snippet'] ?? '').toString();
      final link = (item['link'] ?? '').toString();
      final source = (item['source'] ?? 'Operadora Oficial').toString();

      if (!link.startsWith('https://')) continue;

      offers.add(
        TravelOffer(
          id: 'ground_live_${i}_${now.millisecondsSinceEpoch}',
          category: TravelCategory.buses,
          providerName: title.length > 48 ? '${title.substring(0, 48)}...' : title,
          originLabel: origin,
          destinationLabel: dest,
          cabinOrService: 'Ônibus / Trem • $source',
          baggageInfo: 'Consulte franquia da operadora no bilhete',
          rulesSummary: snippet.isNotEmpty
              ? snippet
              : 'Horários e tarifas verificados para $dateIso.',
          dataSource: 'SearchApi • Rotas Terrestres',
          fetchedAt: now,
          officialUrl: link,
          isDirectPortalFallback: false,
        ),
      );
    }

    return offers;
  }
}
