import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';

class StaysApiClient {
  Future<List<TravelOffer>> searchStays({
    required String proxyBaseUrl,
    required SearchQuery query,
    required String currency,
  }) async {
    final destinationText = query.destination.city.isNotEmpty
        ? query.destination.city
        : query.destination.name;

    final checkInStr = query.departureDate.toIso8601String().split('T').first;
    final effectiveCheckout = query.returnDate ??
        query.departureDate.add(const Duration(days: 2));
    final checkOutStr =
        effectiveCheckout.toIso8601String().split('T').first;

    final cleanBase = proxyBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$cleanBase/api/stays').replace(
      queryParameters: {
        'q': 'Hotéis em $destinationText',
        'checkIn': checkInStr,
        'checkOut': checkOutStr,
        'adults': query.passengers.toString(),
        'currency': currency,
      },
    );

    final response = await http.get(uri).timeout(const Duration(seconds: 25));
    final decoded = jsonDecode(response.body);

    if (response.statusCode != 200) {
      final errMsg = decoded is Map && decoded['error'] != null
          ? decoded['error'].toString()
          : 'Erro ao consultar hospedagens (${response.statusCode})';
      throw Exception(errMsg);
    }

    final rawProps =
        (decoded is Map ? decoded['properties'] : null) as List? ?? [];
    final respCurrency = (decoded is Map && decoded['currency'] != null)
        ? decoded['currency'].toString()
        : currency;

    final now = DateTime.now();
    final offers = <TravelOffer>[];

    for (var i = 0; i < rawProps.length; i++) {
      final item = rawProps[i];
      if (item is! Map<String, dynamic>) continue;

      final name = (item['name'] ?? 'Hospedagem').toString().trim();
      final rating = item['overall_rating'];
      final reviews = item['reviews'];
      final hotelClass = item['hotel_class'];

      final ratePerNight = item['rate_per_night'] is Map
          ? _parsePrice(item['rate_per_night']['extracted_lowest'] ??
              item['rate_per_night']['lowest'])
          : _parsePrice(item['price']);

      final totalRate = item['total_rate'] is Map
          ? _parsePrice(item['total_rate']['extracted_lowest'] ??
              item['total_rate']['lowest'])
          : null;

      final link = (item['link'] ?? '').toString().trim();
      final officialUrl = link.startsWith('https://')
          ? link
          : 'https://www.google.com/travel/hotels?q=${Uri.encodeComponent('$name $destinationText')}';

      final serviceSummary = [
        if (hotelClass != null) '$hotelClass★',
        if (rating != null) 'Nota $rating',
        if (reviews != null) '($reviews avaliações)',
      ].join(' • ');

      final amenitiesList = (item['amenities'] as List?)
              ?.take(4)
              .map((e) => e.toString())
              .toList() ??
          [];

      offers.add(
        TravelOffer(
          id: 'stay_${i}_${now.millisecondsSinceEpoch}',
          category: TravelCategory.stays,
          providerName: name,
          carrierCode: rating != null ? '$rating★' : '',
          originLabel: destinationText,
          destinationLabel: destinationText,
          price: totalRate ?? ratePerNight,
          currency: respCurrency,
          cabinOrService: serviceSummary.isNotEmpty
              ? serviceSummary
              : '${query.passengers} hóspede(s)',
          baggageInfo: amenitiesList.isNotEmpty
              ? amenitiesList.join(' • ')
              : 'Check-in $checkInStr • Check-out $checkOutStr',
          rulesSummary: totalRate != null && ratePerNight != null
              ? 'Total estadia estimado (${_formatMoney(totalRate, respCurrency)}) • Diária base ${_formatMoney(ratePerNight, respCurrency)}.'
              : 'Tarifa exibida conforme disponibilidade do hotel para $checkInStr a $checkOutStr.',
          dataSource: 'SearchApi • Google Hotels',
          fetchedAt: now,
          officialUrl: officialUrl,
          isDirectPortalFallback: false,
        ),
      );
    }

    return offers;
  }

  double? _parsePrice(dynamic raw) {
    if (raw == null) return null;
    if (raw is num) return raw.toDouble();
    final cleaned = raw
        .toString()
        .replaceAll(RegExp(r'[^0-9.,]'), '')
        .replaceAll('.', '')
        .replaceAll(',', '.');
    return double.tryParse(cleaned);
  }

  String _formatMoney(double value, String currency) {
    return '$currency ${value.toStringAsFixed(2).replaceAll('.', ',')}';
  }
}
