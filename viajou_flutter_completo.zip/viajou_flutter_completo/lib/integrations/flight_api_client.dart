import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/search_query.dart';
import '../models/travel_category.dart';
import '../models/travel_offer.dart';
import '../utils/formatters.dart';

class FlightApiClient {
  static const Map<String, String> _knownAirlineUrls = {
    'LATAM': 'https://www.latamairlines.com/br/pt',
    'GOL': 'https://www.voegol.com.br',
    'Azul': 'https://www.voeazul.com.br',
    'TAP': 'https://www.flytap.com/pt-br/',
    'American': 'https://www.aa.com.br',
    'Delta': 'https://pt.delta.com',
    'United': 'https://www.united.com/pt/br',
    'Air France': 'https://wwws.airfrance.com.br',
    'Copa': 'https://www.copaair.com/pt-br',
    'Avianca': 'https://www.avianca.com/pt/',
    'Iberia': 'https://www.iberia.com/br/',
    'Lufthansa': 'https://www.lufthansa.com/br/pt/homepage',
    'Emirates': 'https://www.emirates.com/br/portuguese/',
    'Qatar': 'https://www.qatarairways.com/pt-br/homepage.html',
  };

  Future<List<TravelOffer>> searchFlights({
    required String proxyBaseUrl,
    required SearchQuery query,
    required String currency,
    String languageCode = 'pt',
  }) async {
    if (query.origin == null) {
      throw Exception('Selecione a origem para pesquisar voos.');
    }

    final originCode =
        query.origin!.code.isNotEmpty ? query.origin!.code : query.origin!.city;
    final destCode = query.destination.code.isNotEmpty
        ? query.destination.code
        : query.destination.city;
    final depDateStr = query.departureDate.toIso8601String().split('T').first;

    final params = <String, String>{
      'origin': originCode,
      'destination': destCode,
      'departureDate': depDateStr,
      'adults': query.passengers.toString(),
      'travelClass': query.travelClass,
      'currency': currency,
      'hl': languageCode,
    };

    if (query.isRoundTrip && query.returnDate != null) {
      params['returnDate'] = query.returnDate!.toIso8601String().split('T').first;
    }

    final cleanBase = proxyBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final uri =
        Uri.parse('$cleanBase/api/flights').replace(queryParameters: params);

    final response = await http.get(uri).timeout(const Duration(seconds: 25));
    final decoded = jsonDecode(response.body);

    if (response.statusCode != 200) {
      final errMsg = decoded is Map && decoded['error'] != null
          ? decoded['error'].toString()
          : 'Erro ao consultar voos (${response.statusCode})';
      throw Exception(errMsg);
    }

    final rawFlights = (decoded is Map ? decoded['flights'] : null) as List? ?? [];
    final respCurrency = (decoded is Map && decoded['currency'] != null)
        ? decoded['currency'].toString()
        : currency;

    final now = DateTime.now();
    final seen = <String>{};
    final tempOffers = <TravelOffer>[];

    for (var i = 0; i < rawFlights.length; i++) {
      final item = rawFlights[i];
      if (item is! Map<String, dynamic>) continue;

      final flightsList = (item['flights'] as List?) ?? [];
      if (flightsList.isEmpty) continue;

      final firstLeg = flightsList.first as Map<String, dynamic>;
      final lastLeg = flightsList.last as Map<String, dynamic>;

      final airlineName = (firstLeg['airline'] ??
              item['airline'] ??
              'Companhia Aérea')
          .toString()
          .trim();

      final depAirport = (firstLeg['departure_airport'] is Map
              ? (firstLeg['departure_airport']['id'] ??
                  firstLeg['departure_airport']['name'])
              : firstLeg['departure_airport'])
          ?.toString() ??
          originCode;

      final arrAirport = (lastLeg['arrival_airport'] is Map
              ? (lastLeg['arrival_airport']['id'] ??
                  lastLeg['arrival_airport']['name'])
              : lastLeg['arrival_airport'])
          ?.toString() ??
          destCode;

      final depTime = _parseFlexibleDateTime(
        firstLeg['departure_airport'] is Map
            ? firstLeg['departure_airport']['time']
            : firstLeg['departure_time'],
        query.departureDate,
      );

      final arrTime = _parseFlexibleDateTime(
        lastLeg['arrival_airport'] is Map
            ? lastLeg['arrival_airport']['time']
            : lastLeg['arrival_time'],
        query.departureDate,
      );

      final totalMinutes = _extractTotalMinutes(item, flightsList);
      final duration =
          totalMinutes != null ? Duration(minutes: totalMinutes) : null;

      final priceValue = _parsePrice(item['price']);
      final stops = flightsList.length > 1 ? flightsList.length - 1 : 0;

      final dedupKey =
          '$airlineName-$depAirport-$arrAirport-${depTime?.toIso8601String()}-$priceValue';
      if (seen.contains(dedupKey)) continue;
      seen.add(dedupKey);

      final officialUrl = _resolveOfficialUrl(
        airlineName: airlineName,
        origin: originCode,
        destination: destCode,
        depDate: depDateStr,
      );

      final baggageSummary = (firstLeg['baggage'] is List &&
              (firstLeg['baggage'] as List).isNotEmpty)
          ? (firstLeg['baggage'] as List).join(' • ')
          : 'Consultar franquia de bagagem no site oficial da companhia';

      tempOffers.add(
        TravelOffer(
          id: 'flight_${i}_${now.millisecondsSinceEpoch}',
          category: TravelCategory.flights,
          providerName: airlineName,
          carrierCode: firstLeg['flight_number']?.toString() ?? '',
          originLabel: depAirport,
          destinationLabel: arrAirport,
          departureTime: depTime,
          arrivalTime: arrTime,
          duration: duration,
          stops: stops,
          price: priceValue,
          currency: respCurrency,
          cabinOrService: AppFormatters.travelClassLabel(query.travelClass),
          baggageInfo: baggageSummary,
          rulesSummary: query.isRoundTrip
              ? 'Opção ida e volta para ${query.passengers} passageiro(s). Tarifa sujeita a alteração no site oficial.'
              : 'Opção somente ida para ${query.passengers} passageiro(s). Tarifa sujeita a alteração no site oficial.',
          dataSource: 'SearchApi • Google Flights',
          fetchedAt: now,
          officialUrl: officialUrl,
          isDirectPortalFallback: false,
        ),
      );
    }

    // Marcar tarifas promocionais (abaixo de 88% da média dos resultados)
    final priced = tempOffers.where((e) => e.price != null).map((e) => e.price!).toList();
    if (priced.length >= 2) {
      final avg = priced.reduce((a, b) => a + b) / priced.length;
      final threshold = avg * 0.88;
      return tempOffers.map((o) {
        if (o.price != null && o.price! <= threshold) {
          final pct = (((avg - o.price!) / avg) * 100).round();
          return TravelOffer(
            id: o.id,
            category: o.category,
            providerName: o.providerName,
            carrierCode: o.carrierCode,
            originLabel: o.originLabel,
            destinationLabel: o.destinationLabel,
            departureTime: o.departureTime,
            arrivalTime: o.arrivalTime,
            duration: o.duration,
            stops: o.stops,
            price: o.price,
            currency: o.currency,
            cabinOrService: o.cabinOrService,
            baggageInfo: o.baggageInfo,
            rulesSummary: o.rulesSummary,
            dataSource: o.dataSource,
            fetchedAt: o.fetchedAt,
            officialUrl: o.officialUrl,
            isDirectPortalFallback: o.isDirectPortalFallback,
            isPromoDeal: true,
            promoBadge: pct >= 5 ? '-$pct% ABAIXO DA MÉDIA' : 'TARIFA PROMOCIONAL',
          );
        }
        return o;
      }).toList();
    }

    return tempOffers;
  }

  double? _parsePrice(dynamic raw) {
    if (raw == null) return null;
    if (raw is num) return raw.toDouble();
    final cleaned = raw
        .toString()
        .replaceAll(RegExp(r'[^0-9.,]'), '')
        .replaceAll('.', '')
        .replaceAll(',', '.');
    return double.tryParse(cleaned);
  }

  int? _extractTotalMinutes(Map<String, dynamic> item, List legs) {
    if (item['total_duration'] is num) {
      return (item['total_duration'] as num).toInt();
    }
    if (item['total_duration'] != null) {
      final parsed = int.tryParse(item['total_duration'].toString());
      if (parsed != null) return parsed;
    }
    var sum = 0;
    var hasAny = false;
    for (final leg in legs) {
      if (leg is Map && leg['duration'] is num) {
        sum += (leg['duration'] as num).toInt();
        hasAny = true;
      }
    }
    return hasAny ? sum : null;
  }

  DateTime? _parseFlexibleDateTime(dynamic raw, DateTime fallbackDate) {
    if (raw == null) return null;
    final str = raw.toString().trim();
    if (str.isEmpty) return null;

    final direct = DateTime.tryParse(str.replaceFirst(' ', 'T'));
    if (direct != null) return direct;

    final timeMatch = RegExp(r'^(\d{1,2}):(\d{2})').firstMatch(str);
    if (timeMatch != null) {
      var hour = int.tryParse(timeMatch.group(1)!) ?? 0;
      final minute = int.tryParse(timeMatch.group(2)!) ?? 0;
      final upper = str.toUpperCase();
      if (upper.contains('PM') && hour < 12) hour += 12;
      if (upper.contains('AM') && hour == 12) hour = 0;
      return DateTime(
        fallbackDate.year,
        fallbackDate.month,
        fallbackDate.day,
        hour,
        minute,
      );
    }
    return null;
  }

  String _resolveOfficialUrl({
    required String airlineName,
    required String origin,
    required String destination,
    required String depDate,
  }) {
    for (final entry in _knownAirlineUrls.entries) {
      if (airlineName.toLowerCase().contains(entry.key.toLowerCase())) {
        return entry.value;
      }
    }
    return 'https://www.google.com/travel/flights?q=Voos%20de%20${Uri.encodeComponent(origin)}%20para%20${Uri.encodeComponent(destination)}%20em%20$depDate';
  }
}
