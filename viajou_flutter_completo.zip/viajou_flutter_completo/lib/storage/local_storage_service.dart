import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../app/app_config.dart';
import '../models/checklist_item.dart';
import '../models/location_point.dart';
import '../models/search_query.dart';
import '../models/travel_offer.dart';

class LocalStorageService {
  static const _kFavoritesOffers = 'viajou_fav_offers_v1';
  static const _kFavoriteDestinations = 'viajou_fav_dest_v1';
  static const _kSearchHistory = 'viajou_history_v1';
  static const _kCurrency = 'viajou_currency_v1';
  static const _kLanguage = 'viajou_language_v1';
  static const _kNotifications = 'viajou_notifications_v1';
  static const _kCustomProxyUrl = 'viajou_proxy_url_v1';
  static const _kChecklist = 'viajou_checklist_v1';
  static const _kPriceAlerts = 'viajou_price_alerts_v1';

  Future<List<TravelOffer>> getFavoriteOffers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kFavoritesOffers) ?? [];
    return raw.map((e) => TravelOffer.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveFavoriteOffers(List<TravelOffer> offers) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = offers.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kFavoritesOffers, raw);
  }

  Future<List<LocationPoint>> getFavoriteDestinations() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kFavoriteDestinations) ?? [];
    return raw.map((e) => LocationPoint.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveFavoriteDestinations(List<LocationPoint> list) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = list.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kFavoriteDestinations, raw);
  }

  Future<List<SearchQuery>> getSearchHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kSearchHistory) ?? [];
    return raw.map((e) => SearchQuery.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveSearchHistory(List<SearchQuery> list) async {
    final prefs = await SharedPreferences.getInstance();
    final limited = list.take(25).toList();
    final raw = limited.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kSearchHistory, raw);
  }

  Future<String> getCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kCurrency) ?? 'BRL';
  }

  Future<void> setCurrency(String currency) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kCurrency, currency);
  }

  Future<String> getLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kLanguage) ?? 'pt';
  }

  Future<void> setLanguage(String lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLanguage, lang);
  }

  Future<bool> getNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kNotifications) ?? true;
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kNotifications, enabled);
  }

  Future<String> getProxyUrl() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_kCustomProxyUrl) ?? '';
    if (saved.trim().isNotEmpty) return saved.trim();
    return AppConfig.defaultProxyBaseUrl;
  }

  Future<void> setProxyUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kCustomProxyUrl, url.trim());
  }

  Future<List<ChecklistItem>> getChecklist() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kChecklist);
    if (raw == null) {
      return const [
        ChecklistItem(
          id: 'chk_doc',
          title: 'Documento oficial com foto (RG, CNH ou Passaporte)',
          categoryTag: 'Documentos',
        ),
        ChecklistItem(
          id: 'chk_voucher',
          title: 'Bilhete / QR Code da passagem ou reserva salvo offline',
          categoryTag: 'Documentos',
        ),
        ChecklistItem(
          id: 'chk_benef',
          title: 'Carteira ID Jovem / CadÚnico / Passe Livre (se aplicável)',
          categoryTag: 'Benefícios',
        ),
        ChecklistItem(
          id: 'chk_bag',
          title: 'Bagagem de mão conferida dentro das dimensões permitidas',
          categoryTag: 'Bagagem',
        ),
        ChecklistItem(
          id: 'chk_power',
          title: 'Carregador de celular, powerbank e fones de ouvido',
          categoryTag: 'Eletrônicos',
        ),
        ChecklistItem(
          id: 'chk_fluvial',
          title: 'Rede, punhos e agasalho leve (para viagem fluvial / ônibus)',
          categoryTag: 'Amazônia & Estrada',
        ),
      ];
    }
    return raw.map((e) => ChecklistItem.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveChecklist(List<ChecklistItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = items.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kChecklist, raw);
  }

  Future<List<Map<String, dynamic>>> getPriceAlerts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kPriceAlerts) ?? [];
    return raw
        .map((e) => Map<String, dynamic>.from(jsonDecode(e) as Map))
        .toList();
  }

  Future<void> savePriceAlerts(List<Map<String, dynamic>> alerts) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = alerts.map((e) => jsonEncode(e)).toList();
    await prefs.setStringList(_kPriceAlerts, raw);
  }
}
