import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../app/app_config.dart';
import '../models/travel_offer.dart';
import '../models/search_query.dart';
import '../models/location_point.dart';

class LocalStorageService {
  static const _kFavoritesOffers = 'viajou_fav_offers_v1';
  static const _kFavoriteDestinations = 'viajou_fav_dest_v1';
  static const _kSearchHistory = 'viajou_history_v1';
  static const _kCurrency = 'viajou_currency_v1';
  static const _kNotifications = 'viajou_notifications_v1';
  static const _kCustomProxyUrl = 'viajou_proxy_url_v1';

  Future<List<TravelOffer>> getFavoriteOffers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kFavoritesOffers) ?? [];
    return raw.map((e) => TravelOffer.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveFavoriteOffers(List<TravelOffer> offers) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = offers.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kFavoritesOffers, raw);
  }

  Future<List<LocationPoint>> getFavoriteDestinations() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kFavoriteDestinations) ?? [];
    return raw.map((e) => LocationPoint.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveFavoriteDestinations(List<LocationPoint> list) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = list.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kFavoriteDestinations, raw);
  }

  Future<List<SearchQuery>> getSearchHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kSearchHistory) ?? [];
    return raw.map((e) => SearchQuery.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveSearchHistory(List<SearchQuery> list) async {
    final prefs = await SharedPreferences.getInstance();
    final limited = list.take(25).toList();
    final raw = limited.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_kSearchHistory, raw);
  }

  Future<String> getCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kCurrency) ?? 'BRL';
  }

  Future<void> setCurrency(String currency) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kCurrency, currency);
  }

  Future<bool> getNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kNotifications) ?? true;
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kNotifications, enabled);
  }

  Future<String> getProxyUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kCustomProxyUrl) ?? AppConfig.defaultProxyBaseUrl;
  }

  Future<void> setProxyUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kCustomProxyUrl, url.trim());
  }
}
