import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'app/app_config.dart';
import 'screens/splash_screen.dart';
import 'services/travel_provider.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => TravelProvider(),
      child: const ViajouApp(),
    ),
  );
}

class ViajouApp extends StatelessWidget {
  const ViajouApp({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<TravelProvider>().language;
    final locale = switch (lang) {
      'en' => const Locale('en', 'US'),
      'es' => const Locale('es', 'ES'),
      _ => const Locale('pt', 'BR'),
    };

    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      locale: locale,
      supportedLocales: const [
        Locale('pt', 'BR'),
        Locale('en', 'US'),
        Locale('es', 'ES'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
    );
  }
}
