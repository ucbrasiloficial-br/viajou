import 'package:intl/intl.dart';

class AppFormatters {
  static String currency(double? value, String currencyCode) {
    if (value == null) return 'Consultar no site';
    final symbol = switch (currencyCode) {
      'BRL' => 'R\\$',
      'USD' => 'US\\$',
      'EUR' => '€',
      _ => currencyCode,
    };
    final format = NumberFormat.currency(locale: 'pt_BR', symbol: symbol);
    return format.format(value);
  }

  static String dateShort(DateTime date) {
    return DateFormat('dd/MM/yyyy', 'pt_BR').format(date);
  }

  static String dateDayMonth(DateTime date) {
    return DateFormat("dd 'de' MMM", 'pt_BR').format(date);
  }

  static String timeOnly(DateTime? date) {
    if (date == null) return '--:--';
    return DateFormat('HH:mm').format(date);
  }

  static String dateTimeFull(DateTime date) {
    return DateFormat('dd/MM/yyyy HH:mm').format(date);
  }

  static String durationLabel(Duration? duration) {
    if (duration == null) return 'Duração variável';
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    if (hours == 0) return '\${minutes}m';
    if (minutes == 0) return '\${hours}h';
    return '\${hours}h \${minutes}m';
  }

  static Duration parseIso8601Duration(String iso) {
    final regex = RegExp(r'PT(?:(\d+)H)?(?:(\d+)M)?');
    final match = regex.firstMatch(iso);
    if (match == null) return Duration.zero;
    final hours = int.tryParse(match.group(1) ?? '0') ?? 0;
    final minutes = int.tryParse(match.group(2) ?? '0') ?? 0;
    return Duration(hours: hours, minutes: minutes);
  }

  static String travelClassLabel(String code) {
    switch (code) {
      case 'ECONOMY':
        return 'Econômica';
      case 'PREMIUM_ECONOMY':
        return 'Econômica Premium';
      case 'BUSINESS':
        return 'Executiva';
      case 'FIRST':
        return 'Primeira Classe';
      default:
        return code;
    }
  }
}
